from azip import zip,unzip
from sys import argv
from os.path import isfile

hint='''
Azip function:
壓縮參數:
-i name1 -i name 2            壓縮name1,name2,...檔案
-s azip.txt                   將zip.txt的內容作為參數(默認為azip.txt)
-n name.azip                  壓縮後的檔案名稱

解壓參數:
-o name.azip                  解壓縮name.zip

密碼:
-p password                   附加密碼
'''
default_name='azip.txt'
if len(argv)==1:
    print(hint)
    if isfile(default_name):
        argv+=['-s',default_name]
if len(argv)>1:
    zip_box=[]
    password=None
    azip_name=None
    unzip_name=None
    k=1
    while k<len(argv):
        if argv[k]=='-i':
            zip_box.append(argv[k+1])
        elif argv[k]=='-s':
            cmd_list=open(argv[k+1],'r',encoding='utf-8').read().split('\n')
            cmd_box=[]
            for cmd in cmd_list:
                ck=cmd.index(' ')
                key=cmd[:ck]
                param=cmd[ck+1:]
                if param[0]==param[-1] and param[0] in ('"',"'"):
                    param=param[1:-1]
                cmd_box+=[key,param]
            argv=argv[:k+2]+cmd_box+argv[k+2:]
        elif argv[k]=='-p':
            password=argv[k+1]
        elif argv[k]=='-n':
            azip_name=argv[k+1]
        #--------------------------------
        elif argv[k]=='-o':
            unzip_name=argv[k+1]
        if argv[k] in ('-i','-s','-p','-n','-o'):
            k+=1
        k+=1
    if len(zip_box)>0:
        zip(zip_box,password,azip_name)
    if unzip_name!=None:
        print('解壓縮:',unzip_name)
        unzip(unzip_name,password)