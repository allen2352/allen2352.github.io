from azip.crypt import xor_bytes,generate_password
from azip.tool import legel_filename,ok_print,error_print,warning_print
from os import listdir,mkdir
from os.path import isfile,isdir
from time import time

def zip(filename_list,password=None,azip_name=None):
    st=time()
    if type(filename_list)==str:
        filename_list=[filename_list]
    zip_name=legel_filename(filename_list[0].split('.')[0]+'.azip') if azip_name==None else azip_name
    ok_print(f'Compress "{zip_name}"'+(f' with password({password})' if password!=None else '')+':')
    def zip_object(filepath):
        filename=filepath.split('/')[-1]
        filename_length=len(filename.encode('utf-8'))
        print(f'-i {filepath}')
        if isfile(filepath):
            content=f'{filename_length}*{filename}'.encode('utf-8')+open(filepath,'rb').read()
            return f'{len(content)}*1'.encode('utf-8')+content
        elif isdir(filepath):
            folder_bytes=[zip_object(f'{filepath}/{i}') for i in listdir(filepath)]
            content=f'{filename_length}*{filename}'.encode('utf-8')+b''.join(folder_bytes)
            return f'{len(content)}*0'.encode('utf-8')+content
        return b''
    content=b''.join([zip_object(filename.replace('\\','/')) for filename in filename_list])
    if password!=None:
        password_byte=generate_password(password.encode('utf-8'),1024)
        content = xor_bytes(content, password_byte)
    #---------------------------------------
    if zip_name.split('.')[-1]!='azip':zip_name+='.azip'
    f=open(zip_name,'wb')
    f.write(content)
    f.close()
    ok_print(f'Zip successful, time:{round(time()-st,2)}')
def unzip(zipped_name,password=None):
    st=time()
    content=open(zipped_name,'rb').read()
    if password!=None:
        password_byte=generate_password(password.encode('utf-8'),1024)
        content = xor_bytes(content, password_byte)
    ok_print(f'Decompression "{zipped_name}"' + (f' with password({password})' if password != None else '') + ':')
    def unzip_object(content_bytes,folderpath=''):
        ptr,n=0,len(content_bytes)
        while ptr<n:
            k=content_bytes.index(b'*',ptr)
            content_length=int(content_bytes[ptr:k])
            object_type=int(bytes([content_bytes[k+1]]))
            k2=content_bytes.index(b'*',k+1)
            filename_length=int(content_bytes[k+2:k2])
            filename=content_bytes[k2+1:k2+1+filename_length].decode('utf-8')
            ptr=k+2+content_length
            content=content_bytes[k2+1+filename_length:ptr]
            #-------------------------------------------------------
            filepath=f'{folderpath}{filename}'
            print(f'-o {filepath}')
            if object_type==0:  #為資料夾
                if not isdir(filepath):
                    mkdir(filepath)
                unzip_object(content,filepath+'/')
            elif object_type==1:     #為檔案
                f=open(filepath,'wb')
                f.write(content)
                f.close()
        if ptr!=n:
            warning_print(f'解壓縮出現問題:ptr={ptr},n={n}')
    zipped_name=zipped_name.replace('\\','/')
    zipped_filename=zipped_name.split('/')[-1]
    zipped_folder=zipped_filename[:-len(zipped_name)]
    unzip_folder=zipped_filename.split('.')[0]
    content=f'{len(unzip_folder)}*{unzip_folder}'.encode('utf-8')+content
#    try:
    unzip_object(f'{len(content)}*0'.encode('utf-8')+content,zipped_folder)
    ok_print(f'Unzip successful, time:{round(time()-st,2)}')
 #   except:
  #      error_print('[91m解壓縮錯誤[0m')