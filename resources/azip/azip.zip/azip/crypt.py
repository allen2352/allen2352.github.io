def xor_bytes(content,password,start_p=0):    #start_p:從第幾個password開始循環加密
    content_bytes=list(content)
    content_length=len(content)
    password_bytes=list(password)
    p_len = len(password)
    password_box=password_bytes[start_p:]
    link_times=(content_length-len(password_box))//p_len
    password_box+=password_bytes*link_times
    password_box+=password_bytes[:content_length-len(password_box)]
    void_byte=[a^b for a,b in zip(content_bytes,password_box)]
    return bytes(void_byte)
def generate_password(password,length): #密碼,最短長度
    def generate(password_bytes):
        void_password=[]
        for b in range(2):
            for i in range(len(password_bytes)-1-b):
                void_password.append((password_bytes[i]^password_bytes[i+1+b]+password_bytes[i])%256)
        return void_password
    if len(password)==0:
        password=b'123'
    while len(password)<4:
        password+=xor_bytes(password,b'azbycx')     #增加亂數，若密碼>4就不增加亂數
    password_bytes = list(password)
    #增加變化
    for i in range(len(password_bytes)):
        password_bytes[i]+=i
    password_bytes = generate(password_bytes)       #至少要generate一次
    while len(password_bytes)<length:
        password_bytes=generate(password_bytes)
    return bytes(password_bytes)

if __name__ == '__main__':
    string=b'hello world,this is my first program. In this project,I make an encrypt function.'
    password=b'all'
    password2 = generate_password(password, 100)
    encrypt=xor_bytes(string,password2,0)
    print(len(encrypt)==len(string))
    k=8
    decrypt=xor_bytes(encrypt[k:],password2,k)
    print(decrypt)
