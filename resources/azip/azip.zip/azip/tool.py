from os import listdir
def legel_filename(filename):
    format=filename.split('.')[-1]
    name=filename[:-len(format)-1]
    banlist = '/\\:*?"<>|'
    for i in banlist:
        name = name.replace(i, '_')
    o=listdir()
    if f'{name}.{format}' not in o:return f'{name}.{format}'
    c=1
    while f'{name}_{c}.{format}' in o:
        c+=1
    return f'{name}_{c}.{format}'
def ok_print(msg):
    OK = "[92m"
    RESET = "[0m"
    print(f'{OK}{msg}{RESET}')
def error_print(msg):
    Fail="[91m"
    RESET = "[0m"
    print(f'{Fail}{msg}{RESET}')
def warning_print(msg):
    WARNING = "[93m"
    RESET = "[0m"
    print(f'{WARNING}{msg}{RESET}')