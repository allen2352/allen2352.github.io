from apython import Apython
from sys import argv
from os.path import isfile
apython=Apython()
cmd=argv
hint='''
+any python file to execute
-o filename    =>save as filename
'''
if len(argv)==1:
    print('This is Apython')
    print(hint)
    apython.REPL()
else:
    if isfile(argv[1]):
        apython.load(argv[1])
        if len(argv)>=4 and argv[2]=='-o':
            apython.save(argv[3])
        apython.run()
    else:
        print(f'"{argv[1]}" not exist')