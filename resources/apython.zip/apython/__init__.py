from apython.package import Packager
from apython.executer import Executer
class Apython:
    def __init__(self,encoding='utf-8'):
        self.packager = Packager(encoding)
        self.code = self.packager.code
        self.executer = Executer(self.code)
    def parse(self):  # 印出easy_code
        code = self.packager.code
        code.display()
    def save(self, filepath):
        code = '\n'.join(self.code.code)
        open(filepath, 'w').write(code)
        print(f'[92mApython:save {filepath}[0m')
    def load(self, filepath):
        self.packager.load(filepath)
    def REPL(self):                   #互動式介面，以單行數code為輸入
        hint='>>>'
        process = len(self.code.code)
        while True:
            try:
               cmd=input(hint)
            except KeyboardInterrupt:
                print('\nKeyboardInterrupt')
                continue
            except EOFError:
                break
            need_execute=self.packager.REPL(cmd)        #當cmd有def,with,class,...時，暫停執行
            if need_execute:
                print_result=self.executer.REPL_run(process)      #print_result用不到，因為實函數就print過了
                process = len(self.code.code)          #更新執行進度
                hint='>>>'
            else:
                hint='...'
    def interaactive(self,code_block):     #互動式，以任意行數code為輸入
        process=len(self.code.code)
        self.packager.REPL(code_block,one_line=False)
        print_result=self.executer.REPL_run(process)
        return print_result
    def run(self, tf=0, stack_size=1024):
        self.executer.run(tf, stack_size)