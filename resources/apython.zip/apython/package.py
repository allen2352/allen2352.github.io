#打包程式碼
from os import listdir,getcwd,chdir
from os.path import isdir,isfile
from apython.code import Code
from apython.module import *

def parse_code(code):  # 打包程式碼為[codeline_1,codeline_2,...]
    def deal_string(k,change=True):  # k為',"的位置
        c = code[k]
        k += 1
        p = k
        while True:
            c2=code[k]
            if c2=='\n':
                cline[0]+=1   #額外加一行
            if c2 == '\\':
                k += 1
            elif c2 == c:
                break
            k += 1
        get_text=code[p:k]
       # print('c:',c,change)
        if (c=="'" and not change) or (c=='"' and change):      #代表內容括號為"，與string一樣
            return String(get_text,change=change),k
        elif c == "'" and change:
            text = []
            ck, n = 0, len(get_text)
            while ck < n:
                if get_text[ck]=='"':
                    text.append('\\')
                if get_text[ck]=='\\':
                    text.append(get_text[ck])
                    ck += 1
                text.append(get_text[ck])
                ck += 1
            return String(''.join(text),change=change), k
        elif c=='"' and not change:      #裡面可能有"
            text=[]
            ck,n=0,len(get_text)
            while ck<n:
                if get_text[ck]=='"':
                    text.append('\\')
                text.append(get_text[ck])
                if get_text[ck]=='\\':
                    text.append('\\')
                ck+=1
            return String(''.join(text)),k
    key_word=['def','while','for','in','if','elif','else','class','break','continue','return',':','and','not','or',
              'True','False','None','from','import','as','is','with','raise','try','except','finally','yield',
              'lambda','del','global','nonlocal','assert','$stop']        #無法被當成變數的元素，$stop是apython語言
    data_dict = {'AX': 0, 'BX': 1, 'CX': 2, 'DX': 3, 'ip': 4, 'esp': 5, 'sp': 6, 'ZR': 7, 'TF': 8}      #code中的禁用關鍵字名稱
    k, n = 0, len(code)
    codelines = []
    in_brackets=0
    in_lambda=0
    orig_code=code.split('\n')
    cline=[1]         #此為真實行
    codeline = [(0,cline[0],orig_code[cline[0]-1])]                   #0代表前置空格數量,line為第幾行,後方為原始程式
    while k < n:
      #  print('codeline:',codeline)
      #  input()
        c = code[k]
        if c in '0123456789':  # 代表此為數值
            p = k
            numbers = '0123456789.'
            while k < n:
                if code[k] in numbers:
                    k += 1
                else:
                    break
            number=code[p:k]
            if '.' in number:codeline.append(Float(number))
            else:codeline.append(Integer(number))
            k -= 1
        elif c in '+-*/,()[]{}!=%:><.&^|~':  # 運算單元素
            if k+2<n:
                c3=code[k:k+3]
                if c3 in ('**=','//=','>>=','<<='):
                    codeline.append(c3)
                    k += 3
                    continue
            if k+1<n:
                c2=code[k:k+2]
                if c2 in ('+=','-=','*=','/=','==','!=','**','>','<','>=','<=','%=','//','>>','<<','&=','^=','|='):
                    codeline.append(c2)
                    k += 2
                    continue
            codeline.append(c)
            if c in ('(','[','{'):in_brackets+=1
            elif c in (')',']','}'):in_brackets-=1
            if c==':' and in_brackets==0: #-----------------------------------------------------------處理冒號
                if in_lambda>0:
                    in_lambda-=1
                else:
                    try:
                        q=code.index('\n',k)        #如果找不到\n代表是最後一行了
                    except:q=len(code)
                    if q-k>1:
                        codelines.append(codeline)
                        #cline+=1                    #在同一行，cline不加一
                       # print('codeline:',codeline)
                        codeline = [(codeline[0][0]+4,cline[0],orig_code[cline[0]-1])]   #[(空格數,第幾行,原始程式),...]
                        k+=1
                        while code[k]==' ':k+=1
                        k-=1
        elif c == '#':  # 略過註解
            while k < n and code[k] != '\n':
                k += 1
            k -= 1
        elif c in ('"', "'"):  # 字串
            string,k=deal_string(k)
            if len(codeline)>0 and type(codeline[-1])==String:    #連續兩個string自動相加
                codeline.append('+')
            codeline.append(string)
        elif c == '\n':    #如果in_brackets，則忽略\n
            cline[0]+=1
            if in_brackets==0:
                if len(codeline)>1:
                    codelines.append(codeline)
                codeline = []
                # -----------------------------計算下一行的空格，即便沒有空格也需要
                k += 1
                if k < n:
                    space_num=0             #空格數量
                    while k < n and code[k] == ' ':
                        k += 1
                        space_num+=1
                    codeline.append((space_num,cline[0],orig_code[cline[0]-1]))       #每個[]的第一個為空格數量
                k -= 1
        elif c == 'r' and k + 1 < n and code[k + 1] in ('"', "'"):    #byte類型
            k += 1
            string, k = deal_string(k,change=False)
            if len(codeline) > 0 and type(codeline[-1]) == String:  # 連續兩個string自動相加
                codeline.append('+')
            codeline.append(string)
        elif c == 'b' and k + 1 < n and code[k + 1] in ('"', "'"):    #byte類型
            k+=1
            string,k=deal_string(k)
            if len(codeline) > 0 and type(codeline[-1]) == Byte:  # 連續兩個string自動相加
                codeline.append('+')
            codeline.append(Byte(string.text))
        elif c=='f' and k+1<n and code[k+1] in ('"',"'"):          #代表是f'aaa{bbb}aaa'類型
           # print('這裡2')
            codeline.append('(')
            symbol=code[k+1]
            q=k+2
            while code[q] != symbol or code[q-1]=='\\':
                q += 1
            get=code[k+2:q]
           # print('get為:',get)
            sn=len(get)
            sk=0
            textbox = []
            while sk<sn:
                if get[sk]=='\n':
                    cline[0]+=1
                if get[sk]=='{':
                    if get[sk+1]=='{':
                        textbox.append('{')
                        sk+=1
                    else:                                   #內嵌變數
                        #先儲存先前的
                        if len(codeline) > 0 and type(codeline[-1]) == String:  # 連續兩個string自動相加
                            codeline.append('+')
                        codeline.append(String(''.join(textbox)))
                        textbox=[]
                        sk+=1
                        p=sk
                        #索引至下一個"}"
                        slock=0            #字串鎖
                        c=1                #{鎖
                        while c>0:
                            sc = get[sk]
                            if slock==0:
                                if sc=='{':
                                    c+=1
                                elif sc=='}':
                                    c-=1
                                elif sc in ("'",'"'):      #啟動字串鎖，開始忽略{}
                                    slock=sc
                            else:
                                if sc==slock and get[sk-1]!='\\':    #解除字串鎖
                                    slock=0
                            sk+=1
                        sk-=1                 #為了讓get[sk]定位在"}"
                        vartext=get[p:sk]        #目前get[sk]=="}"
                        sub_codeline=parse_code(vartext)[0][1:]        #理論上只有一行，去除最前方的0
                        codeline+=['+',Var_name('$str'),'(']+sub_codeline+[')','+']
                elif get[sk]=='}' and get[sk:sk+2]=='}}':
                    textbox.append(get[sk])
                    sk+=1
                elif get[sk]=='\\':
                    textbox.append(get[sk])
                    sk+=1
                    textbox.append(get[sk])
                elif get[sk] in ('"',"'"):
                    textbox.append('\\')
                    textbox.append(get[sk])
                else:
                    textbox.append(get[sk])
                sk+=1
            codeline.append(String(''.join(textbox)))
            codeline.append(')')
            k=q
        elif c!=' ':                         # 代表此為自定義變數
        #    print('c:',c)
          #  print('end')
            v_name = []
            ban_word = '+-*/,()[]{}!=%:><.&^|~\\# \n:'   #在變數中禁止出現的元素
            while k < n:
                if code[k] not in ban_word:
                    v_name.append(code[k])
                    k += 1
                else:
                    break
            element_name=''.join(v_name)
            if element_name in key_word:
                if element_name=='True':codeline.append(TFN(True))
                elif element_name=='False':codeline.append(TFN(False))
                elif element_name == 'None':codeline.append(TFN(None))
                elif element_name == '$stop':codeline.append(Stop())
                else:codeline.append(element_name)
                if element_name=='lambda':in_lambda+=1
            else:
                #if len(codeline)>=2 and codeline[-1] in ('*','**') and codeline[-2] in ('(',','): #代表是key word argument
                #    codeline[-1]=Var_name(codeline[-1]+element_name)
                #else:                                                 #一般關鍵字
                if element_name in data_dict:
                    element_name='$$'+element_name
                codeline.append(Var_name(element_name))
            k -= 1
      #  else:
       #     print('nononono')
        k += 1
       # print(code[k:])
    if len(codeline)>1:
        codelines.append(codeline)
    #print('獲取codelines:\n[')
    #for line in codelines:
    #    if len(line)>0:
    #        print('[',end='')
    #        for i in range(len(line)-1):
    #            print(line[i],',',end='')
    #        print(line[-1],'],')
    #    else:print('[],')
    #print(']\n')
    return codelines
#---------------------------工具函數
def next_element(codeline,k,elements,end=False,stop=()):           #從codeline的第k處開始尋找elements，沒有則返回-1
    c=0      #括號
    n=len(codeline)
    elements=list(elements)
    while k<n:
        element=codeline[k]
        if c==0:
            if element in elements:
                return k
            elif element in stop:
                if end:return k
                return -1
        if c<0:
          #  print('強制返回')
            return k
        if element in ('(','[','{'):c+=1
        elif element in (')',']','}'):c-=1
        k+=1
    if end:return n
    return -1
def get_var(codeline,k,namespace):                        #從k開始取得一個變數
    n=len(codeline)
    if k==n:
        return None,-1
    p=k                     #目前p的位為obj
    k+=1
    leftb=('[','(')
    rightb=(']',')')
    while k<n and (codeline[k] in leftb or codeline[k]=='.'):    #function或index
        if codeline[k] in leftb:
            c=1
            k+=1
            while k<n and c>0:
                if codeline[k] in leftb:c+=1
                elif codeline[k] in rightb:c-=1
                k+=1
        elif codeline[k]=='.':
            k+=2
    get=codeline[p:k]
    if len(get)==1:      #代表是某物件
        if type(get[0])==Var_name:
            return Variable(get[0].name,namespace),k                            #回傳 變數,索引結束點，')'後一格
        else:return get[0],k
    elif type(get[0])==Var_name and get[0].name=='$str':                        #擷取apython自身函數
        obj=parse_codeline(get[2:-1],namespace)            #取得()中的東西
        return STR(obj),k
    elif get[1] in '([.':                                      #代表是function或index
       # print('進來了,get為',get)
        q=k
        k=1
        if type(get[0])==Var_name:
            get[0]=Variable(get[0].name,namespace)
       # print('get:',get)
        from time import time
        st=time()+1
        while len(get)>1:
            if get[k]=='(':                         #代表是function call
               # print('走這條')
                args=[]
                kwargs=[]
                s_args=None
                s_kwargs=[]
                if get[k+1]!=')':
                    while k<len(get):              #開始蒐集參數
                        if get[k+2]=='=':                      #代表是指定參數
                            p=k+3
                            k = next_element(get, p, ',)')
                            value = parse_codeline(get[p:k],namespace)
                            kwargs.append((String(get[p-2].name),value))
                        elif get[k+1]=='*':
                            p = k + 2
                            k = next_element(get, p, ',)')
                            value=parse_codeline(get[p:k], namespace)
                            if s_args==None:
                                s_args =value
                            else:
                                s_args=Oper(s_args,value,'+')  #相加
                        elif get[k+1]=='**':
                            p = k + 2
                            k = next_element(get, p, ',)')
                            s_kwargs.append(parse_codeline(get[p:k], namespace))
                        else:
                            p=k+1
                            k=next_element(get,p,',)')
                            value = parse_codeline(get[p:k],namespace)
                            args.append(value)
                        if get[k]==')':break
                    #print('args:',args)
                    #print('kwargs:',kwargs)
                else:k+=1
                #此時k為 ")"
                get=[FuncCall(get[0],List(args),Dict(kwargs),s_args,s_kwargs)]+get[k+1:]
            elif get[k]=='[':
                p=k+1
                collect=[]
                while True:
                    k=next_element(get,p,':]')
                    if get[k]==':':                                           #slice索引
                        if k==p:
                            value=TFN(None)                                 #代表第一欄位為空
                        else:
                            value = parse_codeline(get[p:k],namespace)
                        p=k+1
                        collect.append(value)
                    else:                                                        #單索引
                        if len(collect)==0:
                            collect=parse_codeline(get[p:k],namespace)
                        elif k==p:
                            collect.append(TFN(None))
                        else:
                            collect.append(parse_codeline(get[p:k],namespace))
                        break
                #k為 "]"
                if type(collect)==list:
                    if len(collect)<3:
                        collect+=[TFN(None)]*(3-len(collect))
                    collect=Slice(collect[0],collect[1],collect[2])
                get=[IndexVariable(get[0],collect)]+get[k+1:]
            elif get[k]=='.':                                        #attribute
                subattr=SubVariable(get[0],get[2])
                get=[subattr]+get[3:]
                k-=1
            if time()>st:
              #  print('get為:',get)
                raise Exception('335 get error')
            k=1
       # print('取得:',get[0])
       # a=input()
        return get[0],q
def next_codeline(codelines,row):
    space_n=codelines[row][0][0]
    s_n=space_n+1
    Row=len(codelines)
    while s_n>space_n:
        row += 1
        if row==Row:break
        s_n = codelines[row][0][0]
    return row
#解析一行:
def parse_codeline(codeline,namespace,is_list=False):     #回傳解答陣列[A,B,C,...]
    # 處理lambda(因為怕namespace被覆蓋)
    k = 0
    while k < len(codeline):
        c = codeline[k]
        if c == 'lambda':
            # print('找到了')
            p2 = k
            paramsbox = {}  # {param1:值,param2:值,...}
            k += 1  # k從此開始是變數
            n = len(codeline)
            while k < n:
                c = codeline[k]
                if type(c) == Var_name:  # 取得param
                    paramsbox[c.name]= TFN(None)
                    if k + 1 < n and codeline[k + 1] == '=':  # 此參數存在默認值
                        p = k + 2
                        k = next_element(codeline, p, ',:')  # 碰到,或)調指索引默認值
                        paramsbox[c.name] = parse_codeline(codeline[p:k], namespace)  # function參數需要namespace
                        if codeline[k] == ':': break
                if c == ':': break
                k += 1
            #  print('獲取參數:',paramsbox)
            # 此時k會指著冒號
            # print('目前k指著:',codeline[k])
            q = next_element(codeline, k, (',',')'), end=True)  # 碰到",",")"停止
           # print('get德:',codeline[k + 1:q])
            return_obj = parse_codeline(codeline[k + 1:q], '')  # function內的內容(namespace)要清空
            #  print('return_obj:',return_obj)
            lambda_obj = Lambda(paramsbox, return_obj, namespace)
            codeline = codeline[:p2] + [lambda_obj] + codeline[q:]
            # print('新codeline:',codeline)
            k = 0
        k += 1
    # 處理括弧
    k = 0
    while k < len(codeline):
        if k==0 or (type(codeline[k-1])==str and codeline[k-1] not in (')',']','}')):                 #前面為',','='
            objecct = codeline[k]
            if objecct == '(' :  # 代表此處有tuple，
                q = next_element(codeline, k + 1, ')')
                get = parse_codeline(codeline[k + 1:q], namespace)  # 變成一個tuple
                codeline = codeline[:k] + [get] + codeline[q + 1:]
                # k-=1
            elif objecct == '[':  # 代表是list
                q = next_element(codeline, k + 1, ']')
                get = parse_codeline(codeline[k + 1:q], namespace, is_list=True)  # 變成一個tuple
                codeline = codeline[:k] + [get] + codeline[q + 1:]
                # k -= 1
            elif objecct == '{':  # 代表是集合或dict
                #print(codeline)
                q=next_element(codeline,k+1,['}'])      #先將字典底部找到
               # print('q:',q)
                content=parse_codeline(codeline[k+1:q],namespace,is_list=True)       #此時content的形式為 <obj>:<obj><obj>:<obj>，逗號會消失，如果沒冒號，就是集合
                #codeline=codeline[:k]+content.elements+codeline[q+1:]
                deal_line=content.elements
                #print('deal_line:',deal_line)
                if ':' in deal_line or len(deal_line)==0:     #deal_line為空，默認為dict
                    elementbox = []      #[(key,value),...]
                    p =0
                    n=len(deal_line)
                    while p<n:
                        key=deal_line[p]
                        p+=2
                        value=deal_line[p]
                        p+=1
                        elementbox.append((key, value))
                    get = Dict(elementbox)
                else:
                    get=Set(deal_line)        #集合元素
                codeline = codeline[:k] + [get] + codeline[q + 1:]
        k += 1
    k=0
    while k<len(codeline):
        c=codeline[k]
        if type(c)==str and c in ('break','continue'):      #此行只有此元素
            return Mark(c)
        elif type(c)==str and c=='pass':      #此行只有此元素
            return Pass()
        else:
            l=len(codeline)
            var, q = get_var(codeline, k, namespace)
            codeline = codeline[:k] + [var] + codeline[q:]
            if len(codeline)<l:                              #有變化才處理
                k -= 1
        k+=1
    def deal_single_operator(codeline,op_box,operator):
        k = 0
        while k < len(codeline):
            c = codeline[k]
            if c in op_box and type(codeline[k + 1]) != str:
                if c in ('+','-'):
                    if k==0 or type(codeline[k-1])==str:   #代表沒有加減運算
                        if c=='-':
                            get = operator(codeline[k + 1],c)
                            codeline = codeline[:k] + [get] + codeline[k + 2:]
                            k=-1
                        else:
                            codeline=codeline[:k]+codeline[k+1:]            #刪除"+"
                else:
                    get = operator(codeline[k + 1],c)
                    codeline = codeline[:k] + [get] + codeline[k + 2:]
                    k = -1
            k += 1
        return codeline
    def deal_single_operator_all(codeline,op_box,operator):     #將op後的參數全部打包
        k = 0
        while k < len(codeline):
            c = codeline[k]
            if c in op_box:
                value=parse_codeline(codeline[k+1:],namespace)
                get = operator(value,c)
                codeline = codeline[:k] + [get]
                k = -1
            k += 1
        return codeline
    def deal_operator(codeline,op_box,operator):
        k=0
        while k<len(codeline):
            c=codeline[k]
            if c in op_box:
                if k>0:
                    get=operator(codeline[k-1],codeline[k+1],c)
                    codeline=codeline[:k-1]+[get]+codeline[k+2:]
                    k-=1
            k+=1
        return codeline
    # 處理**
    k = 0
    while k < len(codeline):
        c = codeline[k]
        if c=='**':
            k+=1
            p=k
            while type(codeline[k])==str:k+=1    #可能取到負號或補數、正號
            obj=parse_codeline(codeline[p:k+1],namespace)
            get=Oper(codeline[p-2],obj,'**')
            codeline = codeline[:p-2] + [get] + codeline[k+1:]
            k=p-2
        k += 1
    #處理 ~,-
    codeline = deal_single_operator(codeline, ['~','-','+'],Deny)
    # 處理*/
    codeline=deal_operator(codeline,('*','/','%','//'),Oper)
    #處理+-
    codeline=deal_operator(codeline,('+','-'),Oper)
    # 處理<<>>
    codeline = deal_operator(codeline,('<<','>>'),Oper)
    # 處理&
    codeline = deal_operator(codeline, ['&'],Oper)
    # 處理^
    codeline = deal_operator(codeline, ['^'],Oper)
    # 處理|
    codeline = deal_operator(codeline,['|'],Oper)
    #處理==,!=
    k = 0
    while k < len(codeline):
        c = codeline[k]
        if c in ('==','!=','>','<','>=','<='):
            enebox=[codeline[k-1]]
            p=k
            while c in ('==','!=','>','<','>=','<='):
                enebox+=[c,codeline[k+1]]
                k+=2
                if k<len(codeline):
                    c=codeline[k]
                else:break
            get=Bool(enebox)
            codeline=codeline[:p-1]+[get]+codeline[k:]
            k=p-1
        k += 1
    # 處理in,is，in前面不能有for
    k = 0
    while k < len(codeline):
        c = codeline[k]
        if c=='for':
            k=next_element(codeline,k,['in'],end=True)    #要略過for後面的in
        elif c=='in':                # 處理in
            if k > 0:
                if codeline[k-1]=='not':
                    get=Deny(Tf(codeline[k+1], codeline[k-2], c),'not')
                    codeline = codeline[:k - 2] + [get] + codeline[k + 2:]
                    k -= 2
                else:
                    get = Tf(codeline[k+1], codeline[k-1], c)
                    codeline = codeline[:k - 1] + [get] + codeline[k + 2:]
                    k -= 1
        elif c=='is':              # 處理is
            if k > 0:
                if codeline[k+1]=='not':
                    get=Deny(Tf(codeline[k+2], codeline[k-1], c),'not')
                    codeline = codeline[:k -1] + [get] + codeline[k + 3:]
                else:
                    get = Tf(codeline[k+1], codeline[k - 1], c)
                    codeline = codeline[:k - 1] + [get] + codeline[k + 2:]
                k -= 1
        k += 1
    #處理not
    codeline=deal_single_operator(codeline,['not'],Deny)
    #處理and,or
    codeline = deal_operator(codeline,('and','or'),AndOr)
    #處理 A if B else C
    k = 0
    while k < len(codeline):
        c = codeline[k]
        if c=='if':                                                             #處理 A if B else C
            else_k=next_element(codeline,k,['else'])
            true_item=codeline[k-1]
            event_obj=parse_codeline(codeline[k+1:else_k],namespace)
            end_k=next_element(codeline,else_k,',',end=True)
            false_item=parse_codeline(codeline[else_k+1:end_k],namespace)
            get = sub_if_else(event_obj,true_item,false_item)
            codeline = codeline[:k-1] + [get] + codeline[end_k:]
            k = 0
        elif c=='for':              #處理for
           # print(codeline)
            #print('k:',k)
            express=codeline[k-1]
            in_k=next_element(codeline,k,['in'])
            vnames=parse_codeline(codeline[k+1:in_k],namespace,is_list=True)
            base_obj=codeline[in_k+1]
            if_k=next_element(codeline,in_k,['if'])
           # print('in_k:',in_k)
            if if_k==-1:      #沒有if
                if_obj=None
            else:if_obj=codeline[if_k+1]
           # print('取得:')
            #print(express,vnames,base_obj,if_obj)
            get=sub_for_loop(express,vnames,base_obj,if_obj,is_list)
            return get                                                #其他都別管了，直接return
        k += 1
    #處理return
    codeline=deal_single_operator(codeline,['yield'],Backtrack)
    codeline = deal_single_operator_all(codeline, ('return', 'raise'), Backtrack)
    codeline = deal_single_operator(codeline, ('del','global','nonlocal'),Var_declare)
    #刪除內部逗號
    k=0
    while k<len(codeline)-1:                       #可能是(a,)的tuple
        if codeline[k]==',':del codeline[k]
        else:k+=1
        if k==len(codeline)-1 and not is_list:break
    if len(codeline)>0 and codeline[-1]==',':         #codeline可能為[],()進來，長度為0
        if is_list:del codeline[-1]
        else:
            return Tuple(codeline)
    if is_list:
        return List(codeline)
    if len(codeline)==1:return codeline[0]
    return Tuple(codeline)
#解析程式區塊:
def parse_block(codelines,namespace=Namespace()):         #回傳[[A,B,C,...],[A,B,C,...],...]
    info=Info(namespace)       #local為所有變數，codelines為處理好的codelines
    #開始處理
    row=0
    Row = len(codelines)  # 總行數
    while row<Row:
        codeline=codelines[row]                 #取得一行
        if codeline[1]=='def':
            func_name = codeline[2].name  # Variable
            # 3是(，4開始是變數
            paramsbox = {}  # {param1:值,param2:值,...}
            k = 4
            n = len(codeline)
            pre=''        #前綴，可能為*或**
            while k < n:
                c = codeline[k]
                if c in ('*','**') and codeline[k-1] in ('(',','): #確保這不是運算符
                    pre=c
                elif type(c) == Var_name:  # 取得param
                    param_name=pre+c.name
                    paramsbox[param_name] = TFN(None)
                    if codeline[k + 1] == '=':  # 此參數存在默認值
                        p = k + 2
                        k = next_element(codeline, p, ',)')  # 碰到,或)調指索引默認值
                        paramsbox[param_name] =parse_codeline(codeline[p:k],namespace)
                    pre=''             #清空前綴
                k += 1
            q = next_codeline(codelines, row)
            pinfo =parse_block(codelines[row + 1:q],namespace=Namespace())   #Def內隔絕外部namespace
            fDef = Def(func_name, paramsbox,pinfo,namespace)
            fDef.local_vars=pinfo.locals
            #進行登記
            info.add_info('func',fDef)
            info.write(fDef,(codeline[0][2],codeline[0][1]))
            row=q-1
        elif codeline[1]=='class':
            classname=codeline[2].name
            if codeline[3]=='(':      #代表有繼承
                q=next_element(codeline,4,[')'])
                father=parse_codeline(codeline[4:q],namespace)
            else:
                father=None
            q=next_codeline(codelines,row)
            importer.class_n+=1
            class_esp=f'{classname}^{importer.class_n}'
            pinfo=parse_block(codelines[row+1:q],namespace=Namespace(f'<{class_esp}>'))           #在namespace狀態下，var轉為namespace.var, func轉為 namespace.func
            get=Class(classname,pinfo,namespace,class_esp,father)
            #進行登記
            info.add_info('class',get)
            info.write(get,(codeline[0][2],codeline[0][1]))
            row=q-1
        elif codeline[1]=='if':                                            #if,elif,else型態
            eventbox=[]
            else_codelines=[]
            orig_codelines=[]
            if_k=0
            while row<Row:
                codeline=codelines[row]
                if (codeline[1]=='if' and if_k==0) or codeline[1]=='elif':
                    if_k+=1
                    orig_codelines.append((codeline[0][2],codeline[0][1]))
                    event=parse_codeline(codeline[2:-1],namespace)         #事件真假值
                    if type(event)==Tuple:event=Integer(1)
                    q=next_codeline(codelines,row)
                    block=codelines[row+1:q]
                    pinfo=parse_block(block,namespace)
                    #進行登記
                    info.update(pinfo)
                    eventbox.append((event,pinfo.codelines))
                    row=q
                elif codeline[1]=='else':
                    orig_codelines.append((codeline[0][2],codeline[0][1]))
                    q = next_codeline(codelines, row)
                    block = codelines[row + 1:q]
                    pinfo=parse_block(block,namespace)
                    else_codelines=pinfo.codelines
                    # 進行登記
                    info.update(pinfo)
                    row=q
                    break
                else:break
            row-=1
            info.write(If_else(eventbox,else_codelines),orig_codelines)
        elif codeline[1]=='while':                                         #while型態
            event=parse_codeline(codeline[2:-1],namespace)
            if type(event) == Tuple: event = Integer(1)
            q = next_codeline(codelines, row)
            block = codelines[row + 1:q]
            pinfo= parse_block(block,namespace)
            while_codelines=pinfo.codelines
            # 進行登記
            info.update(pinfo)
            #--------------------------------------
            if q<Row and codelines[q][1]=='else':
                row=q
                q = next_codeline(codelines,row)
                block = codelines[row + 1:q]
                pinfo = parse_block(block, namespace)
                else_codelines=pinfo.codelines
                # 進行登記
                info.update(pinfo)
            else:
                else_codelines=[]
            info.write(While(event,while_codelines,else_codelines),(codeline[0][2],codeline[0][1]))
            row = q-1
        elif codeline[1]=='for':                                           #for,loop型態
            vnames=[]
            k=2            #開始清點參數
            while type(codeline[k])==Var_name or codeline[k]==',':
                if type(codeline[k])==Var_name:
                    var=Variable(codeline[k].name,namespace)
                    info.add_info('var',var)
                    vnames.append(var)
                k+=1
            #接下來k會指到 in
            base_obj=parse_codeline(codeline[k+1:-1],namespace)
            q=next_codeline(codelines,row)
            block = codelines[row + 1:q]
            pinfo = parse_block(block, namespace)
            fp_codelines=pinfo.codelines
            info.update(pinfo)
            if q<Row and codelines[q][1]=='else':
                row=q
                q = next_codeline(codelines,row)
                block = codelines[row + 1:q]
                pinfo = parse_block(block, namespace)
                else_codelines=pinfo.codelines
                # 進行登記
                info.update(pinfo)
            else:
                else_codelines=[]
            for_loop=For_loop(vnames,base_obj,fp_codelines,else_codelines)
            # 進行登記
            info.write(for_loop,(codeline[0][2],codeline[0][1]))
            row=q-1
        elif codeline[1]=='import':
            importer.need_load=1
            package_dict={}
            k,n=2,len(codeline)
            while k<n:
                if type(codeline[k])==Var_name:
                    module_name=codeline[k].name
                    while k+1<n and codeline[k+1]=='.':
                        module_name+=f'.{codeline[k+2].name}'
                        k+=2
                    as_name=None
                    if k+1<n and codeline[k+1]=='as':
                        as_name=codeline[k+2].name
                        var = Variable(as_name, namespace)
                        k+=2
                    else:
                        var=Variable(module_name.split('.')[0],namespace)
                    package_dict[module_name]=as_name   #(filepath,1/0)
                    #登記
                    info.add_info('var',var)
                k+=1
            import_obj=Import(package_dict,namespace)                  #{'abc.def.ghi':as_name,...} , namespace
            info.write(import_obj,(codeline[0][2],codeline[0][1]))
        elif codeline[1] == 'from':
            importer.need_load = 1
            object_names=[]
            module_name=codeline[2].name
            k = 2
            n = len(codeline)
            while k + 1 < n and codeline[k + 1] == '.':
                module_name += f'.{codeline[k + 2].name}'
                k += 2
            #-----------------------------------------
            k+=2                              #跳過import
            while k<n:
                if type(codeline[k])==Var_name:
                    object_name=codeline[k].name
                    if k+1<n and codeline[k+1]=='as':
                        deal=(object_name,codeline[k+2].name)
                        k+=2
                    else:deal=(object_name,object_name)
                    object_names.append(deal)
                    var=Variable(deal[1],namespace)
                    #登記
                    info.add_info('var',var)
                elif codeline[k]=='*':
                    object_names.append(('*','*'))
                k+=1
            from_import_obj = From_Import(module_name,object_names,namespace,info)
            info.write(from_import_obj,(codeline[0][2],codeline[0][1]))
        elif codeline[1]=='try':
            orig_codelines=[(codeline[0][2],codeline[0][1])]
            q=next_codeline(codelines,row)
            pinfo=parse_block(codelines[row+1:q],namespace)
            try_codelines=pinfo.codelines
            info.update(pinfo)
            except_objects=[]
            row=q
            while q<Row and codelines[q][1]=='except':
                codeline=codelines[q]
                orig_codelines.append((codeline[0][2],codeline[0][1]))
                k=next_element(codeline,1,(':','as'))
                if codeline[k]==':':
                    if k-1>1:                #代表中間有包東西
                        error_obj=parse_codeline(codeline[2:k],namespace)
                    else:                    #中間沒有包東西
                        error_obj=Variable('Exception',namespace)
                    as_name=None
                else:                              #代表是as
                    error_obj = parse_codeline(codeline[2:k], namespace)
                    as_name=codeline[k+1].name
                #開始收集codelines
                q=next_codeline(codelines,q)
                pinfo=parse_block(codelines[row+1:q],namespace)
                except_objects.append((error_obj,as_name,pinfo.codelines))
                info.update(pinfo)
                row=q
            if q<Row and codelines[q][1]=='else':
                codeline=codelines[q]
                orig_codelines.append((codeline[0][2],codeline[0][1]))
                q = next_codeline(codelines, q)
                pinfo=parse_block(codelines[row+1:q],namespace)
                else_codelines=pinfo.codelines
                info.update(pinfo)
            else:else_codelines=[]
            row=q
            if q<Row and codelines[q][1]=='finally':
                codeline=codelines[q]
                orig_codelines.append((codeline[0][2],codeline[0][1]))
                q = next_codeline(codelines, q)
                pinfo=parse_block(codelines[row+1:q],namespace)
                finally_codelines=pinfo.codelines
                info.update(pinfo)
            else:finally_codelines=[]
            #if len(except_objects)==0 and len(finally_codelines)==0:
             #   raise SyntaxError('invalid syntax')
            try_except=Try_Except(try_codelines,except_objects,else_codelines,finally_codelines,namespace)
            info.write(try_except,orig_codelines)
            row=q-1
        elif codeline[1]=='with':
            k=2
            q=next_element(codeline,k,['as',':'])
            call_obj=parse_codeline(codeline[k:q],namespace)
            importer.class_n += 1
            orig_as_name=Variable(f'%with_obj_{importer.class_n}',namespace)
            info.add_info('var', orig_as_name)
            if codeline[q]=='as':
                q2=next_element(codeline,q,[':'])
                as_name=parse_codeline(codeline[q+1:q2],namespace)
                if type(as_name)==Variable:
                    info.add_info('var', as_name)
            else:as_name=None

            q=next_codeline(codelines,row)
            pinfo=parse_block(codelines[row+1:q],namespace)
            info.update(pinfo)
            with_obj=With(call_obj,orig_as_name,as_name,pinfo.codelines,namespace)
            info.write(with_obj,(codeline[0][2],codeline[0][1]))
            row=q-1
        elif codeline[1]=='assert':
            k=next_element(codeline,1,[','],end=True)
            event=parse_codeline(codeline[2:k],namespace)
            if k<len(codeline) and codeline[k]==',':
                msg=parse_codeline(codeline[k+1:],namespace)
            else:msg=String('')
            assert_obj=Assert(event,msg)
            info.write(assert_obj, (codeline[0][2], codeline[0][1]))
        else:
            equal=next_element(codeline,0,('=','+=','-=','*=','/=','%=','//=','**=','<<=','>>=','&=','^=','|='),stop=['lambda'])                             #處理=
            op=codeline[equal]      #operator
            variablebox=[]                          #收集[(var1,var2,...),(var1,var2,...),...]
            s=1
            while equal>0:
                vars=parse_codeline(codeline[s:equal],namespace)
                if type(vars) in (Tuple,List):
                    for var in vars:
                        if type(var)==Variable:
                            info.add_info('var', var)
                elif type(vars)==Variable:
                    info.add_info('var', vars)
                s=equal+1
                #vars=[]
                #d=1
                #while d<equal:
                #    if codeline[d]==',':d+=1    #跳過逗號
                #    var,d=get_var(codeline,d,namespace)
                #    if type(var)==Variable:
                #        var.namespace=namespace
                #        info.add_info('var',var)
                #    vars.append(var)
                #    s=d+1
                variablebox.append(vars)
                equal=next_element(codeline,equal+1,'=',stop=['lambda'])
            target=parse_codeline(codeline[s:],namespace)                      #最尾端的物件
           # variablebox.append(results)
           # print('variablebox:',variablebox)
          #  print('\n\ncodeline:',codeline,'\n\n')
           # print('variablebox:',variablebox)
            if len(variablebox)==0:                                   #沒有等於
                info.write(target,(codeline[0][2],codeline[0][1]))
            #elif len(variablebox)==1 and type(variablebox[0]) not in (Tuple, List):  # 代表是單位元素
            #        object = Mov(variablebox[0], target, op)
            #        info.write(object, (codeline[0][2], codeline[0][1]))
            else:
                mov_obj=Multiple_Mov(variablebox,target,op)
                info.write(mov_obj, (codeline[0][2], codeline[0][1]))
                #if type(variablebox[0]) not in (Tuple, List):  # 代表是單位元素
                #    object = Mov(variablebox[0], target, op)
                #    info.write(object, (codeline[0][2], codeline[0][1]))
                #target = variablebox[-1]
                #if
                #for i in range(len(variablebox)-1):
                #    vars=variablebox[i]
                #
                #    if type(vars) not in (Tuple,List):   #代表是單位元素
                #        object = Mov(vars,target,op)
                #        info.write(object,(codeline[0][2],codeline[0][1]))
                #        if type(vars[0])==Variable:
                #            info.add_info('var',vars[0])
                #    else:
                #        if type(target)==FuncCall:
                #            info.write(target,('',0))
                #        for j in range(len(vars)):
                #            object=Mov(vars[j],target[j])
                #            info.write(object,(codeline[0][2],codeline[0][1]))
                #            if type(vars[j])==Variable:
                #                info.add_info('var',vars[j])
        row+=1
    return info
#外部匯入函數
class From_Import:
    def __init__(self,module_name,object_names,namespace,now_info):   #dict:name:(filepath,1/0,name2)，[(name,name2),(name,name2),...],
        self.module_name=module_name
        self.object_names=object_names
        self.namespace=namespace
        self.now_info=now_info
        self.orig_lines = ('', 0)
    def __str__(self):
        return f'<From {self.module_name} import {self.object_names}>'
    def write(self,codes):
        module_data = importer.get_path(self.module_name)
        codes.append('',self.orig_lines)
        if module_data[1]!=0:       #需要被載入
            tem_module_name=f'&tem_import_{len(codes)}'
            package_dict={self.module_name:tem_module_name}
            _import = Import(package_dict,self.namespace)
            _import.write(codes)  # 可使區域變數名失效
        codes.append(f'push $importer["{module_data[0]}"]')
        if self.namespace!='':
            self.namespace.write(codes)
            codes.append(f'push {self.namespace.location}')
            module_space='<esp+1>.'
            ispace='<esp+2>'
        else:
            module_space=''
            ispace='<esp+1>'
        for var in self.object_names:
            if var[0]=='*':             #import 內部所有物件
                info=importer.infos[module_data[0]]
                if info=='built-in':
                    locals=importer.module_dict[module_data[0]]
                else:
                    locals=info.locals
                for local_var in locals:
                    codes.append(f'mov {module_space}{local_var} {ispace}.{local_var}    ;import *')
                    variable=Variable(local_var,self.namespace)
                    self.now_info.add_info('var',variable)
            else:
                codes.append(f'mov {module_space}{var[1]} {ispace}.{var[0]}')
        if self.namespace!='':
            codes.append('$mov esp "+" 2')               #還原堆疊
        else:codes.append('inc esp')
class Import:
    def __init__(self,package_dict,namespace):   #package_dict:{'name':name2/None}    #名稱:檔案路徑，是否讀取，是否轉為其他名稱(as)
        self.package_dict=package_dict
        self.namespace=namespace
        self.orig_lines=('',0)
    def __str__(self):
        return f'<Import: {self.package_dict}>'
    def write(self,codes):         #如果check為True，則在已import狀態不進行import
        if self.namespace != '':
            self.namespace.write(codes)
            last_layer = f'{self.namespace.location}.'
        else:last_layer=''
        tem_layer=last_layer
        for module_name in self.package_dict:
            as_name = self.package_dict[module_name]
            mbox=module_name.split('.')
            for m in range(len(mbox)):
                dealname='.'.join(mbox[:m+1])
                deal_data=importer.get_path(dealname)    #,[filepath,0:已處理/1:未處理]
                p = len(codes)
                namespace_stack_name = f'&{mbox[m]}_{p}'  # 此名為唯一，替換參數堆疊名
                if deal_data[1] == 0:  # 已經被處理
                    codes.append(f'mov {namespace_stack_name} $importer["{deal_data[0]}"]')
                    if as_name == None:                                                   # 代表直接引入名稱
                        codes.append(f'mov {last_layer}{mbox[m]} {namespace_stack_name}')
                    elif m == len(mbox) - 1:                                              #引入as_name
                        codes.append(f'mov {tem_layer}{as_name} {namespace_stack_name}')
                    else:
                        codes.append('pass')
                    last_layer = f'{namespace_stack_name}.'
                elif deal_data[1]==2:       #代表是外部函數
                    importer.loaded.append(deal_data[0])
                    codes.append(f'module {namespace_stack_name} "{deal_data[0]}"')
                    codes.append(f'mov $importer["{deal_data[0]}"] {namespace_stack_name}')
                    if as_name == None:                                                   # 代表直接引入名稱
                        codes.append(f'mov {last_layer}{mbox[m]} {namespace_stack_name}  ;定義{last_layer}{mbox[m]}')
                    elif m == len(mbox) - 1:                                              #引入as_name
                        codes.append(f'mov {tem_layer}{as_name} {namespace_stack_name}')
                    importer.infos[deal_data[0]] ='built-in'
                    last_layer = f'{namespace_stack_name}.'
                elif deal_data[1]==1:       #未處理
                    importer.loaded.append(deal_data[0])    #-----------------------------登記已載入
                    codes.append(0)
                    codes.append(f'mov $importer["{deal_data[0]}"] {namespace_stack_name}')
                    if as_name == None:                                                   # 代表直接引入名稱
                        codes.append(f'mov {last_layer}{mbox[m]} {namespace_stack_name}  ;定義{last_layer}{mbox[m]}')
                    elif m == len(mbox) - 1:                                              #引入as_name
                        codes.append(f'mov {tem_layer}{as_name} {namespace_stack_name}')
                    else:
                        codes.append('pass')
                    #--------------------------------------------------------------------開始編譯
                    codes.add_newtab(deal_data[0])
                    code = open(deal_data[0], 'r', encoding=importer.encoding).read()
                    codelines = parse_code(code)
                    info = parse_block(codelines)    #當作獨立程式碼進行解析
                    for obj in info.codelines:
                        obj.write(codes)
                    importer.infos[deal_data[0]] = info   #登記info資訊
                    codes.del_newtab()
                    #--------------------------------------------------------------------編譯結束
                    #-------------------------編寫參數替換字典
                    params_dict={}
                    box=[]
                    var_k=0
                   # print('info locals:',info.locals)
                    for var in info.locals:
                        if var not in box:
                            box.append(var)
                            params_dict[var]=f'<{namespace_stack_name}+{var_k}>'          #name:order
                            var_k+=1
                    var_text=','.join(box)
                    codes[p] = f'namespace {namespace_stack_name} "{namespace_stack_name}" "{var_text}"'
                    #--------------------------
                    #-------------------------------------------------------------進行參數替換
                    def get_name(string):
                        sp = '.[ ;'
                        k, n = 0, len(string)
                        while k < n:
                            if string[k] in sp:
                                return string[:k], string[k:]
                            k += 1
                        return string, ''
                    def parse_line(line):
                        box = []
                        k, n = 0, len(line)
                        while k < n:
                            p = k
                            if line[p] in ('"', "'"):
                                c = line[p]
                                k = p + 1
                                while line[k] != c:
                                    if line[k] == '\\': k += 1
                                    k += 1
                                k += 1
                            while k < n and line[k] != ' ': k += 1
                            box.append(line[p:k])
                            k += 1
                        return box
                    p+=3           #跳過自己宣告的名稱，(小心自己的參數不要被替換)
                    for i in range(len(codes) - p):
                        line=codes[p+i]
                        if '"' in line or "'" in line:
                            deal=parse_line(line)
                        else:
                            deal = codes[p + i].split(' ')
                        for j in range(len(deal)):  # 將自己的變數做替換
                            if j == 0 or deal[j] == '': continue       #除了命令和空，其餘檢查
                            if deal[j][0] in ('"', "'"):
                                continue
                            if deal[j][0] == ';':  # 代表是註解
                                break
                            var, back = get_name(deal[j])
                            if var in params_dict:
                                deal[j]=params_dict[var]+back
                        codes[p + i] = ' '.join(deal)
                    #----------------------------------------------------------------------參數替換結束
                    last_layer=f'{namespace_stack_name}.'
            last_layer=tem_layer
def Read_ex_func():
    def deal_line(line):
        line_dict={}
        n=len(line)
        k=0
        while k<n:
            while k<n and line[k] in ', ':k+=1
            q=next_element(line,k,'( ,',end=True)
            element=line[k:q]
            while q<n and line[q]==' ':q+=1
            if q<n and line[q]=='(':    #代表還有子類別
                q2=next_element(line,q+1,')')
                line_dict[element]=deal_line(line[q+1:q2])
                k=q2+1
            elif q>=n or line[q]==',':
                line_dict[element]={}     #該元素沒有子類別
                k=q+1
            else:raise Exception('unknow')
        return line_dict
    module_dict = {}  # module_name:[子類別名稱,...]
    ex_func_content = open(getcwd() + '\\apython\\ex_func.py', 'r', encoding='utf-8').read().split('\n')
    for line in ex_func_content:
        p = next_element(line, 0, ' #', end=True)
        if p < len(line) and line[p] == ' ':
            k = next_element(line, p + 1, ' #', end=True)
            module_name = line[p + 1:k]
            q = next_element(line, k + 1, '#')
            if q > k:                             #子類別存在
                module_dict[module_name]=deal_line(line[q + 1:])
            else:module_dict[module_name]={}
    return module_dict
class Importer:          #模組匯入管理器
    def __init__(self):
        self.module_dict=Read_ex_func()
        self.reset()
    def __get_module(self,module_name):        #獲取該資料夾內所有可import模組
        def get_module(nowfolder,k):      #目前工作資料夾，fbox的index
            if k==len(fbox)-1:
                filepath=''
                for file in listdir(nowfolder):
                    road = f'{nowfolder}/{file}'.replace('\\', '/')
                    if isfile(road) and file.split('.')[-1] == 'py' and filepath=='' and file[:-3]==fbox[k]:
                        filepath = road
                    elif isdir(road) and '__init__.py' in listdir(road) and file==fbox[k]:  # 如果有資料夾和py檔同類，取資料夾
                        filepath= road + '/__init__.py'
                return filepath
            return get_module(f'{nowfolder}\\{fbox[k]}',k+1)
        fbox=module_name.split('.')
        return get_module(self.work_folder,0)
    def get_path(self,module_name):          #import後加[同目錄檔案名]，只能是[.py]或[內部有__init__的資料夾]
        if module_name in self.module_dict:
            if module_name in self.loaded:
                return [f'{module_name}',0]
            return [f'{module_name}',2]      #2代表built-in
        else:
            filepath=self.__get_module(module_name)
            if filepath in self.loaded:   #已經載入過
                return [filepath,0]
            if filepath=='':    #代表找不到
                return [f'{module_name}', 2]  # 2代表built-in，創建一個空的Ex_module
            #print('filepath:',filepath,module_name)
            return [filepath,1]
    def reset(self,pyfile='',encoding='cp950'):
        self.need_load=0
        self.encoding=encoding
        py_file_name=pyfile.replace('\\','/').split('/')[-1]
        if pyfile==py_file_name:
            self.work_folder = getcwd()
        else:
            self.work_folder=pyfile[:-len(py_file_name)-1]
        self.nowpath = pyfile
        self.loaded=[]
        self.infos={}                     #path:info
        self.class_n = 0  # 類別管理
importer=Importer()
#打包者
class Packager:
    def __init__(self,encoding='cp950'):
        self.code=Code()
        self.encoding=encoding
        self.REPL_box=[True,[]]
        importer.reset('module', self.encoding)
        self.add_need_load = 0
    def load(self,filepath):
        ftype = filepath.split('.')[-1]
        filename = filepath.replace('\\', '/').split('/')[-1]
        work_folder = filepath[:-len(filename)]
        if len(work_folder) > 0:
            chdir(work_folder)
            filepath = filename
        if 'ec' == ftype:
            code = open(filepath, 'r').read()
            self.code.code = code.split('\n')
        else:
            code = open(filepath, 'r',encoding=self.encoding).read()
            self.code.add_newtab(filepath)
            importer.reset(filepath,self.encoding)
            self.add_need_load=0
            #--------------------------------------------------
            self.load_code(code)
            #--------------------------------------------------
            self.code.del_newtab()
    def REPL(self,cmd,one_line=True):               #單行程式碼
        self.code.add_newtab('REPL')
        if cmd=='':
            if len(self.REPL_box[1])>0:
                code='\n'.join(self.REPL_box[1])
              #  print('code:',code)
                self.load_code(code)
            self.REPL_box=[True,[]]
        else:
            codelines = parse_code(cmd)
            if one_line:
                codeline=codelines[0]
                if codeline[1] in ('def','class','if','while','for','try','with'):
                    self.REPL_box[0]=False     #False 代表不執行
                    self.REPL_box[-1].append(cmd)
                elif not self.REPL_box[0]:
                    self.REPL_box[-1].append(cmd)
                else:
                    self.load_code(cmd,repl=True)
            else:
                self.load_code(cmd, repl=True)
        self.code.del_newtab()
        return self.REPL_box[0]    #是否執行
    def load_code(self,code,repl=False):     #直接輸入代碼
        codelines = parse_code(code)
        self.info = parse_block(codelines)
        if importer.need_load and self.add_need_load == 0:
            self.code.append('mov $importer [dict]')
            self.add_need_load = 1
        if len(self.info.codelines)>0:
            for obj in self.info.codelines:
                obj.write(self.code)
            if repl and type(self.info.codelines[-1]) in (Integer,Float,String,Byte,Variable,SubVariable,IndexVariable,List,Tuple,Dict,Set,FuncCall,Oper,Tf,AndOr,Deny,Bool):
                if type(self.info.codelines[-1])!=FuncCall or self.info.codelines[-1].name!='print':
                    self.code.append(f'repl_print {self.info.codelines[-1].location}')
    def __load_easy_code(self,ec_file):
        code = open(ec_file, 'r').read()
        self.code.code=code.split('\n')
