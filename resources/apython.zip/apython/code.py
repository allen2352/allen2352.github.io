from apython.executer import Undefine
class Code:
    def __init__(self):
        self.tem=('AX','BX')
        self.clean()
    def clean(self):
        self.code=[]
        self.comments=[]
        self.simplify=0
        self.base_num=[]      #基底數值(依據檔案) #(namecode,[0,0,0])
        self.base_esp=-1
        self.file_ed=[]
        self.base=(0,0,0)
    def __apply_file(self,name):
        if name not in self.file_ed:
            self.file_ed.append(name)
        return self.file_ed.index(name)
    def add_newtab(self,name):
        namecode=self.__apply_file(name)
        self.base_num.append((namecode,[0]))
    def del_newtab(self):
        del self.base_num[-1]
    def add_tab(self):
        #print('add_tab')
        pass
       # self.base_num[self.base_esp][1].append(0)
    def del_tab(self):
        pass
        #print('del_tab')
      #  del self.base_num[self.base_esp][1][-1]
    def get_error_msg(self,row):    #獲取錯誤訊息
        if row<len(self.comments):
            cmt_n=self.comments[row][0][2]
            cmt=self.comments[cmt_n]
       #  print(self.comments[cmt_n-1],self.comments[cmt_n],self.comments[cmt_n+1])
            return {'file':self.file_ed[cmt[0][0]],'row':cmt[0][1],'code':cmt[1]}
        else:
            return {'file':'','row':row,'code':self.code[row]}
    def append(self,command,comment=None,simplify=0):
        if comment != None and comment[0]!='':
           # print(command,comment)
            cmt, row = comment
            self.base_num[self.base_esp][1][-1] = row
            real_row = sum(self.base_num[self.base_esp][1])  # 實際在程式碼中的行
            namecode=self.base_num[self.base_esp][0]
            self.base = (namecode,real_row,len(self.comments))
            self.comments.append((self.base,cmt))     #(檔案名稱，第幾行)，原始命令
        if command=='':return
        if self.simplify==0 and simplify==0 and comment==None and len(self.code)>0 and type(command)==str and type(self.code[-1])==str:
            last=self.code[-1].split(' ')
            cmd=command.split(' ')
            if last[0]=='push' and cmd[0]=='pop':
                del self.code[-1]
                if last[1]!=cmd[1]:
                    self.code.append(f'mov {cmd[1]} {last[1]}')
            elif last[0] == 'pop' and cmd[0] == 'push' and last[1]==cmd[1]:
                del self.code[-1]
                if last[1] not in self.tem:
                    self.code.append(f'mov {last[1]} <esp+1>')
            elif last[0]=='mov' and cmd[0]=='push' and last[1]==cmd[1] and last[1] in self.tem:
                del self.code[-1]
                self.code.append(f'push {last[2]}')
            elif last[0]=='pop' and cmd[0]=='mov' and last[1]==cmd[2] and last[1] in self.tem:
                del self.code[-1]
                self.code.append(f'pop {cmd[1]}')
            elif last[0]=='mov' and cmd[0]=='mov' and last[1]==cmd[2] and last[2]==cmd[1]:
                pass
            elif last[0]=='mov' and cmd[0]=='mov' and last[1]==cmd[2] and last[1] in self.tem:      #下一行可能是別人跳的，因此無法簡化
                del self.code[-1]
                self.code.append(f'mov {cmd[1]} {last[2]}')
            elif cmd[0] in ('add','sub') and cmd[2]=='0':
                pass
            else:
                self.code.append(command)
        else:
            self.code.append(command)
        if self.simplify>0:self.simplify-=1
        self.simplify+=simplify
        if len(self.code) > len(self.comments):
            self.comments.append((self.base, ''))
    def display(self,now_ip=-1):
        print('--------------------------------')
        Row=len(self.code)
        if now_ip<Row and now_ip!=-1 and now_ip<len(self.comments):
            now_row=self.comments[now_ip][0][2]
        else:now_row=Row
        for i in range(Row):
            statement=(' ● ' if now_ip == i else '   ')+str(i)+ ' ' * (4 - len(str(i)))+'|'+self.code[i]
            #if now_ip==i:
             #   statement="[93m"+statement+"[0m"
            space=' '*70
            cmt = self.comments[i]
            if cmt[1]!='':   #要match到才會print
                orig_code=(' ● ' if i== now_row else '   ')+str(cmt[0][1])+ ' ' * (4 - len(str(i)))+'| '+cmt[1]
            else:orig_code=''
            print(space+orig_code[:40]+'\r'+statement)
            if i>100:
                print('row more than 100')
                break
        print('--------------------------------')
    def parse_code(self,start_row=0,reset=True):                    #解析為適合執行的格式
        def deal_string(codeline,k):  # k為',"的位置
            c = codeline[k]
            k+=1
            p = k
            while True:
                if codeline[k] == '\\':
                    k += 1
                elif codeline[k] == c:
                    break
                k += 1
            return c+codeline[p:k]+c,k
        def login_item(item):
            if item not in self.data_dict:
                if len(self.data)-self.data_n<100:
                    self.data+=[Undefine()]*1024
                self.data_dict[item]=self.data_n
                if item[0] in ('"',"'"):
                    string=item[1:-1]
                    if item[0]=='"':
                        rbox = {'\\n':'\n','\\r':'\r','\\t':'\t','\\a':'\a','\\b':'\b','\\f':'\f','\\v':'\v','\\"':'"','\\\'':'\'','\\\\':'\\'}
                        k,n=0,len(string)
                        text_box=[]
                        while k<n:
                            if string[k]=='\\' and string[k:k+2] in rbox:
                                text_box.append(rbox[string[k:k+2]])
                                k+=1
                            else:text_box.append(string[k])
                            k+=1
                        string=''.join(text_box)
                    self.data[self.data_n]=string
                elif item[0] in '0123456789-':
                    if '.' in item:self.data[self.data_n]=float(item)
                    else:self.data[self.data_n]=int(item)
                self.data_n+=1
            return self.data_dict[item]
        cmd_dict={'mov':(0,2),
                  '$mov':(1,3),               #$mov AX op BX  #AX+=BX
                  'oper':(2,3),               #oper AX op BX  #AX=AX+BX             #'add','sub','mul','div','pow','quo','rem','address'
                  'cmp':(3,2),                #ZR=AX-BX
                  'jmp':(4,1),               #jmp ip
                  '$jmp':(5,2),              #$jmp ip ">"  #ZR大於0則跳
                  'call':(6,1),              #呼叫函數
                  'push':(7,1),'pop':(8,1),
                  'tf':(9,3),                 #tf AX "ctn" BX    #判斷真假      'ctn','equ','Ctn','is',
                  'inc':(10,1),'dec':(11,1),
                  '$oper':(12,2),              #$oper AX "op" BX                       #'neg','NEG','not'
                  'ex_func':(13,3),           #ex_fuunc AX "str" BX  #AX=str(BX)       #'iter'
                  'try':(14,1),'finally':(15,1),'raise':(16,1),'error':(17,1),
                  'Generator':(18,-1),'Yield':(19,0),'fetch':(20,2),
                  'stop':(21,0),'end':(22,-1),
                  'byte':(23,2),'del':(24,3),'Function':(25,-1),
                  'global':(26,0),'namespace':(28,3),'pass':(26,0),     #global不予理會
                  '*args':(29,3),'**kwargs':(30,3),'module':(31,2),
                  'type':(32,2),'name':(33,2),'print':(34,1)}
        #-----------------------------------------------------
        if reset:
            self.data_dict={'AX':0,'BX':1,'CX':2,'DX':3,'ip':4,'esp':5,'sp':6,'ZR':7,'TF':8,
                       '*args':9,'**kwargs':10,'$Exception':11,
                       'True':12,'False':13,'None':14,'$Inheritance':15}
            self.data_n = len(tuple(self.data_dict))
            self.data=[None]*self.data_n
            self.data+=[Undefine()]*1024
            self.data[12]=True
            self.data[13]=False
            self.data[14]=None
            self.data[15]=None
            self.parse_codes=[]
        else:
            self.data_n = len(tuple(self.data_dict))                              #data開始登記的位置
        #print('data_n:',self.data_n)
        ROW=len(self.code)-1
        start_row-=1
        #print('code:',self.code)
        #print('start_row:',start_row)
        while start_row<ROW:
            start_row+=1
            line=self.code[start_row]
            if line=='':          #line為空
                self.parse_codes.append([26])     #不予理會空line
                continue
            op=line.split(' ')[0]
            cmd=cmd_dict[op]
            deal = [cmd[0]]
            k=len(op)+1
            fetch_k=0
            while fetch_k<cmd[1] or (cmd[1]==-1 and k<len(line)):
                if line[k] in ('"',"'"):                       #必定為字串
                    string,k=deal_string(line,k)          #k為"的位置
                    if fetch_k==1:
                        if op in ('$mov','oper'):
                            op_num=('+','-','*','/','**','%','//','<<','>>','&','^','|').index(string[1:-1])
                            deal.append((0, login_item(str(op_num))))
                        elif op=='tf':
                            op_num = ('in','equ','Ctn','is').index(string[1:-1])
                            deal.append((0, login_item(str(op_num))))
                        elif op=='$oper':
                            op_num = ('not','-','~').index(string[1:-1])
                            deal.append((0, login_item(str(op_num))))
                        else:
                            deal.append((0, login_item(string)))
                    else:
                        deal.append((0,login_item(string)))
                    k+=2
                elif line[k] in '0123456789-':                  #必定為數值
                    k2=k
                    while k2<len(line) and line[k2] in '-0123456789.':k2+=1
                    number=line[k:k2]
                    deal.append((0,login_item(number)))
                    k=k2+1
                elif line[k]=='[':                    #此處為[value]類型，非 variable[value] 類型，因此[]中只能是int,dict,class
                    k2=line.index(']',k)
                    value=line[k+1:k2]
                    if value=='dict':                   #11:dict
                        deal.append((11,-1))
                    elif value=='class':                #13:class
                        deal.append((13,-1))
                    elif value=='func':                 #16:func
                        deal.append((16,-1))
                    else:                                #10:list
                        deal.append((10,int(value)))
                    k=k2+2
                elif line[k]=='(':             #要求[number]        #12:tuple
                    k2=line.index(')',k)
                    deal.append((12,int(line[k+1:k2])))   #tuple宣告
                    k=k2+2
                else:
                    typebox=''
                    if line[k]=='<':
                        k2=line.index('>',k)
                        name=line[k+1:k2]
                        if '+' in name:
                            c=name.split('+')
                            result=[c[0],int(c[1])]
                        else:result=[name,0]
                        k2+=1
                        if result[0]=='esp':
                            typebox+='1'                                   #<esp+k>:1
                            result[0] = login_item(result[0])
                        else:
                            #result[0] = login_item(result[0])            #此處不進行登記，因為func_name要作為key使用
                            typebox='2'                                   #<func+k>:2
                    else:                                                  #name:0
                        k2=k
                        while k2<len(line) and line[k2] not in '[ .':k2+=1
                        result=[line[k:k2]]
                        typebox+='0'
                        result[0] = login_item(result[0])
                    k=k2+1
                    #----------------
                    #[],{},()指令

                    if k2 < len(line) and line[k2] == '.':             # 代表是子屬性，'.':0
                        k2+=1
                        while k2 < len(line) and line[k2] not in '[ .': k2 += 1
                        attr=line[k:k2]
                        result.append(attr)
                        typebox+='0'
                        k=k2+1
                    if k2<len(line) and line[k2]=='[':                        #代表是索引，[key]:1
                        if line[k2+1] in ('"', "'"):           #內容是字串
                            value, k3 = deal_string(line,k2+ 1)
                            result.append(login_item(value))
                            k3+=1            #k3移動到]的位置
                        else:
                            k3=line.index(']',k2)
                            value=line[k2+1:k3]
                            result.append(login_item(value))
                        typebox += '1'
                        k=k3+2
                    if typebox=='0':                    #純名字                #name
                        deal.append((0,result[0]))
                    elif typebox=='00':                                       #name.attr
                        deal.append((1,result[0],result[1]))
                    elif typebox=='01':                                       #name[key]
                        deal.append((2, result[0], result[1]))  # name[key]
                    elif typebox=='1':                                       #<esp+k>
                        deal.append((3, result[0], result[1]))
                    elif typebox=='10':                                       #<esp+k>.attr
                        deal.append((4,result[0],result[1],result[2]))
                    elif typebox=='11':                                       #<esp+k>[key]
                        deal.append((5,result[0],result[1],result[2]))
                    elif typebox=='2':                                       #<func+k>
                        deal.append((6, result[0], result[1]))
                    elif typebox=='20':                                       #<func+1>.attr
                        deal.append((7,result[0],result[1],result[2]))
                    elif typebox=='21':                                       #<func+k>[key]
                        deal.append((8,result[0],result[1],result[2]))
                fetch_k+=1
            self.parse_codes.append(deal)
        return self.parse_codes,self.data,self.data_dict
    def __len__(self):
        return len(self.code)
    def __getitem__(self, item):
        return self.code[item]
    def __setitem__(self, key, value):
        self.code[key]=value
    #def __delitem__(self, key):        #本程式自動優化，勿del
     #   del self.code[key]