from apython.built_in import *
class Undefine:
    def __init__(self):
        self.Fail = "[91m"
        self.RESET = "[0m"
    def __str__(self):
        return f'{self.Fail}<undefined>{self.RESET}'
class class_obj:
    def __init__(self,ram):
        self.ram=ram
        self.atype=None
        self.vars={}
        self.print_lock=0        #0:進行運算，1:直接回傳<The class obj>
    def __str__(self):
        if self.print_lock==0 and '__str__' in self.vars:
            return self.ram.call_obj_function(self,[],'__str__')
        return '<class_obj>'
    def __add__(self, other):
        if self.print_lock==0 and '__add__' in self.vars:
            return self.ram.call_obj_function(self,[other],'__add__')
    def __sub__(self, other):
        if self.print_lock==0 and '__sub__' in self.vars:
            return self.ram.call_obj_function(self,[other],'__sub__')
    def __len__(self):
        if self.print_lock==0 and '__len__' in self.vars:
            return self.ram.call_obj_function(self,[],'__len__')
    def __setitem__(self, key, value):
        if self.print_lock==0 and '__setitem__' in self.vars:
            return self.ram.call_obj_function(self,[key,value],'__setitem__')
    def __getitem__(self, item):
        if self.print_lock==0 and '__getitem__' in self.vars:
            return self.ram.call_obj_function(self,[item],'__getitem__')
    def __contains__(self, item):
        if self.print_lock == 0 and '__contains__' in self.vars:
            return self.ram.call_obj_function(self, [item], '__contains__')
    def __next__(self):
        if self.print_lock == 0 and '__next__' in self.vars:
            return self.ram.call_obj_function(self, [], '__next__')
        elif '__getitem__' in self.vars:
            self.error=False
            self.item_k += 1
            return self.__getitem__(self.item_k)
    def __iter__(self):
        self.item_k=-1
        if self.print_lock == 0 and '__iter__' in self.vars:
            return self.ram.call_obj_function(self, [], '__iter__')
        return self
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.print_lock == 0 and '__exit__' in self.vars:
            return self.ram.call_obj_function(self, [exc_type,exc_val,exc_tb], '__exit__')
    def __call__(self, *args, **kwargs):
        if self.print_lock == 0 and '__call__' in self.vars:
            return self.ram.call_obj_function(self, args, '__call__',kwargs)
    def __del__(self):
        if self.print_lock == 0 and '__del__' in self.vars:
            return self.ram.call_obj_function(self, [], '__del__')
    def __eq__(self, other):
        if self.print_lock == 0 and '__eq__' in self.vars:
            return self.ram.call_obj_function(self, [other], '__eq__')
class Func:
    def __init__(self,ram,ip,class_obj,func_var,stack_len,import_funcs):
        self.name='Function'
        self.atype='Function'
        self.ram=ram
        self.vars={'ip':ip,'class_obj':class_obj}
        self.stack_name=func_var
        self.stack_len=stack_len
        self.import_funcs=import_funcs
    def __str__(self):
        return str(self.name)
    def __call__(self, *args, **kwargs):                 #由內部或外部函數(ex_function)呼叫
        self.ram.data[self.ram.args_location] = args
        self.ram.data[self.ram.kwargs_location] = kwargs
        result=self.ram.func_run(self.vars['ip'],self.vars['class_obj'],self.stack_name,self.stack_len,self.import_funcs)    #ip固定，class_obj和ex_box都是位址定義，因此不用接受返還值
        return result
class generator:
    def __init__(self,ram,start_ip,import_funcs):
        self.ram=ram
        self.next_ip=start_ip
        self.import_funcs = import_funcs
        #self.params=params
        #self.locals=locals
        self.ex_stack=[]                 #程式中斷時可能有超出的堆疊
        #self.ex_box=ex_box                   #父函數們的資料內容，[(loc,stack),...]
        #self.orig_local_len=len(locals)
        #self.base_location=base_location
        self.enter=0                           #當enter=1時，代表已經遭遇了stopiteration
        self.next_lock=True                    #在send前需要先啟動next
        self.send=False
        self.send_obj=None
        self.finally_box=[]                    #如果程式在有finally的try中跳出，並且自己被del，則依序執行finallybox中的內容
        def send(value):
            if not self.next_lock:
                self.send=True
                self.send_obj=value
                return self.__next()
            raise TypeError("can't send non-None value to a just-started generator")
        self.vars={'send':send}
    def __str__(self):
        return '<generator_obj>'
    def __getitem__(self, item):
        return self.__next()
    def __next__(self):
        self.next_lock=False
        if self.send:
            self.send_obj =None               #在啟用send之後，必定要傳給AX值
        return self.__next()
    def __next(self):
        if self.enter==1:    #代表之前進入卻之敗了
            raise StopIteration
        else:
            self.enter=1
            if not self.send:
                next_obj,self.ex_stack,yield_result,base_esp= self.ram.yield_run(self.next_ip,self.ex_stack, self.import_funcs)
            else:
                next_obj, self.ex_stack, yield_result, base_esp = self.ram.yield_run(self.next_ip, self.ex_stack,self.import_funcs,send_obj=self.send_obj)
             #print('取得結果:',yield_result)
           # print('ex_stack',self.ex_stack)
            if next_obj!=None:
                self.next_ip,finally_box=next_obj
                for f_ip in finally_box:
                    if f_ip[0]>-1:
                        ex_stack_num=base_esp-f_ip[1]       #基底堆疊量與進入try時堆疊量的差
                        self.finally_box.append([f_ip[0],ex_stack_num])
                    else:
                        for fip in self.finally_box:          #同個finally就刪掉
                            if fip[0]==abs(f_ip[0]):
                                self.finally_box.remove(fip)
                                break
                self.enter=0
                return yield_result
            raise StopIteration
    def __del__(self):
       # print('del:',self.finally_box)
        for f_ip in self.finally_box:
           # print(f_ip)
            #將堆疊同位
            self.ram.data[self.ram.ip]= f_ip[0]+1
            # --------------------------------------------
            tem_stacks = {}
            for func_name in self.import_funcs:
                tem_stacks[func_name] = self.ram.func_stack[func_name]
                self.ram.func_stack[func_name] = self.import_funcs[func_name]
            for i in range(f_ip[1]):    #原始local量+ex_stack
                self.ram.push(self.ex_stack[i])
            #self.ram.data[self.base_location] = self.ram.data[self.ram.esp]        #<stack_esp>
            self.ram.push(None)           #為了符合finally的堆疊格式
            self.ram.push(1)
            # --------------------------------------------
            #self.ram.tf=1
            try:
                self.ram.one_run('finally yield run')
            except Exception as e:
                print(e)
            finally:
                for func_name in tem_stacks:
                    self.ram.func_stack[func_name] = tem_stacks[func_name]
         #   print('run finish')
def fetch_error(e):
    stype = str(type(e))
    k = stype.index("'")
    k2 = stype.index("'", k + 1)
    return stype[k + 1:k2]
def atype(obj):
    if type(obj)==class_obj:
        return obj.atype
    elif type(obj)==Func:
        return f"<class '__main__.{obj.name}'>"
    return type(obj)     #string,list,int,tuple,...
def aprint(*args,**kwargs):
    text_box=[]
    for obj in args:
        text_box.append(str(obj))
    text=' '.join(text_box)
    if 'end' in kwargs:
        tatal_output.append(text+kwargs['end'])
    else:
        tatal_output.append(text+'\n')
tatal_output=[]
built_in_functions=[abs,all,any,ascii,bin,bool,breakpoint,bytearray,bytes,callable,chr,classmethod,compile,complex,
                    delattr,dict,dir,divmod,enumerate,eval,exec,filter,float,format,frozenset,getattr,globals,hasattr,hash,hex,
                    id,input,int,isinstance,issubclass,iter,len,list,locals,map,max,memoryview,min,next,object,oct,open,ord,pow,print,property,
                    range,repr,reversed,round,set,setattr,slice,sorted,staticmethod,str,sum,super,tuple,vars,zip]
Error_class=[NameError,IndexError,TypeError,SyntaxError,ValueError,KeyboardInterrupt,AssertionError,Exception,RecursionError,
             KeyError,ZeroDivisionError,AttributeError,IndentationError ,UnboundLocalError]
else_built_in=[StopIteration,StopAsyncIteration,SyntaxWarning,FileNotFoundError,ModuleNotFoundError]
bifs={
   # 'help':help,             #打包成exe時，help會無效
    'IOError':IOError,
    'type':atype       #help沒有name,IOError的name為OSError
      }
for key in built_in_functions+Error_class+else_built_in:
    bifs[key.__name__]=key
class Executer:                                               #載入程式碼與記憶體
    def __init__(self,code):
        self.code=code
        self.ex_function=bifs.copy()
        self.run_layer=[]
        self.func_stack={}
    def set(self,var_name,value):
        location=self.data_dict[var_name]
        self.data[location]=value
    def push(self, value):
        self.esp_stack[self.data[self.esp]] = value
        self.data[self.esp]-= 1
    def pop(self):
        self.data[self.esp]+= 1
        return self.esp_stack[self.data[self.esp]]
    def login(self,var_name):
        if var_name in self.var_dict:
            return self.var_dict[var_name]
        self.var_dict[var_name]=self.used_size
        self.used_size+=1
        return self.used_size-1
    def get_var_location(self,var_name):
        return self.var_dict[var_name]
    def pushaw(self):
        for i in range(5):                                #儲存AX,BX,CX,DX,ip進堆疊
            self.esp_stack[self.data[self.esp]]=self.data[i]
            self.data[self.esp]-=1
    def popaw(self):
        for i in range(5):                                #回復AX,BX,CX,DX,ip進堆疊
            self.data[self.esp] += 1
            self.data[4-i]=self.esp_stack[self.data[self.esp]]
    def __setitem__(self,location, value):
     #   print(location,value)
        if location[0]==0:                                                       #name
            self.data[location[1]]=value
        elif location[0]==1:                                                        #name.attr
            self.data[location[1]].vars[location[2]]=value
        elif location[0]==2:                                                             #name[key]
            self.data[location[1]][self.data[location[2]]]=value
        #-----------------------------------------------------------------------------------------------
        elif location[0]==3:                                                             #<esp+k>
            self.esp_stack[self.data[location[1]]+location[2]]=value
        elif location[0]==4:                                                            #<esp+k>
            self.esp_stack[self.data[location[1]] + location[2]].vars[location[3]]=value
        elif location[0]==5:                                                              #<esp+k>[key]
            self.esp_stack[self.data[location[1]]+location[2]][self.data[location[3]]]=value
        # -----------------------------------------------------------------------------------------------
        elif location[0]==6:                                                             #<func+k>
            self.func_stack[location[1]][location[2]]=value
        elif location[0]==7:                                                            #<func+k>
            self.func_stack[location[1]][location[2]].vars[location[3]]=value
        elif location[0]==8:                                                              #<func+k>[key]
            self.func_stack[location[1]][location[2]][self.data[location[3]]]=value
    def call_obj_function(self,obj,args,funcname,kwargs=None):
        tem_esp=self.data[self.esp]
        if kwargs==None:kwargs={}
        self.pushaw()
        self.data[2] = len(args)                                           # CX=len(args)
        func=obj.vars[funcname]
        result=None
        try:
            result=func(*args,**kwargs)
        finally:
            self.popaw()
            self.data[self.esp]=tem_esp
        return result
    def yield_run(self,ip,ex_stack,import_funcs,send_obj=None):
        tem_ip=self.data[self.ip]
        self.data[self.ip]=ip
        #--------------------------------------------
        tem_stacks={}
        for func_name in import_funcs:
            tem_stacks[func_name]=self.func_stack[func_name]
            self.func_stack[func_name]=import_funcs[func_name]
        #--------------------------------------------
        tem_esp=self.data[self.esp]       #儲存目前esp
        for ex_obj in ex_stack:
            self.push(ex_obj)
        #--------------------------------------------
        yield_result =None
        ok=False
        try:                                #此處run可能會噴StopIteration錯誤，至少要回收堆疊、還原ip
            self.data[0]=send_obj
            next_obj=self.__run('yield run')
            ok=True
        #--------------------------------------------
        finally:
            del self.run_layer[-1]          #因為前面有添加comment，此處需除去yield run
            if ok:
                yield_result=self.data[0]            #獲取yield的值
            new_ex_stack=[]
            for i in range(tem_esp-self.data[self.esp]):
                new_ex_stack.insert(0,self.pop())
            # 還原父函數
            for func_name in tem_stacks:
                self.func_stack[func_name]=tem_stacks[func_name]
            #-------------------------------------------
            self.data[self.ip]=tem_ip
        return next_obj,new_ex_stack,yield_result,tem_esp
    def func_run(self,ip,class_obj,stack_name,stack_len,import_funcs):
        tem_ip = self.data[self.ip]  # 當前ip
        tem_esp=self.data[self.esp]
        # --------------------------------------------
        tem_func_stack={}
        for func_name in import_funcs:
            tem_func_stack[func_name]=self.func_stack[func_name]
            self.func_stack[func_name]=import_funcs[func_name]
        if stack_name not in self.func_stack:            #處理堆疊資訊
            self.func_stack[stack_name]=None
        tem_stack=self.func_stack[stack_name]
        # --------------------------------------------
       # self.push(len(self.code))  # 推入最後一行，程式執行結束直接跳至最後一行     #push ip
        #建立新function堆疊
        func_stack=[0]*stack_len
        func_stack[0]=class_obj                 #第0位置為class_obj
        self.func_stack[stack_name]=func_stack
        #-------------------------------------------------------
        self.data[self.ip] = ip+ 1
        self.push(len(self.code))   #這樣pop ip就會直接return
        result=None
        try:
            self.__run(f'Func<{ip}> run')
        #except Exception as e:
        #    print(e)
        #    raise e
        finally:
            result=self.data[0]
            del self.run_layer[-1]
            self.data[self.ip] = tem_ip
            # 還原父函數
            self.func_stack[stack_name]=tem_stack
            for func_name in import_funcs:
                self.func_stack[func_name] = tem_func_stack[func_name]
            self.data[self.esp]=tem_esp
        return result
    def __getitem__(self, location):
        #------------------------------------------------------------------------------------------------name
        if location[0] == 0:                                        # name
            return self.data[location[1]]
        elif location[0] == 1:                                       #name.attr
            obj = self.data[location[1]]
            if type(obj) in (class_obj, generator,Namespace_stack):
                if location[2] in obj.vars:
                    return obj.vars[location[2]]
                return self.undefined  # 發生錯誤
            elif type(obj)==Undefine:
                raise Exception(f'{self.inverse_data_dict[location[1]]} is undefined')
            elif type(obj)==Ex_module and location[2] in obj.vars:
                return obj.vars[location[2]]
            else:
                func=built_in_operator(obj, location[2])
                return func
        elif location[0] == 2:                                       # name[key]
            return self.data[location[1]][self.data[location[2]]]
        #------------------------------------------------------------------------------------------------<esp+k>
        elif location[0] == 3:                                       #<esp+k>
            return self.esp_stack[self.data[location[1]] + location[2]]
        elif location[0]==4:                                         #<esp+k>.attr
            obj = self.esp_stack[self.data[location[1]] + location[2]]
            if type(obj) in (class_obj, generator,Namespace_stack):
                if location[3] in obj.vars:
                    return obj.vars[location[3]]
                return self.undefined
            elif type(obj)==Undefine:
                raise Exception(f'variable is undefined')
            elif type(obj)==Ex_module and location[3] in obj.vars:
                return obj.vars[location[3]]
            else:
                func = built_in_operator(obj, location[3])
                return func
        elif location[0] == 5:                                         # <esp+k>[key]
            return self.esp_stack[self.data[location[1]] + location[2]][self.data[location[3]]]
        #------------------------------------------------------------------------------------------------<func+k>
        elif location[0] == 6:                                       #<func+k>
            return self.func_stack[location[1]][location[2]]
        elif location[0]==7:                                         #<func+k>.attr
            obj =self.func_stack[location[1]][location[2]]
            if type(obj) in (class_obj, generator,Namespace_stack):
                if location[3] in obj.vars:
                    return obj.vars[location[3]]
                return self.undefined
            elif type(obj)==Undefine:
               # ip=self.data[self.ip]
               # print('ip:',ip)
               # start_ip=ip-20
               # error_lines=self.code.code[start_ip:ip+10]
               # for i in range(30):
               #     print(start_ip+i,error_lines[i])
               # print('location:',location)
                raise Exception(f'this variable is undefined')
            elif type(obj)==Ex_module and location[3] in obj.vars:
                return obj.vars[location[3]]
            else:
                func = built_in_operator(obj, location[3])
                return func
        elif location[0] == 8:                                         # <func+k>[key]
            return self.func_stack[location[1]][location[2]][self.data[location[3]]]
        #------------------------------------------------------------------------------------------------[object]
        elif location[0]==10:                                          #list
            return [0]*location[1]
        elif location[0]==11:                                          #dict
            return {}
        elif location[0]==12:                                          #tuple
            return [0]*location[1]
        elif location[0] == 13:                                        #<class obj>
            self.class_objs.append(class_obj(self))
            return self.class_objs[-1]
    def __error_print(self,msg):
        Fail="[91m"
        RESET = "[0m"
        print(f'{Fail}{msg}{RESET}')
    def __ok_print(self,msg):
        OK="[92m"
        RESET = "[0m"
        print(f'{OK}{msg}{RESET}')
    def one_run(self,comment):
        self.__run(comment)
    def run(self,tf=0,stack_size=1024,comment='normal'):
        self.codes, self.data, self.data_dict = self.code.parse_code(start_row=0,reset=True)
        self.inverse_data_dict = {}
        for key in self.data_dict:
            self.inverse_data_dict[self.data_dict[key]] = key
        self.stack_size=stack_size
        self.esp_stack= [0] * stack_size
        #-------------------------------------------------------------
        self.set('esp', -1)  # 設定堆疊指標
        self.set('ip',0)
        self.esp = self.data_dict['esp']
        self.ip = self.data_dict['ip']
        self.ZR = self.data_dict['ZR']
        self.TF = self.data_dict['TF']
        self.ER=self.data_dict['$Exception']
        self.data[self.ER]=0
        self.error_line=0        #發生錯誤的line
        self.args_location = self.data_dict['*args']
        self.kwargs_location = self.data_dict['**kwargs']
        self.class_objs=[]
        self.func_stack={}
        self.undefined=Undefine()
        #--------------------------初始化外部函數
        for name in self.data_dict:
            if name in self.ex_function:
                self.data[self.data_dict[name]]=self.ex_function[name]
        self.normal_run(0,tf,comment)
    def REPL_run(self, row):
        tatal_output.clear()
        if row==0:
            self.run(0,1024,comment='REPL')
        else:
            self.data[0]=None
            self.codes, self.data, self.data_dict = self.code.parse_code(start_row=row,reset=False)
            for name in self.data_dict:
                if name in self.ex_function:
                    self.data[self.data_dict[name]] = self.ex_function[name]
            for key in self.data_dict:
                self.inverse_data_dict[self.data_dict[key]] = key
            self.normal_run(row,0,'REPL')
        return ''.join(tatal_output)
    def normal_run(self,row,tf,comment='normal'):
        self.tf=tf
        self.set('esp',-1)
        self.set('ip',row)
        try:
            self.__run(comment)
            if self.data[self.esp] == -1:
                if tf > 0:
                    self.__ok_print('\n程式結束--------')
            else:
                self.__error_print(f'程式警告:堆疊未還原---------->   {self.data[self.esp]}')
        except Exception as e:
            if self.data[self.ER] == 0:  # 錯誤不是來自try，錯誤來自正常行
                error_ip = self.data[self.ip]
            else:  # 錯誤來自try
                error_ip = self.error_line
            if comment!='REPL':
                msg = self.code.get_error_msg(error_ip)
                self.__error_print(f'\nTrackback:\nFILE: ' + msg['file'] + ',  line:' + str(+msg['row']))
                self.__error_print('   ' + msg['code'])
            error = str(e)
            if len(error) > 0: error = ': ' + error
            self.__error_print(fetch_error(e) + error)
            # print('--------------')
            if tf > 0:
                raise e
    def __run(self,run_comment):
        self.run_layer.append(run_comment)
        def obj_lock(lock):
            for obj in self.class_objs: obj.print_lock = lock
        def cpu_state():
            print('data: ', end='')
            for key in self.data_dict:
                if key[0] not in '"0123456789-' + "'" and key not in  ('None','True','False') and key not in self.ex_function:
                    # if type(key) != int and '"' != key[0] and "'" != key[0]:  # 去除數值和字串
                    print(f'{key}:{self.data[self.data_dict[key]]}', end='  ')
                if key in ('TF', '**kwargs'): print('\n      ', end='')
                if key=='$Exception':print('\n      ', end='')
                if key=='$Inheritance':
                    print('\n自由變數:\n      ',end='')
            stack_text = '\n\nstack:['
            stack_n = 7
            for i in range(25):
                obj = self.esp_stack[-i - 1]
                get = str(obj) + ','
                if i + 1 < abs(self.data[esp]):
                    stack_n += len(get)
                stack_text += get
            print(stack_text[:-1] + ']')
            print(' ' * stack_n + '^')
            for func_name in self.func_stack:
                print(f'{func_name}: {self.func_stack[func_name]}')
        def get_status():
            obj_lock(1)
            now_ip=self.data[ip]
            self.code.display(now_ip)
            cpu_state()
            print(f'run_layer:{self.run_layer}')
            if now_ip < len(self.codes):
                print('\n準備執行:', self.code.code[now_ip], '                  對應:', self.codes[now_ip])
                print('-------------------------------')
            else:
                print('程序已結束\n')
            obj_lock(0)
        ip=self.ip
        esp=self.esp
        ZR=self.ZR
        TF=self.TF
        ER=self.ER
        args_location=self.args_location
        kwargs_location=self.kwargs_location
        finally_box=[]
        n=len(self.codes)
        while self.data[ip]<n:
            cmd=self.codes[self.data[ip]]
           # print(f'{self.data[ip]}   {self.code.code[self.data[ip]]}                       {cmd}')
            if self.tf==1:
                get_status()
                a=input()
                if a!='':
                    #print(f'AX:"{self.data[0]}"')
                    if len(a)<3:
                        self.tf=0.5
                    elif a=='asd':
                        print('偵錯!!--------')
                        self.tf=0.1
                    else:
                        self.__ok_print('程式開始--------')
                        self.tf=0
            if self.tf==0.1:
                now_ip=self.data[ip]
                msg=' '*60+self.code.comments[now_ip]+f'\r       {self.code.code[now_ip]}\r{now_ip}'
                print(msg)
                #cpu_state()
            #------------------------------------------
            if cmd[0] ==0:#mov
                self[cmd[1]] = self[cmd[2]]
            elif cmd[0]==1: #$mov
                op=self[cmd[2]]
                if op==0:  #add
                    self[cmd[1]] += self[cmd[3]]
                elif op==1: #sub
                    self[cmd[1]] -= self[cmd[3]]
                elif op==2: #mul
                    self[cmd[1]] *= self[cmd[3]]
                elif op==3: #div
                    self[cmd[1]]/=self[cmd[3]]
                elif op==4: #pow
                    self[cmd[1]] **= self[cmd[3]]
                elif op==5:  # quo
                    self[cmd[1]] %= self[cmd[3]]
                elif op==6:  # rem
                    self[cmd[1]] //= self[cmd[3]]
                elif op==7:  #shl
                    self[cmd[1]]<<=self[cmd[3]]
                elif op == 8: #shr
                    self[cmd[1]]>>=self[cmd[3]]
                elif op == 9:  #and
                    self[cmd[1]] &= self[cmd[3]]
                elif op == 10: #xor
                    self[cmd[1]] ^= self[cmd[3]]
                elif op == 11: #or
                    self[cmd[1]] |=self[cmd[3]]
            elif cmd[0]==2:  #oper
                op = self[cmd[2]]
                if op == 0:  # add
                    self[cmd[1]] =self[cmd[1]]+self[cmd[3]]
                elif op == 1:  # sub
                    self[cmd[1]] =self[cmd[1]]-self[cmd[3]]
                elif op == 2:  # mul
                    self[cmd[1]] =self[cmd[1]]* self[cmd[3]]
                elif op == 3:  # div
                    self[cmd[1]] =self[cmd[1]]/self[cmd[3]]
                elif op == 4:  # pow
                    self[cmd[1]] =self[cmd[1]]**self[cmd[3]]
                elif op==5:  # quo
                    self[cmd[1]] =self[cmd[1]]%self[cmd[3]]
                elif op==6:  # rem
                    self[cmd[1]] =self[cmd[1]]//self[cmd[3]]
                elif op==7:  #shl
                    self[cmd[1]]=self[cmd[1]]<<self[cmd[3]]
                elif op == 8: #shr
                    self[cmd[1]]=self[cmd[1]]>>self[cmd[3]]
                elif op == 9:  #and
                    self[cmd[1]] =self[cmd[1]]&self[cmd[3]]
                elif op == 10: #xor
                    self[cmd[1]] =self[cmd[1]]^self[cmd[3]]
                elif op == 11: #or
                    self[cmd[1]] =self[cmd[1]] | self[cmd[3]]
            elif cmd[0] == 3:  # cmp 相減
                self.data[ZR] = self[cmd[1]] - self[cmd[2]]
            elif cmd[0]==4: #jmp
                self.data[ip]=self[cmd[1]]
            elif cmd[0]==5: #$jmp
                op=self[cmd[2]]
                zr=self.data[ZR]
                tf=self.data[TF]
                if (op=='==' and  zr== 0) or (op=='!=' and zr != 0) or (op=='>=' and zr >= 0) or (
                        op=='<=' and zr <= 0) or (op=='>' and zr > 0) or (op=='<' and zr < 0):
                    self.data[ip] = self[cmd[1]]
                elif (op=='t' and tf) or (op=='f' and not tf):
                    self.data[ip] = self[cmd[1]]
            elif cmd[0]==6: #call
                jmp_ip=self[cmd[1]]
               # print('jmp:',jmp_ip)
                if jmp_ip==None:
                    jmp_ip=cmd[1][3]               #[mode,name,offset,key]，取出key
                if type(jmp_ip)==Func:   #代表要call內部function
                    args=self.data[args_location]
                    kwargs=self.data[kwargs_location]
                    jmp_ip(*args,**kwargs)
                elif type(jmp_ip)==str:              #exfunction
                  #  print('exfunc')
                    args = self.data[args_location]
                    kwargs = self.data[kwargs_location]
                    tem_ip=self.data[ip]
                    self.data[0] = self.ex_function[jmp_ip](*args, **kwargs)  # 呼叫外部函數，由AX接受回傳值
                  #  print('get:',self.data[0])
                    self.data[ip]=tem_ip
                else:                                  #jmp_ip是function本身
                    args=self.data[args_location]
                    kwargs=self.data[kwargs_location]
                    tem_ip = self.data[self.ip]
                    #-------------------------------------------catch print
                    try:
                        call_func_name=jmp_ip.__name__
                    except:call_func_name=''
                    if call_func_name == 'print':
                        aprint(*args, **kwargs)
                    #-------------------------------------------
                    self.data[0]=jmp_ip(*args,**kwargs)            #呼叫外部函數，由AX接受回傳值
                    self.data[self.ip] = tem_ip
            elif cmd[0] == 7:#push
                self.esp_stack[self.data[esp]]=self[cmd[1]]
                self.data[esp]-=1
            elif cmd[0] == 8:#pop
                self.data[esp] += 1
                self[cmd[1]]=self.esp_stack[self.data[esp]]
            elif cmd[0]==9:  #tf判斷真假
                event=self[cmd[2]]
                if event==0: #in
                    self.data[TF]=self[cmd[3]] in self[cmd[1]]
                elif event==1: #equ
                    self.data[TF]=self[cmd[3]]==self[cmd[1]]
                elif event ==2: # Ctn
                    self.data[TF] = self[cmd[3]] in self[cmd[1]].vars
                elif event ==3: # is
                    self.data[TF] = self[cmd[3]] is self[cmd[1]]
            elif cmd[0] == 10: #inc
                self[cmd[1]] += 1
            elif cmd[0] == 11:#dec
                self[cmd[1]] -= 1
            elif cmd[0]==12: #$oper
                op=self[cmd[2]]
                if op== 0:  # not
                    try:                                  #用try是怕物件無法轉換:'NoneType' object cannot be interpreted as an integer
                        self[cmd[1]] = not self[cmd[1]]
                    except:
                        self[cmd[1]]=False
                elif op == 1:  #           負數
                    self[cmd[1]] = -self[cmd[1]]
                elif op==2:  #          補數
                    self[cmd[1]] = ~self[cmd[1]]

            elif cmd[0]==13:                              #ex_func AX funcname BX
                tem_ip=self.data[ip]
                self[cmd[1]]=self.ex_function[self[cmd[2]]](self[cmd[3]])
                self.data[ip]=tem_ip
            elif cmd[0]==14: #--------------------------------------------------------------------------try
                error_ip=self[cmd[1]]
                if error_ip=='end':
                   # del self.run_layer[-1]                #try正常後會自動del，此處不需要
                    return     #try end
                self.data[ip] += 1
                tem_esp=self.data[esp]           #儲存當前esp
                try:
                    self.__run(f'try {error_ip}')              #可能在堆疊過程中斷
                                                               #可能出現yield中斷，esp變動
                except Exception as e:
                    self.error_line=self.data[ip]       #註記發生錯誤的ip
                    self.data[esp] = tem_esp  # 還原原本的esp
                    self.data[ER]=e
                    self.data[ip] = error_ip     #遇到錯誤時，跳到偵錯ip
                del self.run_layer[-1]                   #因為前面有添加comment，此處需del
            elif cmd[0]==15:  #finally
                f_ip=self[cmd[1]]
                finally_box.append((f_ip,self.data[self.esp]))
            elif cmd[0]==16: #raise
                raise self[cmd[1]]       #進入except會自動del掉run_layer
            elif cmd[0]==17:  #error
                error=self[cmd[1]]
                if type(error)==list:
                    if Exception in error:
                        self.data[TF]=True
                    else:self.data[TF]=type(self.data[ER]) in error
                elif error==Exception:
                    self.data[TF]=True
                else:
                    self.data[TF] = type(self.data[ER])==error
            elif cmd[0]==18:  #Generator
                start_ip=self[cmd[2]]
                ex_k=3
                import_names={}   #(loc,stack)
                while ex_k<len(cmd):
                    func_name=self[cmd[ex_k]]
                    import_names[func_name]=self.func_stack[func_name]
                    ex_k+=1
                self[cmd[1]]=generator(self,start_ip,import_names)
            elif cmd[0]==19:  #Yield
                if self.run_layer[-1]=='finally yield run':
                    raise Exception("Exception ignored in: <generator object>\nRuntimeError: generator ignored GeneratorExit")
               # del self.run_layer[-1]                    #yield run結束會自動del，此處不需要
                return self.data[ip]+1,finally_box
            elif cmd[0] == 20:         #-------------------------------------------------------------- fetch
                tem_esp = self.data[esp]  # 儲存當前esp
                tem_ip=self.data[ip]      #暫存當前ip
                try:
                    get=self[cmd[2]]
                    self[cmd[1]]=next(get)
                    self.data[TF]=True                 #成功
                except StopIteration as e:                              #因為前面的try沒有附加run layer，此處except不清理任何run layer
                    self.data[TF]=False
                self.data[esp]=tem_esp
                self.data[ip]=tem_ip           #fetch結束後理論上ip不變
            elif cmd[0]==21:  #stop
                print('ip---->',self.data[self.ip],'esp------>',self.data[self.esp])
              #  if self.tf!=1:
               #     get_status()
               # input()
               # self.tf=1
            elif cmd[0]==22:      #end
                command=self[cmd[1]]
                if command=='finally_yield' and self.run_layer[-1]=='finally yield run':
                   # del self.run_layer[-1]                                              #yield run結束會自動del，此處不需要
                    return
                elif command=='Function':
                    func_name=self[cmd[2]]
                    if len(cmd)>3:
                        items_str = self[cmd[3]].split(',')
                        items = list(map(int, items_str))
                        for i in items:
                            self.func_stack[func_name][i]=None       #abort params
            elif cmd[0]==23:     #byte
                self[cmd[1]]=self[cmd[2]].encode()
               # del self[cmd[1]]
            elif cmd[0]==24:     #del
                op=self[cmd[1]]
                if op==0:    #刪除單元素
                    self[cmd[2]]=Undefine()
                elif op==1:  #刪除AX[BX]
                    del self[cmd[2]][self[cmd[3]]]
                elif op==2:                         #刪除  XXX.attr
                    del self[cmd[2]].vars[self[cmd[3]]]
            elif cmd[0]==25:     #Function
                func_ip=self[cmd[2]]
                func_class_obj=self[cmd[3]]
                func_stack_name=self[cmd[4]]
                func_stack_len=self[cmd[5]]
                ex_k = 6
                import_names= {}  #要匯入的父函數名稱
                while ex_k < len(cmd):
                    func_name=self[cmd[ex_k]]
                    import_names[func_name]=self.func_stack[func_name]         #在宣告時就儲存當前堆疊資訊
                    ex_k += 1
                self[cmd[1]] = Func(self, func_ip,func_class_obj,func_stack_name,func_stack_len,import_names)
            elif cmd[0]==26: #pass
                pass
            elif cmd[0]==28:   #namespace
                var_box=self[cmd[3]].split(',')
                var_k=0
                var_dict={}
                for name in var_box:
                    var_dict[name]=var_k
                    var_k+=1
                stack=[Undefine()]*var_k
                namespace_name=self[cmd[2]]
                self.func_stack[namespace_name]=stack
                self[cmd[1]]=Namespace_stack(self,namespace_name,var_dict)
            elif cmd[0]==29:  #*args
                self[cmd[1]]=self[cmd[2]][self[cmd[3]]:]
            elif cmd[0]==30:  #kwargs
                key_dict=self[cmd[2]]
                not_need=self[cmd[3]].split(',')
                void_dict={}
                for key in key_dict:
                    if key not in not_need:
                        void_dict[key]=key_dict[key]
                self[cmd[1]]=void_dict
            elif cmd[0] == 31:  # module
                self[cmd[1]]=Ex_module(self[cmd[2]])
            elif cmd[0]==32:   #type
                self[cmd[1]].atype=self[cmd[2]]
            elif cmd[0]==33:   #name
                self[cmd[1]].name=self[cmd[2]]
            elif cmd[0] == 34:  #repl_print
                item=self[cmd[1]]
                if item!=None:
                    print(item)
            self.data[ip]+=1
            if -self.data[esp]>self.stack_size:
                raise RecursionError('maxinum recursion depth exceeded')
        #del self.run_layer[-1]       #del讓__run的請求者del掉就好，自己不用del
        if self.tf>0:
            get_status()
class Ex_module:    #引入外部函數
    def __init__(self,module_name):
        self.module_name=module_name
        self.__name__='Ex_module'
        self.vars={}
    def __str__(self):
        return self.module_name
    def __call__(self, *args, **kwargs):
        raise TypeError("'module' object is not callable")
class Namespace_stack:
    def __init__(self,ram,stack_name,var_dict):
        self.stack_name=stack_name
        self.vars=namespace_stack_var(ram,stack_name,var_dict)
    def __str__(self):
        return f'module "{self.stack_name}"'
class namespace_stack_var:
    def __init__(self,ram,stack_name,var_dict):
        self.ram = ram
        self.name = stack_name
        self.var_dict = var_dict
    def __contains__(self, item):
        return item in self.var_dict
    def __setitem__(self, key, value):
        if key in self.var_dict:
            self.ram.func_stack[self.name][self.var_dict[key]]=value
        else:
            #登記新屬性
            now_length=len(self.ram.func_stack[self.name])
            self.var_dict[key]=now_length
            self.ram.func_stack[self.name].append(value)            #嵌入最後一個
    def __getitem__(self, item):
        return self.ram.func_stack[self.name][self.var_dict[item]]