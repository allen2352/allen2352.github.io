import import2
q='this is test'
from mix import *
def test_function(string):
    for i in string:
        print(i)
    print(string)
    print(test2.test3.q)
print('answer:--------------------',s,a,b,y)