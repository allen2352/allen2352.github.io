
a=100
b='200'

try:
    print('try')
    c=a+b
except NameError:
    print('name error')
except ValueError:
    print('value error')
except Exception as e:
    print('except is ',e)
else:
    print('else')
finally:
    print('fist try end')
class NEW:
    def __init__(self):
        print('new init')
        class new:
            def __init__(self):
                self.value=10
            def __getitem__(self, item):
                return self.value*item
            def __setitem__(self, key, value):
                self.value+=key+value
        self.sss=new()
    def __add__(self, other):
       # print('my sss:', self.sss.value)
       # print('other sss:', other.sss.value)
        self.sss.value+=other.sss.value
       # print('my sss:',self.sss.value)
        return self
    def __setitem__(self, key, value):
        self.sss[key]=value
    def __getitem__(self, item):
        return self.sss[item]
    def __del__(self):
        print('with value:',self.sss.value,' be destroy')
    def yield_loop(self):
        try:
            for i in range(10):
                self.sss[i]=i**2
                yield self.sss[10]
        finally:
            print('loop end with:',self.sss.value)
class DEF:
    def Class(self,a,b):
        self.a=a
        self.b=b
        print('this is class test')
    def __init__(this,a,b):
        this.Class(b,a)
        print('__init__')
        this.k=10
        this.abc=100
        this.random=300
    def __enter__(self):
        print('enter!')
        self.k+=20
        new=NEW()
        new.sss[self.a]=self.b
        return new
    def __exit__(self, exc_type, exc_val, exc_tb):
        print('exit')
with DEF(10,20) as rew:
    new=NEW()
    print(rew.sss.value)
    print(new.sss.value)
  #  $stop
    rew+=new
    print(rew.sss.value)
    print('happy')
print(rew.sss[100])
x=rew.yield_loop()
y=new.yield_loop()
for i in range(10):
    print(next(x)*next(y))