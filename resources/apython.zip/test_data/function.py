def func1(a,b,c):
    w=a+b
    z=a+c
    d=a*b-c
    return w*z*d
def func2(q,w,e):
    s=q-w**e
    return s
print(func1(3,6,7))
print(func1(func2(2,3,4),6,7))
class ABC:
    def __init__(self):
        print('init')
        self.k=0
    def func(self,a,b):
        print('func')
        return 100*a*b
    def __str__(self):
        return 'this is abc'
    def __add__(self, other):
        self.k+=other
        print(f'now self.k is {self.k}')
        return self
abc=ABC()
c=abc.func(2,3)+50
print(c,str(abc+5))