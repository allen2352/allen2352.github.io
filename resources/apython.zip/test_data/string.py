easy='hello world'
print(easy)
easy2="hello he+"
print(easy2)
string1='\'""\"sa\\\''
print(string1)
r_string1=r'\'""\"sa\\\''
print(r_string1)
string2="\'123\n\'\\\"\'''"
print(string2)
r_string2=r"\'123\n\'\\\"\'''"
print(r_string2)
string3=f'abc\'{{"12\'3"}}12{345}}}\"\''
print(string3)
r_string3=r'abc\'{{"12\'3"}}12{345}}}\"\''
print(r_string3)
n_string3='abc\'{{"12\'3"}}12{345}}}\"\''
print(n_string3)
x=f'12{"hello"}}}{{\'\""\'"}}'.join(['"',"'"])
y='"\''
print(x)
print(y)
class ABC:
    def __init__(self,a):
        print(f'this is \' self. {a} \' init ! ')
        self.k=0
    def func(self):
        print(f'this is \'self.{self.k}\' init ! ')
abc=ABC(10)
abc.func()
