box=[]
for i in range(10):
    box.append(i**2-i)
    for j in range(10):
        box.append(i*j)
s=sum(box)%30
k=[]
hintbox=[]
while s>0:
    k.append((s,s**2))
    s-=1
    if s>10:
        hintbox+=['>10']
    elif s==10:
        hintbox+=['==10']
    else:
        hintbox+=['<10']
sss=[i+j for i,j in k]
print(sss)
c=(i for i in range(10))
for i in range(10):
    print(next(c))
print(hintbox)
def func_loop(a,b):
    def sub_func(a,b,x):
        for i in range(10):
            yield i**a+b/(abs(x)+12)
    xbox=sub_func(a+b,a*b*1234,a-b)
    for i in range(10):
        yield next(xbox)
func=func_loop(2,5)
for i in range(10):
    print(next(func))