from os import listdir
def test_function(string):
    for i in string:
        print(i)
    print(string)