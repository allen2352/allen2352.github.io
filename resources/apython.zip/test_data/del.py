b=[4]
a=[[1],[2],[3],b]
print(a)
del a[-1]
print(a)
#print(b)
def abc():
    x=1
    y=2
    def rew():
        print(x+y)
    return rew
a=abc()
a()
class ABC:
    def __init__(self):
        self.a=5
        self.k=0
    def k(self):
        print('100')
abc=ABC()
print(abc.k)
print(abc.a)
del abc.k
print(abc.k)
a=list(range(10))
print(a[3:])
print(a[3::])
print(a[:5:])
print(a[:8:-1])
del a[2:5]
print(a[::-1])
a+=['hello','world!']+a[::-2]
for i in range(3):
    del a[-1]
print(a)
b='hello'
print(b)
del b
print(b)