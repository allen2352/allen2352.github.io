a=None
def test():
    a=100
    def test2():
        nonlocal a
        a=200
        print('test2:a=', a)
       # $stop
       # $stop
        def test3():
            nonlocal a
            a=300
            def test5():
                nonlocal a
                a+=30
                print('test5:a=',a)
            test5()
            print('test3:a=',a)
            return test5
        def test4():
           # $stop
            global a
            global he_plus
            #$stop
           # $stop
            class ABC:
                def __init__(self,orig,nnn):
                    self.k=orig**nnn
                def __add__(self, other):
                    new=ABC(2,3)
                    new.k=self.k+other.k
                    return new
                def __str__(self):
                    return f'{self.k}'
            he_plus=ABC(4,5)
            a=400
          #  $stop
            return ABC(6,7)
        print('test2:a=', a)
        ss=test3()
        print('test2:a=', a)
        nonlocal he2
        print('test2:a=', a)
        he2=test4()
      #  $stop
#        $stop
      #  $stop
        print('test2:a=',a)
        ss()
        ss()
    #$stop
    he2=0
    test2()
    #$stop
    print('test:a=',a)
    global fff
   # $stop
    fff=he2+he_plus
test()
#$stop
print('全域a=',a)
print(fff)