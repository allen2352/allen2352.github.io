#from random import random
class AAA:
    print('sound good')
    def __init__(self):
        self.k=10
        print('my k is ',self.k)
    def func(self):
        self.k+=100
        return self.k
    print('he+')
    ccc=3000
class BBB(AAA):
    print('my first')
    def __init__(self):
        self.k=200
        print('my k is ',self.k)
    def func(self):
        self.k+=2000
        return self.k
    print('zzz')
b=BBB()
print(b.func())
print(b.ccc)
class A2:
    print('A2')
    def func(self):
        return 2
class A1:
    print('A1')
    def func(self):
        return 1
class A3:
    print('A3')
    def func(self):
        return 3
box=[A1,A2,A3]
class BB(A3,A2,A1):
    def __init__(self):
        print('start')
for i in range(10):
    a=BB()
    print(a.func())
def p1():
    print('p1')
def p2():
    print('p2')
a=[p2(),p1()]