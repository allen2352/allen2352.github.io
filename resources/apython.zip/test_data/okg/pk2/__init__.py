import okg.pk2.sss
fg='this is good'
#LO=okg.pk2.sss.repeat_func
#bbb=okg.pk2.sss.a1
class OKK:
    def __init__(self):
        print('this is init')
    def __enter__(self):
        print('enter')
        self.tem=okg.pk2.sss.Guava(3.5)
        return self.tem
    def __exit__(self, exc_type, exc_val, exc_tb):
        print('exit')
        print('my tem is ',self.tem.k)