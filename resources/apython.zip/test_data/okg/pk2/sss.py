a1=100
b2=200
c3=300
def repeat_func(func):
    for i in range(5):
        func()
class Guava:
    def __init__(self,l):
        print('this is Guava')
        self.k=100*l
    def print(self):
        print(self.k)
    def __add__(self, other):
        self.k+=other
        return self