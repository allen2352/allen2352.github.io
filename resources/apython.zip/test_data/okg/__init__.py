import okg
import okg.pk1
a=100
a*=okg.pk1.a
from okg.pk1 import *
class ABC:
    def __init__(self):
        self.test='hello'
    def asd(self):
        self.test+='_asd'
    def func(self,rp):
        print(f'{rp} {self.test}')
print('okg')
print(a+b+c)
s=gen(3,5)
for i in range(5):
    print(next(s))
with OKK() as ok:
    for i in range(3):
        ok+=next(s)

