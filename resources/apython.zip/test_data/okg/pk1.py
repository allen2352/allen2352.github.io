a=100
b=200
c=300
from okg.pk2 import *
def gen(x,y):
    try:
        for i in range(10):
            yield i+x*y
        x+=2
    finally:
        print('gen end')