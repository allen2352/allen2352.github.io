import import3
from import3 import *
class Apple:
    def __init__(self):
        self.k=3
    def func1(self,l):
        print(l*100)
        return 10
    def __add__(self, other):
        new=Apple()
        new.k=self.k+other.k
        return new
class Banana(Apple):
    def func1(self,s):
        self.k=s**s
        print(self.k)
        return 100
b=Banana()
print(Apple)
a=Apple()
print(a.k)
#