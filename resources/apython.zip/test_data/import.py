from import2 import Apple,b,test_function,q
#import test2
a=Apple()
print(a.func1(20))
d=b.func1(5)
c=b
print(c.k*d)
#print(test_function(q))
import okg.pk2.sss
print(okg)
print(okg.pk2)
print(okg.pk2.sss)
print(b)
print(c)
d=not b
#print(not b)
#assert 1==2 or 1==3 or c is not b,'123'+'456'
asd=okg.ABC()
print(okg.pk2.sss.repeat_func(asd.asd))
print(asd.func('he+'))