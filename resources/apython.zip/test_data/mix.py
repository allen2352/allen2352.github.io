b=lambda x,y:x**2+y*3-5
s=b(5,7)
print(s)
c=lambda x:[i for i in range(x) if i%2==0]
d=lambda x,y:((yield x+y+i) for i in range(10) if i%3==1)
g=d(2,3)
#a=c(10)
try:
    for i in c(100):
        print(next(g),end=' ')
except:
    print(c(10))
    def abc(x,y):
        def p():
            for i in range(10):
                yield (x+y+i)
        return p()
    class YYY:
        a=(lambda self,x,y,z:x+y**z)(0,3,5,7)
        b=lambda self,w,e:(lambda q,w,e:q*w+e-7)(w,e,10)
        def __init__(self,x,y):
            self.value=self.b(x,y)
        def __str__(self):
            return str(self.value)
        def func(self,func):
            func()
    #with c(10) as ce:
     #   print('happy')
finally:
    def this_is_mix_try():
        class test:
            def __init__(self):
                print('__init__')
            def __enter__(self):
                print('__enter__')
                return YYY(10,20)
            def __exit__(self, exc_type, exc_val, exc_tb):
                print('__exit__')
        with test() as T:
            k=0
            while k<2:
                with test():
                    print('inside test')
                    def lock():
                        for i in range(10):
                            yield k**3+T.value
                    lo=lock()
                    print('yield:',next(lo))
                k+=1
                if T.value>10:
                    print(f'T is bigger:{T.value}')
                elif s<30:
                    print('s is small')
                print(T.value,s)
            else:
                print('this is else leave')
    sss=this_is_mix_try
    for i in range(20):
        try:
            a=abc(2,3)
            for i in range(10):
                print(next(a)*i,end=' ')
            y=YYY(3,6)
            y.func(sss)
            print(y,end=' ')
            if i>3:
                i+=5
                break
        except:
            print('a except occur')
        finally:
            print(i,end=' ')
            if i>8:
                break

a=[1,2,3]
b=list(map(str,a))
print(b)
a = (lambda self, x, y, z: x + y ** z)(0, 3, 5, 7)
class YYY:
    a = (lambda self, x, y, z: x + y ** z)(0, 3, 5, 7)
    b = lambda self, w, e: (lambda q, w, e: q * w + e - 7)(w, e, 10)
    def __init__(self, x, y):
        self.value = self.b(x, y)*1000+self.a
        #print(self.value)
    def __str__(self):
        return str(self.value)
y=YYY(3,6)

print(y)