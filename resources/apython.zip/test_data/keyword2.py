from time import *
import keyword3
import os.path
class Apple:
    def __init__(self):
        self.k=3
    def func1(self,l):
        print(l*100)
        return 10
    def __add__(self, other):
        new=Apple()
        new.k=self.k+other.k
        return new
class Banana(Apple):
    def func1(self,s):
        self.k=s**s
        print(self.k)
        return 100
b=Banana()
print(Apple)
a=Apple()
print(f'now time is {round(time(),2)} and a.k=',a.k)
#
print(f'new.txt is '+('file' if os.path.isfile('new.txt') else 'not file'))