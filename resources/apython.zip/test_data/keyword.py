import keyword2
from keyword3 import *
def abc(x,y,*args,**kwargs):
    print(x)
    print(y)
    for i in args:
        print(i,end=' ')
    print(kwargs['ed'])
dfg={'ed':200,'su':400}
abc(1,2,3,2,3,4,5,6,r=100,**dfg)
def allen_func(function,*args, **kwargs):
    a=function(*args,**kwargs)
    print(a)
for i in range(3):
    allen_func(print,'hello',' he+ ',123456,'',end=' \n\n')
alen=allen_func(len,[1,2,3,4,5])
print(alen)
qq=allen_func('hey he+'.replace,'h','H')
allen_func(print,allen_func('this is easy '.split,' '),qq,end='\nthis is end')
keyword2.sleep(1)
allen_func(keyword2.keyword3.listdir)