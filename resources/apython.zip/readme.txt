main.py:用於執行python檔案，單行式REPL
block.py用於執行區塊式REPL
在apython中設定ex_func可匯入外部函數，然後執行ebuild_in.py進行built_in改寫
