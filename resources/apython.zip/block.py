from apython import Apython
apython=Apython()
block1='''
print('hello world')
def add(a,b):
    return a+b
'''
result1=apython.interaactive(block1)
print('result1:\n'+result1)
#a=input()
block2='''
print(add(3,5))
def sub(a,b):
    return a-b
b=add(2,5)-sub(1,6)
print(b)
print(1,2,3,4,5)
'''
result2=apython.interaactive(block2)
print('result2:\n'+result2)
#a2=input()

block3='''
class ABC:
    def __init__(self,id):
        self.id=id
    def __str__(self):
        return str(self.id)
    def __add__(self,other):
        new=ABC(self.id+other.id)
        return new
class BBC(ABC):
    def func(self,k):
        self.id**=k

bbc=BBC(5)
abc=ABC(10)
bbc.func(3)
f=abc+bbc
print(f)
'''
result3=apython.interaactive(block3)
print('result3:\n'+result3)