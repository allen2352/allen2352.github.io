from alink import *
from apython import Apython
from os import listdir,getcwd,mkdir,rename,remove,rmdir,popen,chdir
from os.path import isdir,isfile

HttpDB.set_init_user_data({'index_path_html':'','index_path_content_html':'','main_element':'','last_html':void_html,'last_dir':'','copylink':''})
def index(user,request):
    def get_icon(filename):
        key = filename.split('.')[-1]
        if key in ['png', 'jpg', 'jpeg', 'bmp', 'tiff', 'tif', 'ppm', 'WebP', 'ico']:
            icon = 'picture'
        elif key in ['mp3', 'wav']:
            icon = 'music'
        elif key in ['mp4', 'avi', 'mov', 'wmv', 'mkv', 'asf', 'flv', 'gif']:
            icon = 'video'
        elif key in ['ttc', 'fon', 'ttf']:
            icon = 'font'
        elif key in ['docx', 'doc', 'ppt', 'pptx', 'xlsx', 'xls', 'lnk']:
            icon = {'docx': 'word', 'doc': 'word', 'ppt': 'power point', 'pptx': 'power point', 'xlsx': 'excel','xls': 'excel', 'lnk': 'shortcut'}[key]
        elif key in ['txt', 'exe', 'pdf', 'py', 'zip', 'xml', 'rpf', 'ini', 'dll', 'c', 'cpp', 'rar', 'js', 'html','dev', 'pyc', 'url','css']:
            icon = key
        else:
            icon = 'file'
        return icon
    html_file=open('cloud/index.html','r',encoding='utf-8').read()
    if 'path' not in request.GET_param:
        request.GET_param['path']=getcwd().replace('\\','/')
    path=str(request.GET_param['path']).replace('\\','/')
    road = f'{path}'
    if isdir(road) or isfile(road):
        if isfile(road):
            c=road.split('/')
            f_road=c[:-1]
            road_isfile=c[-1]
        else:
            f_road=road.split('/')
            road_isfile=None
        pathbox=[]
        now_path=''
        for froad in f_road:
            if froad!='':
                now_path+=froad+'/'
                pathbox.append(f'<input type="button" value="{froad}" style="border: 1px;background-color : #FFFFFF;" onclick="location.href=\'/index.html?path={now_path}\'">>')
        user['last_dir'] = now_path
        content_box=[]
        for file in listdir(now_path):
            filepath=now_path+file
            if isdir(filepath):
                icon='folder'
            else:
                icon=get_icon(file)
            if len(file)>10:
                displayname=file[:10]+'...'
            else:
                displayname=file
            if file==road_isfile:
                btn_style=f'style="font-size: 3vh;color:yellowgreen;border: 1px;background-color : #FFFFFF;width:220px;text-align:left;"'
            else:
                btn_style = f'style="font-size: 3vh;border: 1px;background-color : #FFFFFF;width:220px;text-align:left;"'
            content_box.append(f'<button type="button" class="myfile" id="{filepath}" name="{file}" {btn_style}><img src="static/image/Icon/{icon}.png" style="height: 3vh;position: relative;top:0.5vh;">&ensp;{displayname}</button>')
        content_box.append('<div id="newfolder" style="font-size: 3vh;border: 1px;background-color : #FFFFFF;width:220px;text-align:left;">&ensp;</div>')
        user['index_path_html']=''.join(pathbox)
        user['index_path_content_html']='<hr>'.join(content_box)
    if isfile(road):                         #獲取檔案
        icon=get_icon(road)
        src=f'/file?path={road}'
        if icon=='picture':
            user['main_element']=f'<img style="width:70vw;" src="{src}">'
        elif icon in ('txt','py','css','html','js'):
            content=open(road,'r',encoding='utf-8').read()
            content=html_convert(content)
            user['main_element']=f'<pre>{content}</pre>'
        elif icon=='music':
            user['main_element']=f'<audio src="{src}" controls>'
        elif icon == 'video':
            user['main_element'] = f'<video style="width:70vw;"  src="{src}" controls>'
        elif icon == 'pdf':
            user['main_element'] = f'<embed style="width:100%;height:80vh;" src="{src}">'
        else:
            filename=road.split('/')[-1]
            user['main_element']=f'<a href="{src}">{filename}</a>'
    html_file = html_file.replace('{{index_path_html}}', user['index_path_html']).replace(
        '{{index_path_content_html}}', user['index_path_content_html']).replace('{{main_element}}',user['main_element'])
    user['last_html']=html_file
    return  'HTTP/1.1 200 OK\r\n\r\n'.encode('utf-8')+user['last_html'].encode('utf-8')
def get_file(user,request):
    path=request.GET_param['path']
    return return_http_file(path,need_execute=False)
def upload_file(user,request):
    file_objects = request.get_name('file')
    for file_object in file_objects:
        filename = file_object['filename']
        success=file_object.save(user['last_dir']+filename)
        if success:
            print('成功!!!')
        else:
            return _404
    request.GET_param['path']=user['last_dir']
    return index(user,request)
def copylink(user,request):
    cpylink=user['last_dir']+str(request.GET_param['filename'])
    user['copylink']=cpylink
    return 'HTTP/1.1 200 OK\r\n\r\n'.encode('utf-8') + user['last_html'].encode('utf-8')
def cutlink(user,request):
    ctlink=user['last_dir']+str(request.GET_param['filename'])
    user['copylink']=ctlink+'*cut'
    return 'HTTP/1.1 200 OK\r\n\r\n'.encode('utf-8') + user['last_html'].encode('utf-8')
def pastelink(user,request):
    def get_deal_box(filename):
        if isfile(filename):
            return [(1,filename,filename[cl:])]
        elif isdir(filename):
            box=[(0,filename[cl:])]
            for i in listdir(filename):
                road=f'{filename}/{i}'
                box+=get_deal_box(road)
            return box
        return []
    work_folder=user['last_dir'].rstrip('/')+'/'
    cpylink=user['copylink']
    is_cut='*cut' in cpylink
    cpylink = cpylink.split('*')[0]
    if is_cut:
        rename(cpylink,work_folder+cpylink.split('/')[-1])
    else:
        cpylink_name=cpylink.split('/')[-1]
        cl=len(cpylink)-len(cpylink_name)
        deal_box=get_deal_box(cpylink)
        r_speed=2**20
        for i in deal_box:
            if i[0]==1 and i[1]!=work_folder+i[2]:
                f=open(i[1],'rb')
                g=open(work_folder+i[2],'wb')
                code=f.read(r_speed)
                while code:
                    g.write(code)
                    code = f.read(r_speed)
                f.close()
                g.close()
            elif i[0]==0 and not isdir(work_folder+i[1]):
                mkdir(work_folder+i[1])
    request.GET_param['path'] = user['last_dir']
    return index(user,request)
def renamelink(user,request):
    work_folder = user['last_dir'].rstrip('/') + '/'
    c=request.GET_param['param'].split('*')
    try:
        rename(work_folder+c[0],work_folder+c[1])
    except Exception as e:
        print(e)
    request.GET_param['path'] = user['last_dir']
    return index(user,request)
def removelink(user,request):
    def remove_dir(filepath):
        for i in listdir(filepath):
            road=f'{filepath}/{i}'
            if isdir(road):
                remove_dir(road)
            elif isfile(road):
                remove(road)
        rmdir(filepath)
    rmlink = user['last_dir'] + str(request.GET_param['filename'])
    if isfile(rmlink):
        remove(rmlink)
    elif isdir(rmlink):
        remove_dir(rmlink)
    request.GET_param['path'] = user['last_dir']
    return index(user,request)
def newfolder(user,request):
    foldername=request.GET_param['name']
    work_folder=user['last_dir'].rstrip('/')+'/'
    try:
        mkdir(f'{work_folder}{foldername}')
    except Exception as e:
        print(e)
    request.GET_param['path'] = user['last_dir']
    return index(user,request)
def terminal_cmd(user,request):
    cmd=str(request.GET_param['cmd'])
    if 'terminal' not in user:
        user['cmd_mode']='normal'
        user['cmd_folder']=getcwd()
        user['terminal']=getcwd()+'&gt;' #>符號
    work_folder=user['cmd_folder']
    if user['cmd_mode']=='normal':
        if cmd!='display':    #代表要執行指令
            result = cmd + '\n'
            c=cmd.split(' ')
            if (c[0]=='cd' and len(c)==2) or c[0]=='cd..':
                if c[0]=='cd..' or c[1]=='..':
                    f_name=work_folder.split('\\')[-1]
                    work_folder=work_folder[:-len(f_name)-1]
                elif isdir(f'{work_folder}\\{c[1]}'):
                    work_folder=f'{work_folder}\\{c[1]}'
                user['cmd_folder'] = work_folder
                result+=user['cmd_folder']+'&gt;'
            elif c[0]=='py' and len(c)==1:
                user['apython']=Apython()
                user['cmd_mode']='apython'
                result+='>>>'
            elif c[0]=='reset':
                user['terminal']=''
                result=user['cmd_folder']+'&gt;'
            else:
                mypath=getcwd()
                chdir(work_folder)
                result+=popen(cmd).read()+'\n'+user['cmd_folder']+'&gt;'
                chdir(mypath)
            user['terminal']+=html_convert(result)
    elif user['cmd_mode']=='apython':
        result = cmd + '\n'
        if cmd=='^Z':
            user['cmd_mode']='normal'
            result +=user['cmd_folder'] + '&gt;'
        else:
            execute_result=user['apython'].REPL(cmd)
            result+=execute_result+('\n' if execute_result!='' else '')+'>>>'
        user['terminal'] += html_convert(result)
    terminal_content=user['terminal'].split('<br>')
    user['terminal']='<br>'.join(terminal_content[-1000:])
    content = user['terminal']
    header =f'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent_Length:{len(content)}\r\n\r\n'
    return (header+content).encode('utf-8')
#server=HttpServer()
server=HttpsServer('server.crt','server.key')
server.set_template_path('cloud')
server.add_route('/index.html',['get'],index)
server.add_route('/file',['get'],get_file)
server.add_route('/upload_file',['post'],upload_file)
server.add_route('/copylink',['get'],copylink)
server.add_route('/cutlink',['get'],cutlink)
server.add_route('/pastelink',['get'],pastelink)
server.add_route('/rename',['get'],renamelink)
server.add_route('/removelink',['get'],removelink)
server.add_route('/newfolder',['get'],newfolder)
server.add_route('/cmd',['get'],terminal_cmd)
server.mainloop()