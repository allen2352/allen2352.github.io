from os import system
built_in=\
{
    "<class 'str'>":
        {
            'attr':'',
            'example':"'hello'",
            'function':'join,count,split,index,format,encode,replace,capitalize,casefold,center,endswith,expandtabs,'
                       'find,format_map,isalnum,isalpha,isascii,isdecimal,isdigit,isidentifier,islower,isnumeric,'
                       'isprintable,isspace,istitle,isupper,ljust,lower,lstrip,maketrans,partition,removeprefix,'
                       'removesuffix,rfind,rindex,rjust,rpartition,rsplit,rstrip,splitlines,startswith,strip,swapcase,'
                       'title,translate,upper,zfill'
        },
    "<class 'list'>":
        {
            'attr':'',
            'example':"[1,2,3]",
            'function':'append,pop,count,remove,insert,clear,copy,index,extend,reverse,sort'
        },
    "<class 'tuple'>":
        {
            'attr':'',
            'example':"(1,5,9)",
            'function':'index,count'
        },
    "<class 'dict'>":
        {
            'attr':'',
            'example':"{1:2,3:4}",
            'function':'pop,get,copy,clear,update,keys,fromkeys,items,popitem,setdefault,values'
        },
    "<class 'bytes'>":
        {
            'attr':'',
            'example':"b'hell'",
            'function':'join,count,split,index,format,decode,replace,capitalize,casefold,center,endswith,expandtabs,'
                       'find,format_map,isalnum,isalpha,isascii,isdecimal,isdigit,isidentifier,islower,isnumeric,'
                       'isprintable,isspace,istitle,isupper,ljust,lower,lstrip,maketrans,partition,removeprefix,'
                       'removesuffix,rfind,rindex,rjust,rpartition,rsplit,rstrip,splitlines,startswith,strip,swapcase,'
                       'title,translate,upper,zfill'
        },
    "<class 'set'>":
        {
            'attr':'',
            'example':"{1,2,3,4}",
            'function':'pop,add,remove,copy,clear,update,difference,difference_update,discard,intersection,intersection_update,'
                       'isdisjoint,issubset,issuperset,symmetric_difference,symmetric_difference_update,union'
        },
    "<class '_io.TextIOWrapper'>":
        {
            'attr':'name,encoding,mode,buffer,closed,errors,line_buffering,newlines',
            'example':"open('newtext.txt','w')",
            'function':'write,tell,read,close,seek,fileno,flush,isatty,readable,readline,readlines,seekable,truncate,writable,writelines,'
                       '__enter__,__exit__'
        },
    "<class 'builtin_function_or_method'>":
        {
            'attr':'__name__',
            'example':"print",
            'function':''
        }
}
build_template='''
def next_element(codeline,k,elements,end=False,stop=()):           #從codeline的第k處開始尋找elements，沒有則返回-1
    c=0      #括號
    n=len(codeline)
    elements=list(elements)
    while k<n:
        element=codeline[k]
        if c==0:
            if element in elements:
                return k
            elif element in stop:
                if end:return k
                return -1
        if c<0:
            print('強制返回')
            return k
        if element in ('(','[','{'):c+=1
        elif element in (')',']','}'):c-=1
        k+=1
    if end:return n
    return -1
def Read_ex_func():
    def deal_line(line):
        line_dict={}
        n=len(line)
        k=0
        while k<n:
            while k<n and line[k] in ', ':k+=1
            q=next_element(line,k,'( ,',end=True)
            element=line[k:q]
            while q<n and line[q]==' ':q+=1
            if q<n and line[q]=='(':    #代表還有子類別
                q2=next_element(line,q+1,')')
                line_dict[element]=deal_line(line[q+1:q2])
                k=q2+1
                sub_dict[element]=list(line_dict[element])
            elif q>=n or line[q]==',':
                line_dict[element]={}     #該元素沒有子類別
                k=q+1
            else:raise Exception('unknow')
        return line_dict
    sub_dict={}   #name:[sub,...]
    module_dict = {}  # module_name:[子類別名稱,...]
    ex_func_content = open('ex_func.py', 'r', encoding='utf-8').read().split('\\n')
    for line in ex_func_content:
        p = next_element(line, 0, ' #', end=True)
        if p < len(line) and line[p] == ' ':
            k = next_element(line, p + 1, ' #', end=True)
            module_name = line[p + 1:k]
            if k<len(line) and line[k]=='#':k-=1
            q = next_element(line, k + 1, '#')
            if q > k:                             #子類別存在
                module_dict[module_name]=deal_line(line[q + 1:])
            else:module_dict[module_name]={}
    return module_dict,sub_dict
def build():
    g = open('built_in.py', 'w',encoding='utf-8')
    g.write("#encoding='utf-8'\\nfrom apython.ex_func import *\\n")
    g.write('class bcolors:\\n    OK = "\033[92m"  # GREEN\\n    WARNING = "\033[93m"  # YELLOW\\n    FAIL = "\033[91m"  # RED\\n    RESET = "\033[0m"  # RESET COLOR\\n')
    g.write("def built_in_operator(obj,op):\\n    stype = str(type(obj))\\n")
    k=0
    for stype,abox,fbox in datas:
        if len(fbox)>0:
            if k==0:
                g.write(f'    if stype=="{stype}":\\n')
            else:
                g.write(f'    elif stype=="{stype}":\\n')
            s=0
            for item in fbox:
                if s==0:
                    g.write(f'        if op==\\'{item}\\':return obj.{item}\\n')
                else:
                    g.write(f'        elif op==\\'{item}\\':return obj.{item}\\n')
                s+=1
            k+=1
    module_dict,sub_dict=Read_ex_func()
    g.write("    elif 'Ex_module' in stype:   #代表是Ex_module，<class '__main__.Ex_module'>\\n        module_name=obj.module_name\\n")
    k = 0
    for module_name in module_dict:
        if k == 0:
            g.write(f'        if module_name=="{module_name}":\\n')
        else:
            g.write(f'        elif module_name=="{module_name}":\\n')
        s = 0
        for sub_term in module_dict[module_name]:
            if s == 0:
                g.write(f'            if op==\\'{sub_term}\\':return {module_name}.{sub_term}\\n')
            else:
                g.write(f'            elif op==\\'{sub_term}\\':return {module_name}.{sub_term}\\n')
            s += 1
        if s==0:   #代表沒有sub_term
            g.write(f'            pass\\n')
        k += 1
    g.write('    obj_name=obj.__name__\\n    if op=="__name__":return obj_name\\n')
    k = 0
    for sub_element in sub_dict:
        if k == 0:
            g.write(f'    if obj_name=="{sub_element}":\\n')
        else:
            g.write(f'    elif obj_name=="{sub_element}":\\n')
        s = 0
        for sub_term in sub_dict[sub_element]:
            if s == 0:
                g.write(f'        if op==\\'{sub_term}\\':return obj.{sub_term}\\n')
            else:
                g.write(f'        elif op==\\'{sub_term}\\':return obj.{sub_term}\\n')
            s += 1
        if s==0:   #代表沒有sub_term
            g.write(f'        pass\\n')
        k += 1
    g.write("    print(f'{bcolors.FAIL}apython built_in error:\\\\n    {obj} has no attribute {op} {bcolors.RESET}')\\n    raise Exception\\n")
    g.close()
build()
'''
def test_and_build():
    f=open('test_error.txt','w',encoding='utf-8')
    f.write("#encoding='utf-8'\ndatas=[]")
    k=1
    for key in built_in:
        data=built_in[key]
        f.write(f'\ntype{k}="{key}"')
        f.write(f'\nexample{k}='+data['example'])
        f.write(f'\nabox{k}=[]')
        f.write(f'\nfbox{k}=[]')
        if data['attr'] != '':
            attrs = data['attr'].split(',')
            for item in attrs:
                f.write(f'\ntry:\n    abox{k}.append(example{k}.{item}.__name__)\nexcept:\n    pass')
        if data['function']!='':
            functions = data['function'].split(',')
            for item in functions:
                f.write(f'\ntry:\n    fbox{k}.append(example{k}.{item}.__name__)\nexcept:\n    pass')
        f.write(f'\ndatas.append((type{k},abox{k},fbox{k}))')
        k+=1
    f.write(build_template)
    f.close()
test_and_build()
system('py test_error.txt')