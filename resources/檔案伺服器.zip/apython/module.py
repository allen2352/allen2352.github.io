#基本型態:
class Integer:                         #整數
    def __init__(self,number):
        self.number=int(number)
    def __str__(self):
        return f'{self.number}'
    def write(self,codes):
        self.location=str(self.number)
class Float:                          #浮整數
    def __init__(self,number):
        self.number=float(number)
    def __str__(self):
        return f'{self.number}'
    def write(self,codes):
        self.location=str(self.number)
class String:                          #字串
    def __init__(self,text,change=True):    #change:自動改變\',\n符號
        self.text=text
        self.change=change
    def __str__(self):
        return f'"{self.text}"'
    def write(self,codes):
        if self.change:
            self.location=f'"{self.text}"'
        else:
            self.location=f"'{self.text}'"
class Byte:                          #字串
    def __init__(self,text):
        self.text=text
    def __str__(self):
        return f'"{self.text}"'
    def write(self,codes):
        codes.append(f'byte AX "{self.text}"')
        self.location=f'AX'
class Var_name:
    def __init__(self,name):           #變數名
        self.name=name
    def __str__(self):
        return f'{self.name}'
#通用變數型態
class Namespace:
    def __init__(self,namespace=''):
        self.namespace=namespace
    def __str__(self):
        return f'{self.namespace}'
    def __eq__(self, other):
        return self.namespace==other
    def __contains__(self, item):
        return item in self.namespace
    def write(self,codes):
        if self.namespace!='':
            self.location=self.namespace
class Variable:
    def __init__(self,name,namespace):     #codeline是某段指稱變數
        self.namespace=namespace
        self.name=name
    def __str__(self):
        return f'<var={self.name}>'
    def write(self,codes):
        if self.namespace!='':
            self.namespace.write(codes)
            self.location=f'{self.namespace.location}.{self.name}'
        else:self.location=self.name
class SubVariable:                          #屬性指稱變數
    def __init__(self,obj,attr):
        self.obj=obj                 #任意物件
        self.attr=attr               #variable
    def __str__(self):
        return f'<obj={self.obj}  attr={self.attr}>'
    def write(self,codes):
        self.obj.write(codes)
        olocation=self.obj.location
        if '.' in olocation or '[' in olocation or olocation[0] in ('"',"'"):     #太長，或是字串
            codes.append(f'mov AX {self.obj.location}      ;此項過長或是字串')
            self.location = f'AX.{self.attr.name}'
        else:self.location=f'{self.obj.location}.{self.attr.name}'
class Slice:
    def __init__(self,start_obj,end_obj,step_obj):
        self.start_obj=start_obj
        self.end_obj=end_obj
        self.step_obj=step_obj
    def __str__(self):
        return '<slice>'
    def write(self,codes):
        codes.append('push [3]')
        self.start_obj.write(codes)
        codes.append(f'mov <esp+1>[0] {self.start_obj.location}')
        self.end_obj.write(codes)
        codes.append(f'mov <esp+1>[1] {self.end_obj.location}')
        self.step_obj.write(codes)
        codes.append(f'mov <esp+1>[2] {self.step_obj.location}')
        codes.append('pop *args')
        codes.append('mov **kwargs [dict]')
        codes.append('call slice')
        self.location='AX'
class IndexVariable:
    def __init__(self,name,slice_obj):      #[a1:a2,a1:,a3...] => [(a1,a2),(a1,None),a3...]
        self.name=name
        self.slice_obj=slice_obj    #單元素 or tuple
    def __str__(self):
        return f'<Index {self.name} slice={self.slice_obj}>'
    def write(self,codes):
        self.name.write(codes)
        codes.append(f'push {self.name.location}')
        self.slice_obj.write(codes)
        codes.append(f'mov BX {self.slice_obj.location}')
        codes.append('pop AX')
        self.location='AX[BX]'
#串列打包型態:
class List:
    def __init__(self,elements):
        self.elements=elements
    def __str__(self):
        box=[]
        for obj in self.elements:
            box.append(str(obj))
        return '<List  '+','.join(box)+'>'
    def __getitem__(self, j):
        if j<len(self.elements):
            return self.elements[j]
        raise StopIteration
    def __len__(self):
        return len(self.elements)
    def write(self,codes):
        codes.append(f'mov AX [{len(self.elements)}]')
        codes.append('push AX')
        for i in range(len(self.elements)):
            self.elements[i].write(codes)
            codes.append(f'mov <esp+1>[{i}] {self.elements[i].location}')
        codes.append('pop AX')
        self.location='AX'
class Tuple:
    def __init__(self, elements):
        self.elements = elements
    def __str__(self):
        box = []
        for obj in self.elements:
            box.append(str(obj))
        return '<Tuple  ' + ','.join(box) + '>'
    def __getitem__(self, j):
        if j < len(self.elements):
            return self.elements[j]
        raise StopIteration
    def __len__(self):
        return len(self.elements)
    def write(self, codes):
        codes.append(f'mov AX ({len(self.elements)})')
        codes.append('push AX')
        for i in range(len(self.elements)):
            self.elements[i].write(codes)
            codes.append(f'mov <esp+1>[{i}] {self.elements[i].location}')
        codes.append('pop AX')
        self.location = 'AX'
class Dict:
    def __init__(self,elements):  #[(key,value),...]
        self.elements=elements
    def __str__(self):
        box=[]
        for key,value in self.elements:
            box.append(f'{key}:{value}')
        return '<Dict  '+','.join(box)+'>'
    def __len__(self):
        return len(self.elements)
    def write(self,codes):
        codes.append('push [dict]')
        for key,value in self.elements:
            key.write(codes)
            codes.append(f'push {key.location}')
            value.write(codes)
            codes.append(f'pop BX')
            codes.append(f'mov <esp+1>[BX] {value.location}')
        codes.append('pop AX')
        self.location = 'AX'
class Set:                           #集合
    def __init__(self,elements):
        self.elements=elements
    def __str__(self):
        return '<set>'
    def write(self,codes):
        _tuple=Tuple(self.elements)
        _tuple.write(codes)
        codes.append(f'ex_func AX "set" {_tuple.location}')
        self.location='AX'
#高階打包型態:
def is_number(num):
    try:
        e=float(num)
        return True
    except:return False
class Lambda:
    def __init__(self,params,return_obj,namespace):
        self.params=params                   #{key:value,...}
        self.return_obj=return_obj
        self.namespace=namespace
    def __str__(self):
        return '<lambda>'
    def write(self,codes):
        tem_name = f'&lambda_{len(codes)}'
        _return=Backtrack(self.return_obj,'return')
        block_info=Info('')
        for key in self.params:
            block_info.add_info('var',Variable(key,''))
        block_info.codelines.append(_return)
        _def=Def(tem_name,self.params,block_info,self.namespace)
        _def.write(codes)
        if self.namespace == '':
            self.location=tem_name
        else:
            self.namespace.write(codes)
            loc=f'{self.namespace.location}.{tem_name}'
        #    codes.append(f'mov {loc} {tem_name}')
            self.location=loc
class Def:                                            #函數定義型態
    def __init__(self,fname,params,block_info,namespace):
        self.name=fname
        self.params=params        #{key:value,...}
      #  print('my params:',params)
        self.namespace = namespace
        self.codelines=block_info.codelines
        self.local_vars = block_info.locals
        self.in_class='^' in self.namespace
        self.orig_lines=('',0)
    def __str__(self):
        text=f'<Def {self.name}'
        vtext=[]
        for obj in self.codelines:
            vtext.append(str(obj))
        text+='{'+''.join(vtext)+'}'
        return text
    def write(self,codes):
        def get_name(string):
            sp='.[ ;'
            k,n=0,len(string)
            while k<n:
                if string[k] in sp:
                    return string[:k],string[k:]
                k+=1
            return string,''
        if self.namespace!='':                                 #宣告自己的程式開始位址(<class>,ip)
            self.namespace.write(codes)
            declare_func=[len(codes),'BX',len(codes)+2,self.namespace.location,0]
            codes.append(0)
            codes.append(f'mov {self.namespace.location}.{self.name} BX')
        else:
            declare_func = [len(codes),self.name, len(codes) + 1,None, 0]
            codes.append(0)
        codes.add_tab()
        skip_ip=len(codes)                      #上一行的程式需要跳過自己
        codes.append(0)             #額外1
        #程式開始前準備------------------------------------------------------------
        self.func_var=f'{self.name}_{skip_ip}'       #自己的堆疊
       # codes.append(f'push {self.func_var}')        #將自己上次的esp存起來
        codes.append('push **kwargs')
        codes.append('push *args')
        #開處處理參數
        i=0      #累計使用參數數量
        keybox=[]   #累計使用參數名
      #  print('#############')
       # print(self.params)
        #print('namespace:',self.namespace)
        class_obj=None
        params=tuple(self.params)
        for key in params:
            if self.in_class and class_obj==None:                 #若是class，擷取第一個參數
                class_obj=key
                continue
            if key[:2]=='**':   #代表是kwargs
                key_text=','.join(keybox)
                codes.append(f'**kwargs <esp+2>["{key[2:]}"] <esp+2> "{key_text}"')
                self.params[key[2:]]=self.params[key]
                del self.params[key]
                keybox.append(key[2:])
            elif key[0]=='*':
                codes.append(f'*args <esp+2>["{key[1:]}"] <esp+1> {i}')
                self.params[key[1:]] = self.params[key]
                del self.params[key]
                keybox.append(key[1:])
            else:
                keybox.append(key)
                codes.append('cmp CX 0')
                skip_param=len(codes)
                codes.append(0)
                codes.append(f'tf <esp+2> "in" "{key}"')     #查看key是否在已有參數中
                skip_param2=len(codes)
                codes.append(0)
                self.params[key].write(codes)
                codes.append(f'mov <esp+2>["{key}"] {self.params[key].location}')
                codes.append(f'jmp {len(codes)+2}')
                codes[skip_param]=f'$jmp {len(codes)-1} "!="'
                codes.append(f'mov <esp+2>["{key}"] <esp+1>[{i}]')
                codes.append('dec CX')
                codes[skip_param2]=f'$jmp {len(codes)-1} "t"'
                i+=1
        #計算非param的local數量
        local_num = 0
        local_dict = {}
        for key in self.params:
            local_num+=1
            local_dict[key]=local_num             #將自己參數加入
        for var in self.local_vars:
            if var not in self.params and var not in local_dict:
                local_num+=1
                local_dict[var]=local_num
        declare_func[4]=local_num+1
        codes[declare_func[0]]=f'Function {declare_func[1]} {declare_func[2]} {declare_func[3]} "{self.func_var}" {declare_func[4]}'    #新建陣列[0,1,2,3,...]
        #--------------------------------------------------------------------地點(名字)，ip，class_obj,local_num+1,...
        return_ips=[]
        #真正的程式開始----------------------------------------------------------------------------------參數移動
        codes.append(f'')
        for key in self.params:
            if key!=class_obj:
                #if key[:2]=='**':
                #    codes.append(f'mov <{self.func_var}+{local_dict[key]}> <esp+2>["{key[2:]}"]')
                #elif key[0]=='*':
                #    codes.append(f'mov <{self.func_var}+{local_dict[key]}> <esp+2>["{key[1:]}"]')
                #else:
                codes.append(f'mov <{self.func_var}+{local_dict[key]}> <esp+2>["{key}"]')
        yield_ip = len(codes)
        codes.append(0)  # 這裡進行2選一，以程式中是否有yield作為判斷
        codes.append(0)
        # 真正的程式開始--------------------------------------------------------------------------------------
        have_yield=False
        p = len(codes)
        for obj in self.codelines:
            obj.write(codes)             #每一段void_code都是獨立的
        def save_gen(num):
            if len(add_Function)>0 and num not in add_Function[-1][1]:
                add_Function[-1][1].append(num)
            if len(add_Generator)>0 and num not in add_Generator[-1][1]:
                add_Generator[-1][1].append(num)
    #------------------------------------------------------------------------------------程式組態設定
        def in_global(word):
            for items in global_words:
                if word in items:
                    return True
            return False
        add_Generator=[]            #內容:(len(codes),)
        add_Function=[]         #自己有哪些子涵數?要在這些子涵數的標投欄添加自己參數的堆疊名稱
        global_words=[[]]      #當自己或子涵數宣告global時，不可做參數替換
        nonlocal__words=[]     #自己所宣告的nonlocal word，不可做參數替換
        nonlocal_ips=[]       #自身宣告nonlocal時的ip，
        not_abort=[]                         #不可在程式結束後從堆疊銷毀的變數，包含add_Generator,add_Function
        def parse_line(line):
            box=[]
            k,n=0,len(line)
            while k<n:
                p=k
                if line[p] in ('"',"'"):
                    c=line[p]
                    k=p+1
                    while line[k]!=c:
                        if line[k]=='\\':k+=1
                        k+=1
                    k+=1
                while k<n and line[k]!=' ':k+=1
                box.append(line[p:k])
                k+=1
            return box
        for i in range(len(codes)-p):
            line=codes[p+i]
            if '"' in line or "'" in line:
                deal=parse_line(line)
            else:
                deal=line.split(' ')
            if deal[0]=='return':           #處理return
                return_ips.append(p+i)
                continue
            elif deal[0]=='global':
                global_words[-1].append(deal[1])           #註記global，進入其他function時，不可進行參數替換
          #      print(p+i,deal[1])
            elif deal[0]=='nonlocal':          #自己標記的nonlocal
                nonlocal__words.append(deal[1])
                nonlocal_ips.append(p+i)
         #       print(p+i,deal[1])
            if deal[0] == 'yield':
                deal[0] ='Yield'     #將yield換成Yield表示被處理過
                have_yield=True
            elif deal[0]=='Function':                                 #有子涵數會用到自己的變數
                add_Function.append((p+i,[]))
                global_words.append([])
            elif deal[0]=='Generator':                                 #有子涵數會用到自己的變數
                add_Generator.append((p+i,[]))
            elif deal[0]=='end':
                if deal[1]=='"Function"':          #儲存結果
                    f_row,items=add_Function[-1]
                    if len(items)>0:                #有東西才儲存
                        not_abort+=items                    #因為有子涵數用到自己的參數，因此在自己結束後，這些參數不在堆疊中進行銷毀
                        func_add_text=f' "{self.func_var}"'    #加上""以免被判定為數值
                        codes[f_row]=codes[f_row]+func_add_text
                  #  print('------------------item:',items)
                    del add_Function[-1]
                   # print(f'{self.name} before del:',global_words)
                    del global_words[-1]
                elif deal[1]=='"Generator"':          #儲存結果
                    g_row,items=add_Generator[-1]
                    if len(items)>0:                #有東西才儲存
                        not_abort += items  # 因為有子涵數用到自己的參數，因此在自己結束後，這些參數不在堆疊中進行銷毀
                        gen_add_text=f' "{self.func_var}"'    #加上""以免被判定為數值
                        codes[g_row]=codes[g_row]+gen_add_text
                    del add_Generator[-1]
                continue
            for j in range(len(deal)):                      #將自己的變數做替換
                if j==0 or deal[j]=='':continue
                if deal[j][0] in ('"',"'"):   #代表是字串
                    continue
                if deal[j][0]==';':     #代表是註解
                    break
                var,back=get_name(deal[j])
                if not in_global(var) and var not in nonlocal__words:
                    if var == '': break
                    elif var==class_obj:
                        deal[j]=f'<{self.func_var}+0>'+back
                       # deal.append(f'        ;此為class obj')
                        save_gen(local_num+4)
                    elif var in self.params:                     #自己的參數
                        deal[j]=f'<{self.func_var}+{local_dict[var]}>'+back
                      #  deal.append(f'        ;這個參數為  {var}')
                        save_gen(local_dict[var])
                    elif var in self.local_vars:
                        deal[j]=f'<{self.func_var}+{local_dict[var]}>'+back
                      #  deal.append(f'        ;這個參數為  {var}')
                        save_gen(local_dict[var])
            codes[p+i]=' '.join(deal)
        need_abort=[]
        for i in range(local_num+1):
            if i not in not_abort:
                need_abort.append(str(i))
        #---------------------------------------------------------------清除nonlocal，以免被其他function(父函數)讀取
        for non_ip in nonlocal_ips:
            codes[non_ip]=''
        #----------------------------------------------------------------------------------------------------------
        # return後直達程式結束
        endip = len(codes)
        if len(return_ips)>0 and return_ips[-1]==endip-1:
            for rip in return_ips:
                codes[rip]=f'jmp {endip-1}         ;return點'
        else:
            for rip in return_ips:
                codes[rip]=f'jmp {endip}'
            if have_yield:
                codes.append('mov AX ""')
            else:
                codes.append('mov AX None')            #return None
        #還原堆疊，return_ip跳到此
        if have_yield:             #如果有yield，則return AX，並且發生錯誤
            stopiteration=FuncCall(Variable('StopIteration',''),List([Variable('AX','')]),Dict({}))
            _raise=Backtrack(stopiteration,'raise')
            _raise.write(codes)
            codes.append('stop     ;理論上不會執行到這一行')
         #   codes.append(f'$mov esp "+" 1      ;確保從raise後可離開')
          #  codes.append('pop ip')
            codes[yield_ip] = f'Generator AX {yield_ip + 2} "{self.func_var}"'  # Generator地點，始ip，要儲存的堆疊名稱
            codes[yield_ip + 1] = f'jmp {len(codes) - 1}      ;因為是yield，直接跳到pop ip'  # 跳到pop ip
            codes.append('end "Generator"')  # 組譯器語言，給自己看的
        else:
            codes[yield_ip] = ''  # f'$mov esp "-" {local_num}'                                        #正常情況
            codes[yield_ip + 1] = ''  # f'mov {self.func_var} esp'
        #----------------------------------------------------------------如果有yield，則直接跳到pop ip
        codes.append(f'$mov esp "+" 2           ;準備離開函數')
        if have_yield:
            codes.append(f'end "Function" "{self.func_var}"')           #因為還要進來，因此不刪除自身任何變數
        else:
            codes.append(f'end "Function" "{self.func_var}" '+'"'+','.join(need_abort)+'"')        #在這裡之後就不用再替換變數了
        codes.append('pop ip')       #pop ip跳到程式最後一行return
        codes.del_tab()
        codes[skip_ip]=f'jmp {len(codes)-1}           ;跳過此函數'
class FuncCall:                                       #函數呼叫型態
    def __init__(self,name,args,kwargs,s_args=None,s_kwargs=()):  #name,args,kwargs都是obj型態
        self.name=name
        self.args=args
        self.kwargs=kwargs
        self.s_args=s_args
        self.s_kwargs=s_kwargs
        self.orig_lines=('',0)
    def __str__(self):
        return f'<Call {self.name} args={self.args} kwargs={self.kwargs}>'
    def __getitem__(self, item):
        return IndexVariable(Variable('AX',''),Integer(item))
    def write(self,codes):
        def deal_cx_args_kwargs(args,call_name):
            codes.append(f'push {len(args)}        ;儲存CX')  # 不包含，就全推
            args.write(codes)
            codes.append(f'push {args.location}  ;為call {call_name} 做準備', simplify=self.in_class)
            if self.s_args != None:
                self.s_args.write(codes)
                codes.append(f'ex_func AX "list" {self.s_args.location}')    #AX轉為陣列
                codes.append(f'ex_func BX "len" AX')     #BX為陣列長度
                codes.append('$mov <esp+2> "+" BX')       #原CX增加
                codes.append('$mov <esp+1> "+" AX')       #AX增加
            self.kwargs.write(codes)
            if len(self.s_kwargs)>0:
                codes.append(f'push {self.kwargs.location}')
                for s_kwargs in self.s_kwargs:
                    s_kwargs.write(codes)
                    codes.append('mov *args [1]')
                    codes.append(f'mov *args[0] {s_kwargs.location}')
                    codes.append('mov **kwargs [dict]')
                    codes.append('call <esp+1>.update')
                codes.append('pop **kwargs')
            else:
                codes.append(f'mov **kwargs {self.kwargs.location}')
            codes.append('pop *args')
            codes.append(f'pop CX     ;取回CX')  # 批次讓Def載入參數
            if need_push_name:
                codes.append('pop AX')
                codes.append('call AX')
            else:
                codes.append(f'call {call_name}')
        codes.append('',self.orig_lines)
        self.name.write(codes)
        self.in_class = '^' in self.name.location       #function call的namespace包含在name中
        need_push_name=self.name.location[:2]=='AX' or '&' in self.name.location
        if need_push_name:codes.append(f'push {self.name.location}')
        if self.in_class:
            space,name=self.name.location.split('.')
            codes.append(f'tf {space} "Ctn" "{name}"')    #查看此函數是否包含name這個function
            jmp_if_true=len(codes)          #包含就跳
            codes.append(0)
            #---------------------------------------------------因為不包含，所以呼叫外部function
            deal_cx_args_kwargs(self.args,name)
            jmp_leave=len(codes)
            codes.append(0)
            #-----------------------------------------------------------------有包含，推args[1:]並呼叫
            codes[jmp_if_true]=f'$jmp {len(codes)-1} "t"'
            args=List(self.args.elements[1:])     #若包含，就只推[1:]
            deal_cx_args_kwargs(args,self.name.location)
            #-------------------------------------------------------離開
            codes[jmp_leave]=f'jmp {len(codes)-1}'
        else:                                                     #-----------------------------不在class裡的正常模式中
            deal_cx_args_kwargs(self.args,self.name.location)
        self.location='AX'
class Backtrack:           #回傳
    def __init__(self,value,cmd):
        self.A=value
        self.cmd=cmd
        self.orig_lines=('',0)
    def __str__(self):
        return f'<{self.cmd} {self.A}>'
    def write(self,codes):
        self.A.write(codes)
        if self.A.location!='AX':
            codes.append(f'mov AX {self.A.location}')
        codes.append(f'{self.cmd} AX',self.orig_lines)
        self.location='AX'
class Var_declare:                      #變數的各種宣告
    def __init__(self,value,cmd):      #del,global,nonlocal
        self.value=value
        self.cmd=cmd
    def __str__(self):
        return f'<{self.cmd} {self.value}>'
    def write(self,codes):
        self.value.write(codes)
        if self.cmd=='del':
            if '.' in self.value.location:     #XXX.attr
                class_obj,key=self.value.location.split('.')
                codes.append(f'del 2 {class_obj} "{key}"')
            elif self.value.location[:3]=='AX[':    #AX[BX]
                codes.append('del 1 AX BX')
            else:
                codes.append(f'del 0 {self.value.location} None')
        else:
            codes.append(f'{self.cmd} {self.value.location}')
class Try_Except:
    def __init__(self,try_codelines,except_objects,else_codelines=(),finally_codelines=(),namespace=''):   #except_dict:{error_term:(as_name,codelines) }
        self.try_codelines=try_codelines
        self.except_objects=except_objects
        self.else_codelines=else_codelines
        self.finally_codelines=finally_codelines               #即使except沒抓到錯誤，也必定會執行，然後才產生錯誤
        self.namespace=namespace
        self.orig_lines = []
    def __str__(self):
        return f'<Try Except>'
    def write(self,codes):
        ol=0
        to_finally_ip=len(codes)               #宣告必定得要執行的finally位置
        codes.append(0,self.orig_lines[ol])   #finally ip
        to_except_ip=len(codes)                                     #try error_ip
        codes.append(0)   #try except_ip
        #----------------------------------------------**參數蒐集箱
        SD = {'continue': [], 'break': [], 'return': []}        #全域蒐集
        yield_box=[]                                            #只處理try中的
        #----------------------------------------開始寫try
        start_p=len(codes)                                 #開始檢查的基底p
        codes.add_tab()
        for obj in self.try_codelines:
            obj.write(codes)
        codes.del_tab()
        ol+=1
        for i in range(len(codes)-start_p):                    #---------------------------------處理try中yield
            cmd = codes[start_p+i].split(' ')[0]
            if cmd=='yield':
                yield_box.append(start_p+i)
        #----------------------------------------
        codes.append('try "end"')           #停止try
        try_leave = len(codes)                               # -----------------跳到else
        codes.append(0)
        #-----------------------------------------開始寫except
        if self.namespace!='':
            self.namespace.write(codes)
            ispace=f'{self.namespace.location}.'
        else:ispace=''
        e=0
        try_except_ip = f'try {len(codes) - 1}'
        try_push_0= []
        jmp_push_0=[]
        jmp_push_1 = []  # 收集從except結束通往finally的ip
        for i in range(len(self.except_objects)+1):            #(obj,as_name,codelines)
            if e==0:
                codes[to_except_ip]=try_except_ip
                e=1
            else:
                codes[to_except_ip] = f'$jmp {len(codes) - 1} "f"'
            if i<len(self.except_objects):
                codes.append('', self.orig_lines[ol])
                ol += 1
                error_data = self.except_objects[i]
                error_data[0].write(codes)
                codes.append(f'error {error_data[0].location}')
                to_except_ip=len(codes)
                codes.append(0)
                if error_data[1]!=None:            #代表有as
                    codes.append(f'mov {ispace}{error_data[1]} $Exception')
                codes.append('mov $Exception 0')               #清空Exception
                #---------------------------------except內容開始
                try_push_0.append(len(codes))
                codes.append(0)
                codes.add_tab()
                for obj in error_data[2]:
                    obj.write(codes)
                codes.del_tab()
                codes.append('try "end"')
                jmp_push_1.append(len(codes))
                codes.append(0)
            else:                     #執行到此代表錯誤都沒有被抓到
                jmp_push_0.append(len(codes))              #直接跳到push 0
                codes.append(0)
                #_raise=Raise(Variable('$Exception',''))
                #_raise.write(codes)
        # -------------------------------處理try中的yield
        for yield_ip in yield_box:
            codes[yield_ip]=f'jmp {len(codes)-1} ;處理try中的yield'
            codes.append('try "end"')
            codes.append('yield AX          ;try中的yield改到這裡')
            codes.append(try_except_ip)
            codes.append(f'jmp {yield_ip}     ;返回try中的yield下一行')
        #--------------------------------------------------開始寫else
        jmp_to_finally=[]
        codes[try_leave]=f'jmp {len(codes)-1}    ;try正常結束，跳到else'
        if len(self.else_codelines) > 0:
            codes.append('',self.orig_lines[ol])
            ol+=1
            codes.add_tab()
            try_push_0.append(len(codes))
            codes.append(0)
            for obj in self.else_codelines:
                obj.write(codes)
            codes.append('try "end"')
            codes.del_tab()
        push_1=len(codes)-1
        for jp0 in jmp_push_1:
            codes[jp0]=f'jmp {push_1}  ;跳到push 1'
        codes.append('push None  ;推入None')  # 平衡一下return，沒東西也要push
        codes.append('push 1     ;代表正常')
        jmp_to_finally.append(len(codes))
        codes.append(0)
        #-------------------------#處理continue,break,return
        stype_SD={}
        for i in range(len(codes)-start_p):                    #---------------------------------處理try,except,else中的continue,break,return
            if type(codes[start_p+i])==str:
                cmd = codes[start_p+i].split(' ')[0]
                if cmd in SD:
                    SD[cmd].append(start_p+i)
        stype=2
        for key in SD:
            if len(SD[key])>0:
                jmp_ip = len(codes)-1
                for ip in SD[key]:
                    codes[ip]=f'jmp {jmp_ip}'
                if key=='return':
                    codes.append('push AX')
                else:
                    codes.append('push None')        #平衡一下return，沒東西也要push
                codes.append('try "end"')  # 停止try
                codes.append(f'push {stype}')
                jmp_to_finally.append(len(codes))
                codes.append(0)                       #jmp to_finally
                #進行註冊
                stype_SD[stype]=key
                stype+=1
        #-------------------------收集所有錯誤進來者
        push_0= len(codes) - 1
        for tp0 in try_push_0:
            codes[tp0]=f'try {push_0}'
        for jp0 in jmp_push_0:
            codes[jp0]=f'jmp {push_0} ;push 0'
        codes.append('push None')  # 平衡一下return，沒東西也要push
        codes.append('push 0')
        #--------------------------------------------------------------------------開始寫finally
        finally_ip=len(codes)-1
        codes[to_finally_ip]=f'finally {finally_ip}'
        for jtf in jmp_to_finally:
            codes[jtf]=f'jmp {finally_ip}    ;跳到finally'
        codes.append(f'finally -{finally_ip}')
        finally_p=len(codes)
        if len(self.finally_codelines)>0:
            codes.append('push $Exception')        #儲存錯誤訊息
            codes.append('mov $Exception 0')
            codes.append('', self.orig_lines[ol])
            ol += 1
            codes.add_tab()
            for obj in self.finally_codelines:
                obj.write(codes)
            codes.del_tab()
          #  codes.append('pop $Exception')        #取回錯誤訊息
        #-------------------------------抓取finally中的continue(實際不出現)，break，return
        finally_events={'continue':[],'break':[],'return':[]}
        for i in range(len(codes)-finally_p):                    #---------------------------------處理try中yield，強制淨化之前的效果
            if type(codes[finally_p+i])==str:
                cmd = codes[finally_p+i].split(' ')[0]
                if cmd in finally_events:
                    finally_events[cmd].append(finally_p+i)
        #-------------------------------------處理之前push的關鍵詞，此處為中間沒有break或return中斷的後續
        if len(self.finally_codelines)>0:
            codes.append('pop $Exception')  # 取回錯誤訊息
        codes.append('pop AX')
        leave_SD={}
        for stype in stype_SD:
            codes.append(f'cmp AX {stype}')
            leave_SD[len(codes)]=stype_SD[stype]
            codes.append(0)
        codes.append('cmp AX 1')
        jmp_to_leave=len(codes)
        codes.append(0)
        codes.append('pop AX')                             #從0走至此，還原堆疊
        _raise=Backtrack(Variable('$Exception', ''),'raise')
        _raise.write(codes)
        #--------------------------------
        for key in finally_events:            #從finally中break或return的事件
            if len(finally_events[key])>0:
                jmp_ip=len(codes)-1
                for ip in finally_events[key]:
                    codes[ip]=f'jmp {jmp_ip}       ;跳至finally中的事件:{key}'
                codes.append('$mov esp "+" 3')    #去除關鍵詞，無論先前是甚麼都不重要(回傳值None,判斷值0,錯誤error)
                codes.append(key)
        #---------------------------------
        for lip in leave_SD:                        #從try,except,else中的continue,break,return事件
            codes[lip]=f'$jmp {len(codes)-1} "=="'                   #從2,3,4離開至此
            codes.append('pop $Exception')  # 取回錯誤訊息
            codes.append('pop AX')                     #還原AX堆疊
            codes.append(leave_SD[lip])
        #--------------------------------
        codes[jmp_to_leave]=f'$jmp {len(codes)-1} "=="'            #從1離開至此
        codes.append('pop AX')                          #還原AX堆疊
        codes.append('end "finally_yield"')
class With:
    def __init__(self,call_obj,orig_as_name,as_name,with_codelines,namespace):
        self.call_obj=call_obj
        self.orig_as_name=orig_as_name
        self.as_name=as_name
        self.with_codelines=with_codelines
        self.namespace=namespace
        self.orig_lines = ('', 0)
    def __str__(self):
        return '<with>'
    def write(self,codes):
        codes.append('',self.orig_lines)
        codes.add_tab()
        self.orig_as_name.write(codes)
        self.call_obj.write(codes)    #定義好參數args和kwargs，push ip,call (<class>,ip)
        codes.append(f'mov {self.orig_as_name.location} {self.call_obj.location}')
       # codes.append('stop')
        _enter_call=FuncCall(Variable(f'{self.orig_as_name.location}.__enter__',''),List([]),Dict({}))       #會先push ip再call，故類別位置為<esp+2>
        _enter_call.write(codes)
        if self.as_name!=None:                          #as_name獲取__enter__所回傳的東西
            codes.append(f'push {_enter_call.location}')
            self.as_name.write(codes)
            codes.append(f'pop {self.as_name.location}')
        #--------------------------------------------------------------------
        try_codelines=self.with_codelines
        except_objects=[]
        else_codelines = []            #當前堆疊:<class_obj>,(finally的return物件),stype,此function所push的ip，故要呼叫位置為<esp+4>
        _exit_call = FuncCall(Variable(f'{self.orig_as_name.location}.__exit__', ''), List([TFN(None), TFN(None), TFN(None)]), Dict({}))
        finally_codelines =[_exit_call]
        _try_except=Try_Except(try_codelines,except_objects,else_codelines,finally_codelines)
        _try_except.orig_lines=[('',0),('',0),('',0)]
        _try_except.write(codes)
        codes.del_tab()
        #codes.append('inc esp     ;還原with的<class_obj物件>')
class Stop:
    def __init__(self):
        pass
    def __str__(self):
        return '<$stop>'
    def write(self,codes):
        codes.append('stop')
class Command:
    def __init__(self,cmd_list):
        self.cmd_list=cmd_list
    def __str__(self):
        return f'<cmd_list>'
    def write(self,codes):
        for cmd in self.cmd_list:
            codes.append(cmd)
class sub_if_else:
    def __init__(self,event,true_item,false_item):           # A if B else C
        self.event=event
        self.true_item=true_item
        self.false_item=false_item
    def __str__(self):
        return f'<A if else B>'
    def write(self,codes):
        self.event.write(codes)
        codes.append(f'cmp {self.event.location} 1')
        jne_false=len(codes)
        codes.append(0)
        self.true_item.write(codes)
        if self.true_item.location!='AX':
            codes.append(f'mov AX {self.true_item.location}   ;true item')
        leave_ip=len(codes)
        codes.append(0)
        codes[jne_false]=f'$jmp {len(codes)-1} "!="   ;跳到false'
#        print('false item:',self.false_item)
        self.false_item.write(codes)
 #       print('location:',self.false_item.location)
        if self.false_item.location!='AX':
            codes.append(f'mov AX {self.false_item.location}   ;false item',simplify=1)   #下一行可能會mov item AX，會被簡化導致錯誤
        codes[leave_ip]=f'jmp {len(codes)-1}   ;離開sub_if_else'
        self.location='AX'
class If_else:                                        #if,else型態
    def __init__(self,if_items,else_codelines):     #if_items=[[event_obj,codelines],...]
        self.if_items=if_items
        self.else_codelines=else_codelines
        self.orig_lines=[]
    def __str__(self):
        text=[f'if {self.if_items[0][0]}:']
        for obj in self.if_items[0][1]:text.append(str(obj))
        for i in self.if_items[1:]:
            text.append(f'elif {i[0]}:')
            for obj in i[1]:text.append(str(obj))
        if len(self.else_codelines)>0:
            text.append('else:')
            for obj in self.else_codelines:text.append(str(obj))
        return ''.join(text)
    def write(self,codes):
        need_set_end=[]
        ol=0
        for event,block in self.if_items:
            codes.append('',self.orig_lines[ol])
            ol+=1
            event.write(codes)          #進行條件運算
            codes.append(f'cmp {event.location} 1')
            codes.add_tab()
            jip=len(codes)
            codes.append(0)                         #jne條件被否定時跳到下一句判斷
            for obj in block:obj.write(codes)       #條件成立則繼續執行
            need_set_end.append(len(codes))         #執行結束直接跳至底部
            codes.append(0)
            codes[jip]=f'$jmp {len(codes)-1} "!="        ;跳到下一句判斷'          #下一句判斷的位置
            codes.del_tab()
        if len(self.else_codelines)>0:
            codes.append('',self.orig_lines[ol])
            codes.add_tab()
            for obj in self.else_codelines:obj.write(codes)               #結束執行
            codes.del_tab()
        for ip in need_set_end:
            codes[ip]=f'jmp {len(codes)-1}        ;跳至底部'           #設定底部
class While:                                          #while型態
    def __init__(self,event,codelines,else_codelines):
        self.event=event
        self.codelines=codelines
        self.else_codelines=else_codelines
        self.orig_lines=('',0)
    def __str__(self):
        return f'event:{self.event} do:{self.codelines}'
    def write(self,codes):
        again_ip=len(codes)
        codes.append('',self.orig_lines)
        self.event.write(codes)
        codes.append(f'cmp {self.event.location} 1')
        codes.add_tab()
        out_ip=len(codes)
        codes.append(0)          #不是True，跳出迴圈
        break_box=[]
        for obj in self.codelines:
            p=len(codes)
            obj.write(codes)
            for i in range(len(codes)-p):
                cmd=codes[p+i].split(' ')[0]
                if cmd=='continue':
                    codes[p+i]=f'jmp {again_ip-1}'     #continue跳回開頭
                elif cmd=='break':
                    break_box.append(p+i)
        codes.append(f'jmp {again_ip-1}               ;continue重來')     #重來
        #----------------------------------------
        to_else_ip=len(codes)-1
        codes[out_ip]=f'$jmp {to_else_ip} "!="'              #在while判定為False時，跳到else
        for obj in self.else_codelines:
            obj.write(codes)
        #----------------------------------------
        break_ip=len(codes)-1
        for b_ip in break_box:
            codes[b_ip]=f'jmp {break_ip}          ;break出'
        codes.del_tab()
class sub_for_loop:
    def __init__(self,express,vnames,base_obj,if_obj,is_list):
        self.express=express
        self.vnames=vnames
        self.base_obj=base_obj
        self.if_obj=if_obj
        self.is_list=is_list
    def __str__(self):
        return '<sub for loop>'
    def write(self,codes):
        _yield=Backtrack(self.express,'yield')        #express非賦值變數，不用註冊
        if self.if_obj!=None:
            _if=If_else([[self.if_obj,[_yield]]],[])
            _if.orig_lines=[('',0),('',0),('',0)]
            _for_loop=For_loop(self.vnames,self.base_obj,[_if],[])
        else:
           # print(self.vnames)
          #  print(self.base_obj)
            _for_loop = For_loop(self.vnames, self.base_obj, [_yield],[])
        info = Info('')
        for var in self.vnames:
            info.add_info('var', var)
        info.write(_for_loop,('',0))
        id=len(codes)
        fDef=Def(f'&generator_{id}',{},info,'')      #function本身不會被其他物件呼叫，不需要namespace，&以len(codes)作為標誌，不會找錯
        fDef.write(codes)
        codes.append('push 0        ;儲存CX')
        codes.append('push [0]')
        codes.append('mov **kwargs [dict]')
        codes.append('pop *args')
        codes.append('pop CX     ;取回CX')
        codes.append(f'call &generator_{id}')
#        fcall=FuncCall(Variable(f'&generator_{id}',''),List([]),Dict({}))
 #       fcall.write(codes)
        if self.is_list:
            codes.append(f'ex_func AX "list" AX')
        self.location='AX'
class For_loop:                                       #for,loop型態
    def __init__(self,vnames,base_obj,codelines,else_codelines):                 #varuables=[name1,name2,...]
        self.vnames=vnames
        self.base_obj=base_obj
        self.codelines=codelines
        self.else_codelines=else_codelines
        self.orig_lines=('',0)
    def __str__(self):
        return '<For loop>'
    def write(self,codes):
        self.base_obj.write(codes)
        #base_obj_name=f'&base_obj_{len(codes)}'
        codes.append(f'ex_func AX "iter" {self.base_obj.location}',self.orig_lines)                        #將base_obj轉為iter存起來
        codes.add_tab()
        codes.append('push AX')
       # codes.append('stop')
        #-------------------------------
        again_ip=len(codes)                           #每一圈的起始點
        codes.append(f'fetch AX <esp+1>')                                           #從base_obj取出一個值到AX，取出成功時TF=1，否則TF=0
        leave_ip=len(codes)                             #比較發現無法取出東西跳出
        codes.append(0)
        if len(self.vnames)==1:                                  #開始分配參數
            self.vnames[0].write(codes)
            codes.append(f'mov {self.vnames[0].location} AX')
        else:
            #codes.append('mov AX <esp+3>[CX]')
            for i in range(len(self.vnames)):
                self.vnames[i].write(codes)
                codes.append(f'mov {self.vnames[i].location} AX[{i}]')
        #---------------------------------------------------------函數開始
        break_box = []
        return_box=[]
        for obj in self.codelines:
            p = len(codes)
            obj.write(codes)
            for i in range(len(codes) - p):
                cmd = codes[p + i].split(' ')[0]
                if cmd == 'continue':
                    codes[p + i] = f'jmp {again_ip - 1}'  # continue跳回開頭
                elif cmd == 'break':
                    break_box.append(p + i)
                elif cmd=='return':                   #此時要return的物件已經存在AX
                    return_box.append(p+i)
        codes.append(f'jmp {again_ip-1}')
        #-------------------------------------迴圈結束
        if len(return_box)>0:
            return_leave_ip=len(codes)                      #所有return都跳到這裡
            for r_ip in return_box:
                codes[r_ip]=f'jmp {return_leave_ip-1}'
            codes.append('inc esp')                       #還原堆疊
            codes.append('return AX')                       #補足return
        #-------------------------------------break或正常離開到此
        out_ip=len(codes)-1
        codes[leave_ip] = f'$jmp {out_ip} "f"'                  # 無法取出東西時，tf=0，跳至else
        for obj in self.else_codelines:
            obj.write(codes)
        #--------------------------------                   #中途break的直接跳出
        break_ip=len(codes)-1
        for b_ip in break_box:
            codes[b_ip] = f'jmp {break_ip}          ;break出迴圈'
        codes.append('inc esp')                                     #還原堆疊
        codes.del_tab()
class Mark:                    #標誌
    def __init__(self,mark):
        self.mark=mark
    def __str__(self):
        return f'<mark {self.mark}>'
    def write(self,codes):
        codes.append(self.mark)
class Pass:
    def __init__(self):
        pass
    def __str__(self):
        return '<pass>'
    def write(self,codes):
        pass
class TFN:                 #True,False,None
    def __init__(self,value):
        self.value=value
    def __str__(self):
        return f'<{self.value}>'
    def write(self,codes):
        self.location=self.value
class Class:
    def __init__(self,name,info,namespace,class_esp,father=None):
        self.name=name
        self.functions=info.funcs
        #for func_key in self.functions:
         #   self.functions[func_key].in_class=True
        self.codelines=info.codelines
        self.namespace=namespace
        self.class_esp=class_esp
        self.father=father
        self.orig_lines=('',0)
    def __str__(self):
        return f'<class {self.name}>'
    def write(self,codes):
        #codes.append('mov BX [func]',self.orig_lines)
       # set_ip=len(codes)
       # codes.append(0)
        if self.namespace!='':
            self.namespace.write(codes)
            codes.append(f'Function BX {len(codes) + 3} {self.namespace.location} "{self.class_esp}" 1', self.orig_lines)
            class_param=f'{self.namespace.location}.{self.name}'
            codes.append(f'mov {class_param} BX')
        else:
            class_param=self.name
            codes.append(f'Function {class_param} {len(codes) + 2} None "{self.class_esp}" 1', self.orig_lines)  # 地點(名字)，ip，class_obj
        codes.append(f'name {class_param} "<class \'__main__.{self.name}\'>"')     #註冊類別名稱
        codes.add_tab()
        skip_class_ip=len(codes)
        codes.append(0)                                           #跳過自己
        #------------------------------------------------------
        codes.append('tf $Inheritance "equ" None')          #判斷呼叫自己的人是否要繼承自己，用equ因為怕inheritance為undefined
        codes.append(f'$jmp {len(codes)+3} "t"')        #jt ip 'f'
        codes.append(f'mov <{self.class_esp}> $Inheritance')
        codes.append('push 1')              #要繼承
        codes.append(f'jmp {len(codes)+2}')
        codes.append(f'mov <{self.class_esp}> [class]')
        codes.append('push 0')
        codes.append('mov $Inheritance None')      #清空繼承
        # ------------------------------------------------------儲存CX,args,kwargs
        codes.append('push CX')
        codes.append('push *args')
        codes.append('push **kwargs')  # 先將宣告用的args和kwargs儲存起來
        #--------------------------------------------------------
        if self.father!=None:
            if type(self.father)==Tuple:
                deal=self.father.elements
            else:deal=[self.father]
           # print(deal)
            for father in deal:
                #-----------------------------在父函數write前要先push cx,args,kwargs
                father.write(codes)
                #------------------------------在call父函數前先取回參數
                codes.append('mov **kwargs <esp+1>')
                codes.append('mov *args <esp+2>')
                codes.append('mov CX <esp+3>')
                #------------------------------
                codes.append(f'mov $Inheritance <{self.class_esp}>')
                codes.append(f'call {father.location}')
        #------------------------------------------------------
        codes.append(f'type <{self.class_esp}> {class_param}')     #註冊自己的類別
        #進行區域物件宣告
        for obj in self.codelines:
            obj.write(codes)
        #-------------------------------------------------------
        #在所有函數宣告結束後，如果自己有建立__init__，就進入
        codes.append(f'mov AX <{self.class_esp}>')  # 取回自己class
        codes.append('pop **kwargs')
        codes.append('pop *args')
        codes.append('pop CX')
        #----------------------------------------
        codes.append('pop BX')           #取回繼承判斷
        codes.append('cmp BX 1')         #判斷是否繼承
        leave_init_ip=len(codes)
        codes.append(0)           #如果要繼承，就跳過init。$jmp ip "t"
        #----------------------------------------
        codes.append('tf AX "Ctn" "__init__"')             #是否包含__init__這個宣告?
        codes.append(f'$jmp {len(codes)+1} "t"')                 #如果包含init就call
        skip_init_ip=len(codes)
        codes.append(0)
        codes.append('call AX.__init__')
        codes.append(f'mov AX <{self.class_esp}>')                   #取回自己
        #------------------------------------------------------
        end=len(codes)-1
        codes[leave_init_ip]=f'$jmp {end} "=="'
        codes[skip_init_ip]=f'jmp {end}'
        codes.append(f'end "Function" "{self.class_esp}"')
        codes.append('pop ip')      #回去程式的宣告處
        #----------------------------------------------------------
        codes[skip_class_ip] = f'jmp {len(codes) - 1}'
        self.location='AX'
        codes.del_tab()
#資料移轉型態
def two_object_write(A,B,codes):
    A.write(codes)
    if A.location[:3] == 'AX.' or A.location=='AX':  # A為subvariable
        codes.append('push AX')
        B.write(codes)
        codes.append(f'mov BX {B.location}')
        codes.append('pop AX')
        blocation = 'BX'
    elif A.location[:3] == 'AX[':  # A為indexvariable，location必為AX[BX]
        codes.append('push AX')
        codes.append('push BX')
        B.write(codes)
        codes.append(f'mov DX {B.location}')
        codes.append('pop BX')
        codes.append('pop AX')
        blocation = 'DX'
    else:  # 正常情況
        B.write(codes)
        blocation = B.location
    return blocation
#class Mov:
#    def __init__(self,A,B,op='='):
#        self.A=A
#        self.B=B
##        cmd={'+=':'add','-=':'sub','*=':'mul','/=':'div','%=':'quo','//=':'rem','**=':'pow',
# #            '<<=':'shl','>>=':'shr','&=':'and','^=':'xor','|=':'or'}
#        if op=='=':
#            self.ctype=0
#            self.cmd='mov'
#        else:
#            self.ctype=1
#            self.cmd=op[:-1]     #將等號去除
#        self.orig_lines = ('', 0)
#    def __str__(self):
#        return f'<{self.cmd} {self.A} {self.B}>'
#    def write(self,codes):
#        codes.append('',self.orig_lines)
#        blocation=two_object_write(self.A,self.B,codes)
#        if self.ctype == 0:
#            codes.append(f'mov {self.A.location} {blocation}')
#        elif self.ctype == 1:
#            codes.append(f'$mov {self.A.location} "{self.cmd}" {blocation}')
class Multiple_Mov:
    def __init__(self,obj_list,target,op):
        self.obj_list=obj_list
        self.target=target
        if op == '=':
            self.ctype = 0
            self.cmd = 'mov'
        else:
            self.ctype = 1
            self.cmd = op[:-1]  # 將等號去除
        self.orig_lines = ('', 0)
    def __str__(self):
        return '<Multiple mov>'
    def write(self,codes):
        codes.append('', self.orig_lines)
        self.target.write(codes)
        codes.append(f'push {self.target.location}')
        for obj in self.obj_list:
            if type(obj) in (Tuple,List):
                for i in range(len(obj)):
                    obj[i].write(codes)
                    if self.ctype == 0:
                        codes.append(f'mov {obj[i].location} <esp+1>[{i}]')
                    elif self.ctype == 1:
                        codes.append(f'$mov {obj[i].location} "{self.cmd}" <esp+1>[{i}]')
            else:
                obj.write(codes)
                if self.ctype == 0:
                    codes.append(f'mov {obj.location} <esp+1>')
                elif self.ctype == 1:
                    codes.append(f'$mov {obj.location} "{self.cmd}" <esp+1>')
        codes.append('inc esp')          #還原堆疊
#運算型態
class Oper:
    def __init__(self,A,B,symbol):
        self.A=A
        self.B=B
        self.symbol=symbol#{'+':'add','-':'sub','*':'mul','/':'div','**':'pow','%':'quo','//':'rem','<<':'shl','>>':'shr','&':'and','^':'xor','|':'or'}[symbol]
       # self.oper=('+','-','*','/','**','%','//','<<','>>','&','^','|').index(symbol)
    def __str__(self):
        return f'<{self.A} {self.symbol} {self.B}>'
    def write(self,codes):
        self.A.write(codes)
        codes.append(f'push {self.A.location}')
        self.B.write(codes)
        codes.append(f'oper <esp+1> "{self.symbol}" {self.B.location}')
        codes.append('pop AX')
        self.location = 'AX'
#邏輯運算符
class Tf:   #真假判斷式
    def __init__(self,A,B,cmd):
        self.A=A
        self.B=B
        self.cmd=cmd
       # self.oper=('in','equ','Ctn','is').index(cmd)
    def __str__(self):
        return f'<{self.cmd} {self.A} {self.B}>'
    def write(self,codes):
       # print('tf:  ',self.A,self.B,self.cmd)
        blocation=two_object_write(self.A,self.B,codes)
        codes.append(f'tf {self.A.location} "{self.cmd}" {blocation}')    #B是否cmd在A
        codes.append('mov AX TF')
        self.location='AX'
class AndOr:
    def __init__(self,A,B,cmd):
        self.A=A
        self.B=B
        self.cmd=cmd
    def __str__(self):
        return f'<{self.cmd} {self.A} {self.B}>'
    def write(self,codes):
        self.A.write(codes)
        codes.append(f'cmp {self.A.location} 1')          #相同就繼續，否則跳至mov AX 0
        jip=len(codes)
        codes.append(0)
        self.B.write(codes)
        codes.append(f'cmp {self.B.location} 1')           #失敗就跳至mov AX 0
        lip = len(codes)
        codes.append(0)
        if self.cmd=='and':       #兩邊都要True，jip,lip為False時跳到0
            codes.append('mov AX 1')
            codes.append(f'jmp {len(codes)+1}')          #成功就跳過mov AX 0
            to_false=len(codes)-1
            codes.append('mov AX 0', simplify=1)
            codes[jip]=f'$jmp {to_false} "!="'
            codes[lip]=f'$jmp {to_false} "!="'
        elif self.cmd=='or':       #兩邊都要False，jip,lip為True時跳到1
            codes.append('mov AX 0')
            codes.append(f'jmp {len(codes) + 1}')  # 失敗就跳過mov AX 1
            to_true = len(codes) - 1
            codes.append('mov AX 1', simplify=1)
            codes[jip] = f'$jmp {to_true} "=="'
            codes[lip] = f'$jmp {to_true} "=="'
        self.location='AX'
class Deny:       #否定operator
    def __init__(self,A,cmd):
        self.A=A
        self.cmd=cmd
        #self.oper=('not','-','~').index(cmd)
    def __str__(self):
        return f'<{self.cmd} {self.A}>'
    def write(self,codes):
        self.A.write(codes)
        if self.A.location != 'AX':
            codes.append(f'mov AX {self.A.location}')
        codes.append(f'$oper AX "{self.cmd}"')
        self.location = 'AX'
#真假判斷符
class Bool:
    def __init__(self,enequalbox):     #enebox=[var,==,var,!=,var...]
        self.enebox=enequalbox
    def __str__(self):
        text=''
        for i in self.enebox:
            text+=str(i)
        return text
    def write(self,codes):
        k=0
        self.enebox[0].write(codes)           #計算第一個
        codes.append(f'push {self.enebox[0].location}')        #將結果存起來
        need_set_end=[]
        need_set_tf=[]
        cmp_dict={'==':'f','!=':'t','>':'<=','<':'>=','>=':'<','<=':'>'}            #否定時跳離符
        while k<len(self.enebox)-1:
            self.enebox[k+2].write(codes)             #計算第二個
            codes.append('pop DX')           #將第一個的結果放在DX  (上一個的結果可能在AX,AX[BX],xxx.attr)
            if self.enebox[k+1] in ('==','!='):
                codes.append(f'tf DX "equ" {self.enebox[k + 2].location}')
                need_set_tf.append((len(codes),cmp_dict[self.enebox[k+1]]))
            else:
                codes.append(f'cmp DX {self.enebox[k+2].location}')       #將第二個的值與第一個
                need_set_end.append((len(codes),cmp_dict[self.enebox[k+1]]))              #True就繼續比較下去，False則跳至mov AX 0
            codes.append(0)                            #若比較結果為False則跳離
            if k+3<len(self.enebox):
                codes.append(f'push {self.enebox[k+2].location}')        #將第二個結果的值存起來
            k+=2
        codes.append('mov AX True')                         #當條件成功到最後，設置AX為1
        codes.append(f'jmp {len(codes)+1}')                                     #跳過mov AX 0指令
        end = len(codes)-1  # 所有中間失敗的都跳到此行
        codes.append('mov AX False',simplify=1)                #中間失敗的都跳到此，設為False
        for i in need_set_end:
            codes[i[0]]=f'$jmp {end} "{i[1]}"'
        for i in need_set_tf:
            codes[i[0]]=f'$jmp {end} "{i[1]}"'
       # codes.append('dec esp')                       #堆疊指標回去一個
        self.location='AX'
#特殊功能函數
class Assert:
    def __init__(self,event,msg):
        self.event=event
        self.msg=msg
        self.orig_lines = ('', 0)
    def __str__(self):
        return f'<assert {self.event}, {self.msg}>'
    def write(self,codes):
        codes.append('',self.orig_lines)
        not_event=Deny(self.event,'not')
        assertionerror = FuncCall(Variable('AssertionError', ''), List([self.msg]), Dict({}))
        _raise = Backtrack(assertionerror, 'raise')
        if_obj=If_else([[not_event,[_raise]]],[])
        if_obj.orig_lines=[('',0)]
        if_obj.write(codes)
class STR:
    def __init__(self,obj):
        self.obj=obj
    def __str__(self):
        return f'<STR: {self.obj}>'
    def write(self,codes):
        self.obj.write(codes)
        codes.append(f'ex_func AX "str" {self.obj.location}')
        self.location='AX'
#------------------------------------------------------------------程式資訊
class Info:                             #用來記錄parse_block資訊
    def __init__(self,namespace):
        self.locals=[]
        self.vars={}
        self.funcs={}       #fname:fDef
        self.classes={}
        self.codelines=[]
        self.namespace=namespace
    def add_info(self,type,obj):
        if type=='var':
            self.vars[obj.name]=obj
        elif type=='func':
            self.funcs[obj.name]=obj
        elif type=='class':
            self.classes[obj.name]=obj
        if obj.name not in self.locals:
            self.locals.append(obj.name)
    def update(self,info):
        self.locals+=info.locals
        self.vars.update(info.vars)
        self.funcs.update(info.funcs)
        self.classes.update(info.classes)
    def write(self,codeline,orig_codelines):
        def deal_orig(orig_codeline):
            box = []
            for obj in orig_codeline:
                if type(obj)==int:
                    box.append(' '*obj)
                else:box.append(str(obj)+' ')
            return ''.join(box)
        self.codelines.append(codeline)
        #if type(orig_codelines)==list:
        #    nbox=[]
        #    for line in orig_codelines:
        #        nbox.append((deal_orig(line[0]),line[1]))
        #else:nbox=(deal_orig(orig_codelines[0]),orig_codelines[1])
        codeline.orig_lines=orig_codelines