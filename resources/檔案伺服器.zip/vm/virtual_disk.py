from os import path,listdir
from time import time,localtime
from vm.crypt import xor_bytes,generate_password
'''
檔案系統，每個單位是1024Byte

'''
def progress_bar(now_size,total_size,size=50):
    i=int(size*now_size/total_size)
    print('\r[' + '#' * i + ' ' * (size - i) + f'] {esize(now_size)}/{esize(total_size)}', end='')
def nowtime(t):
    nt=localtime(t)
    return f'{nt.tm_year}/{nt.tm_mon}/{nt.tm_mday} {nt.tm_hour}:{nt.tm_min}:{nt.tm_sec}'
def esize(size):
    size_unit=('B','KB','MB','GB','TB','PB','EB')
    for i in range(len(size_unit)):
        csize=round(size/(2**(10*i)),2)
        if csize<1024:
            return f'{csize} {size_unit[i]}'
def legel_filename(filename):
    format=filename.split('.')[-1]
    name=filename[:-len(format)-1]
    banlist = '/\\:*?"<>|'
    for i in banlist:
        name = name.replace(i, '_')
    o=listdir()
    if f'{name}.{format}' not in o:return f'{name}.{format}'
    c=1
    while f'{name}_{c}.{format}' in o:
        c+=1
    return f'{name}_{c}.{format}'
def format_file_size(size):  # size為byte大小
    s = str(int(size)).encode('utf-8')
    a = '0'.encode('utf-8')
    return a * (15 - len(s)) + s
def file_info(isfile,build_t,last_update_t,last_read_t,file_size,file_location):
    def format_isfile(isfile):
        return ('1' if isfile else '0').encode('utf-8')
    def format_time(t):
        n = str(int(t)).encode('utf-8')
        a='0'.encode('utf-8')
        return a * (10 - len(n)) + n[-10:]
    def format_file_location(location):
        a='0'.encode('utf-8')
        location_byte=location.encode('utf-8')
        return location_byte+a*(67-len(location_byte))
    return format_isfile(isfile)+format_time(build_t)+format_time(last_update_t)+format_time(last_read_t)+format_file_size(file_size)+format_file_size(0)+format_file_location(file_location)

'''通用名詞註記
ptr:在FILE中的位址
dptr:在磁碟中的位址
'''
def text_to_serial(text):                         # 串列格式讀取e.g.   100,200-400,345,356,10-50,57*
    k = text.index('*')
    box=[]
    for i in text[:k].split(','):
        if '-' in i:
            c = i.split('-')
            box.append((int(c[0]), int(c[1])))
        else:
            box.append(int(i))
    return box
def serial_to_text(serial):
    text = ''
    for i in serial:
        if type(i) == int:
            text += f'{i},'
        elif type(i) == tuple:
            text += f'{i[0]}-{i[1]},'
    return text[:-1] + '*'
def sort_serial(serial):
    get={}
    box,nbox=[],[]
    for i in serial:
        if type(i)==int:
            get[i]=i
            box.append(i)
        elif type(i)==tuple:
            get[i[0]]=i
            box.append(i[0])
    box.sort()
    for i in box:
        nbox.append(get[i])
    return combine_serial(nbox)
def combine_serial(serial):
    tem=[0,'no']
    result=[]
    c=0
    while c<len(serial):
        if type(serial[c])==int:deal=(serial[c],serial[c]+1024)
        else:deal=serial[c]
        if deal[0]==tem[1]:
            tem[1]=deal[1]
        else:
            result.append((tem[0],tem[1]))
            tem=[deal[0],deal[1]]
        c+=1
    result.append((tem[0], tem[1]))
    del result[0]
    return result
class Space_Serial:                                                       #檔案所佔空間序列
    def __init__(self,disk,ptr,extend_ptr,location):
        self.ptr=ptr
        self.disk=disk
        self.ptrs=[extend_ptr]
        while extend_ptr>0:
            fetch=self.disk.file_describe_space_configuration.read(extend_ptr).decode('utf-8')
          #  print('fetch:',fetch)
            extend_ptr=int(fetch[:15])
            self.ptrs.append(extend_ptr)          #最後一個ptr必定是0
            location+=fetch[15:128]
      #  print(self.ptrs)
      #  print('location:',location)
        self.serial=text_to_serial(location)
    def now_max_size(self):             #當前所存放的最大空間
        total=0
        for i in self.serial:
            if type(i)==int:
                total+=1
            elif type(i)==tuple:
                total+=(i[1]-i[0])/1024
        return int(total*1024)
    def resize(self,size):                                                   #調整內容大小
        now_max_size=self.now_max_size()
        if size>now_max_size:        #如果空間不足，就申請
            need=(size-now_max_size)//1024+1                    #需要的空間個數
            apply_serial=self.disk.apply_space(need)
            self.serial+=apply_serial
        elif size<now_max_size-1024:
            need=size//1024+1
            abort_serial=[]
            c=0
            while need>0:
                if type(self.serial[c])==int:
                    need-=1
                elif type(self.serial[c])==tuple:
                    deal=[self.serial[c][0],self.serial[c][1]]
                    while need>0 and deal[1]-deal[0]>0:
                        need-=1
                        deal[0]+=1024
                    if deal[1]-deal[0]>0:
                        self.serial[c]=(self.serial[c][0],deal[0])
                        abort_serial.append((deal[0],deal[1]))
                c+=1
            abort_serial+=self.serial[c:]
            self.serial=self.serial[:c]
          #  print('abort:',abort_serial)
            self.disk.release_space(abort_serial)
        self.save()
    def save(self):                                          #儲存
        self.serial=combine_serial(self.serial)
       # print(self.serial)
        byte=serial_to_text(self.serial).encode('utf-8')
        n=len(byte)
        ptrs=[self.ptr]+self.ptrs
        c=0                     #目前為第c個ptr
     #   print('全byte為:',byte)
      #  print('n為:',n)
        while n>0:
            if c==0:n-=67
            else:n-=113
            if n<=0:                       #就此結束
                ptrs[c+1]=0
            else:                          #再申請一個
                if ptrs[c+1]==0:
                    ptrs[c+1]=self.disk.register_describe_configuration()
                    ptrs.append(0)
            if c==0:
              #  print('呼叫fdsc1----------------------')
              #  print('ptrs:',ptrs)
                self.disk.file_describe_space_configuration.write(ptrs[c]+46, format_file_size(ptrs[c+1])+byte[:67])
            else:
                self.disk.file_describe_space_configuration.write(ptrs[c],format_file_size(ptrs[c+1])+byte[c*113-46:c*113+67])
            c+=1
        if c+1<len(ptrs):
            self.disk.unregister_describe_configuration(ptrs[c+1:-1])                   #取消登記
        self.ptrs=ptrs[1:c+1]
        self.disk.save_configuration()
class FDSC:
    def __init__(self,disk,ptr,unit):       #unit為每次擴展單位，為8的倍數
        self.disk=disk
        self.unit=unit
        self.disk.f.seek(ptr,0)
        fetch=self.disk.f.read(128).decode('utf-8')
        self.dptrs=[ptr,int(fetch[46:61])]
        while self.dptrs[-1]>0:
            self.disk.f.seek(self.dptrs[-1]+46, 0)
            self.dptrs.append(int(self.disk.f.read(15).decode('utf-8')))
        self.max_term=self.__get_max_term()
    def __get_max_term(self):                                  #自身可登記的檔案最大項
        return (len(self.dptrs)-1)*self.unit
    def extend(self,ptr):                 #擴展可用空間
        self.dptrs[-1]=ptr
        #----------------------------------更新舊版面
      #  print('dparts:',self.dptrs)
        self.disk.f.seek(self.dptrs[-2] + 46, 0)
        self.disk.f.write(format_file_size(self.dptrs[-1]))
        #----------------------------------更新新版面
        self.dptrs.append(0)
        self.disk.f.seek(self.dptrs[-2] + 46, 0)
        self.disk.f.write(format_file_size(self.dptrs[-1]))
        #-----------------------------------更新最大項
        self.max_term=self.__get_max_term()
    def write(self,ptr,content):
      #  print('給的ptr為:',ptr)
        order = ptr // 128  # 第幾項
        page = order // self.unit  # 第幾頁
      #  print('我的頁表:',self.dptrs)
      #  print(f'目標為第{page}第{order}項')
        offset = order - self.unit * page  # 第page頁偏移多少
        offset2=ptr-(ptr//128)*128
        dptr = self.dptrs[page] + offset * 128+offset2
        self.disk.f.seek(dptr, 0)
       # print('FDSC寫入的dptr為:',dptr)
       # print('FDSC要寫入的內容為:',content)
        return self.disk.f.write(content)
    def read(self,ptr):
        order=ptr//128                            #第幾項
        page=order//self.unit                            #第幾頁
        offset=order-self.unit*page              #第page頁偏移多少
        dptr=self.dptrs[page]+offset*128
        self.disk.f.seek(dptr,0)
        return self.disk.f.read(128)
class FOLDER:
    def __init__(self,disk,ptr,encrypt=None):
        self.disk=disk
        self.ptr=ptr
        self.encrypt=encrypt
        self.file=FILE(self.disk,self.ptr,encrypt=self.encrypt)
        self.file_size=self.file.file_size
        self.type=0
        self.box=[]
        self.__load_content()
    def get_info(self):
        self.file.get_info()
    def __load_content(self):
        content = self.file.read(0,0)
        try:
            self.content=content.decode('utf-8')
            self.access_rights=True
        except UnicodeDecodeError:
            self.content=''
            self.access_rights=False
      #  print('獲取Content:',self.content)
    def reload(self):                     #將self.content轉為可使用list
        box = self.content.split('|')[1:]
        self.box=[]
        for i in range(len(box)):
            name, ptr = box[i].split('*')
            self.box.append([name, int(ptr)])
    def save(self):
        if self.access_rights:
            box=[]
            for name,ptr in self.box:
                box+=[f'|{name}*'.encode('utf-8')+format_file_size(ptr)]
            byte=b''.join(box)
            self.file.file_size=len(byte)
            self.file.write(byte,0)
            self.content=byte.decode('utf-8')
    def listdir(self,fptr=True):
        if len(self.box)==0:self.reload()
        if not fptr:
            box=[]
            for i in self.box:
                box.append(i[0])
            return box
        return self.box
    def get_file_ptr(self,filename):
      #  print('Content:',self.content)
        try:
            nk=self.content.index(f'|{filename}*')
            pk=self.content.index('*',nk)
            ptr=int(self.content[pk+1:pk+16])
        except:ptr=-1
        return ptr
    def CreatFile(self,filename):
        if not self.access_rights:return -1
        banlist = '/\\:*?"<>|'
        for i in banlist:
            filename = filename.replace(i, '_')
        self.reload()
        login_ptr=self.disk.register_describe_configuration(1)          #獲取登記空間
        space_serial=serial_to_text(self.disk.apply_space(1))
        #print('登記ptr:',login_ptr)
        #print('空間ptr:',space_ptr)
        t=time()
        login_info=file_info(True,t,t,t,0,space_serial)
        #print('登記資訊:',login_info)
       # print('呼叫fdsc')
        self.file.fdsc.write(login_ptr,login_info)
        self.box.append([filename,login_ptr])
        self.save()
        return login_ptr
    def is_exist(self,filename):    #是否存在filename
        for i in self.box:
            if i[0] == filename:
                return i
        return False
    def MoveFile_to_AnotherFolder(self,filename1,filename2,anotherfolder,overwrite=True):
        self.reload()
        file1_info = self.is_exist(filename1)
        if not file1_info:
            print('起始地檔案不存在')
            return -1
        if self.ptr==anotherfolder.ptr:    #代表是同一個資料夾
            file1_info[0]=filename2
        else:
            anotherfolder.reload()
            file2_info = anotherfolder.is_exist(filename2)
            if file2_info:
                if not overwrite:
                    print('目的地檔案名稱已存在')
                    return -1
                anotherfolder.DeleteFile(filename2)  #刪除原有檔案
            self.box.remove(file1_info)
            anotherfolder.box.append(file1_info)
            anotherfolder.save()
        self.save()
        return file1_info[1]
    def DeleteFile(self,name):
        self.reload()
        dptr=-1
        for i in self.box:
            if i[0]==name:
                dptr=i[1]
                self.box.remove(i)
        self.save()
        if dptr!=-1:
            #--------------------釋放檔案資源
            f=FILE(self.disk,dptr,encrypt=self.encrypt)
            f.space_manaager.resize(-1)               #歸還使用空間
            self.disk.unregister_describe_configuration(dptr)
        return dptr
class FILE:                                                             #一般檔案
    def __init__(self,disk,ptr,encoding='binary',encrypt=None):     #磁碟，檔案配置FILE中的ptr
        self.disk=disk
        self.ptr=int(ptr)
        self.encoding=encoding
        self.encrypt=encrypt
        #-----------------------------擷取檔案配置表資訊
        self.fdsc=self.disk.file_describe_space_configuration       #檔案配置表
       # print('我的ptr為:',ptr)
        fetch=self.fdsc.read(self.ptr).decode('utf-8')
       # print('fetch為:',fetch)
        self.type=int(fetch[0])           #型態，占1        #1:檔案，0:資料夾
        self.build_t=int(fetch[1:11])     #建立時間，占10
        self.update_t=int(fetch[11:21])   #上次修改時間，占10
        self.read_t=int(fetch[21:31])     #上次讀取時間，占10
        self.file_size=int(fetch[31:46])  #檔案大小，占15
        location=fetch[61:128]       #所占空間位址，占67
        extend_ptr=int(fetch[46:61])            #擴充位址，占15
        self.space_manaager=Space_Serial(self.disk,self.ptr,extend_ptr,location)                #所佔空間序列
        #---------------------------------------------------------------
        self.seek(0)                                        #自己的指標(在檔案內)
        self.__set_info('read_t')
    def set_type(self,ty):
        self.type=ty
        self.__set_info('type')
    def __set_info(self,state):                                 #設定註冊表內容
        if state=='type':s=(0,str(self.type).encode('utf-8'))
        elif state=='update_t':s=(11,str(int(time())).encode('utf-8'))
        elif state=='read_t':s=(21,str(int(time())).encode('utf-8'))
        elif state=='size':s=(31,format_file_size(self.file_size))
        self.fdsc.write(self.ptr+s[0],s[1])
    def get_info(self):
        info=[]
        info.append(f'檔案登記位址:{self.ptr}')
        info.append('檔案型態:'+['資料夾','檔案'][self.type])
        info.append(f'建立時間:{nowtime(self.build_t)}')
        info.append(f'上次修改時間:{ nowtime(self.update_t)}')
        info.append(f'上次存取時間:{nowtime(self.read_t)}')
        info.append(f'檔案大小:{self.file_size}')
        info.append(f'儲存空間序列{self.space_manaager.serial}')
        return '\n'.join(info)
    def seek(self,pen):self.pen=pen
    def write(self,byte,pen=None):
        def disk_write(dptr,content):
         #   if self.ptr==512:print(self.ptr,f'在{dptr}的位置寫下{len(content)}的長度')
            self.disk.f.seek(dptr,0)
            self.disk.f.write(content)
        if pen!=None:self.pen=pen
        if self.encoding!='binary':
            byte=byte.encode(self.encoding)
        n=len(byte)
        if self.pen+n>=self.file_size:                       #如果寫入時超出可用空間，就申請
            self.file_size=self.pen+n
            self.space_manaager.resize(self.file_size)
            self.__set_info('size')
        if self.encrypt!=None:             #對寫入的byte進行加密
            byte=xor_bytes(byte,self.encrypt,self.pen)
            assert n==len(byte),'加密錯誤'
        c=0               #在serial的位置
        k=0               #在byte中的位置
        skip=0     #前往pen之前所跳過的內容大小(byte)
      #  if self.ptr==512:
      #      print('------------------------------------WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW')
      #      print('要寫的序列為:',self.space_manaager.serial)
       #     print(f'{self.ptr}的pen為',self.pen)
        while c<len(self.space_manaager.serial):
            deal=self.space_manaager.serial[c]
            if skip>=self.pen:                #開始寫入磁碟
               # print(self.ptr,'寫入!')
                if type(deal)==int:
                  #  if self.ptr==512:print('從這裡寫1')
                    disk_write(deal,byte[k:k+1024])
                    k+=1024
                elif type(deal) == tuple:
                    w_size=deal[1]-deal[0]
                 #   if self.ptr==512:print('從這裡寫2')
                    disk_write(deal[0],byte[k:k+w_size])
                    k+=w_size
            else:                            #跳過內容
                if type(deal)==int:
                    if skip+1024>self.pen:
                        k=skip+1024-self.pen
                     #   if self.ptr==512:print('從這裡寫3')
                        disk_write(deal+1024-k,byte[:k])
                    skip+=1024
                elif type(deal)==tuple:
                    w_size=deal[1]-deal[0]
                    if skip+w_size>self.pen:
                        k=w_size-(self.pen-skip)
                    #    if self.ptr==512:print('從這裡寫4')
                        disk_write(deal[0]+(self.pen-skip),byte[:k])
                    skip+=w_size
            c+=1
            if k>len(byte)-1:break
        self.pen += n
        self.__set_info('update_t')
        return n
    def read(self,n=0,pen=None):
        def disk_read(dptr,n):
          #  print(n)
            self.disk.f.seek(dptr,0)
            byte.append(self.disk.f.read(n))
        if pen != None: self.pen = pen
        read_pen=self.pen
        if n==0:
            n=self.file_size-self.pen
        else:n=min(n,self.file_size-self.pen)
        read_size=n
     #   print('n:',n)
     #   print('pen:',self.pen)
        byte=[]
        c = 0  # 在serial的位置
        skip = 0  # 前往pen之前所跳過的內容大小(byte)
        while c < len(self.space_manaager.serial):
            deal = self.space_manaager.serial[c]
            if skip >= self.pen:                       #返回byte
                if type(deal) == int:
                    r_size=min(1024,n)
                    #print(1)
                    disk_read(deal,r_size)
                    n-=r_size
                elif type(deal) == tuple:
                    r_size =min(deal[1] - deal[0],n)
                   # print(2)
                    disk_read(deal[0], r_size)
                    n-=r_size
            else:                                    # 跳過內容
                if type(deal) == int:
                    if skip + 1024 > self.pen:
                        r_size= min(skip + 1024 - self.pen,n)
                       # print(3)
                        disk_read(deal + 1024 - r_size,r_size)
                        n-=r_size
                    skip += 1024
                elif type(deal) == tuple:
                    t_size = deal[1] - deal[0]
                    if skip + t_size > self.pen:
                        r_size = min(t_size - (self.pen - skip),n)
                       # print(4)
                        disk_read(deal[0] + (self.pen - skip),r_size)
                        n-=r_size
                    skip += t_size
            c += 1
            if n==0:break
        self.pen+=read_size
        self.__set_info('read_t')
        read_byte=b''.join(byte)
        if self.encrypt!=None:             #對讀出的byte進行解密
            read_byte=xor_bytes(read_byte,self.encrypt,read_pen)
            assert read_size==len(read_byte),'解密錯誤'
        if self.encoding!='binary':
            read_byte=read_byte.decode(self.encoding)
        return read_byte
    def close(self):
        self.disk=None
        self.space_manaager=None
class VDisk:
    def __init__(self,disk_path='',password=None):
        self.disk_path=disk_path
        self.work_folder='VDisk:'   #磁碟中的相對目錄
        self.fdsc_unit=800
        self.encrypt=generate_password(password.encode('utf-8'),2**10) if password!=None else None    #1MB的加密密鑰
        # -----------------------------------------------------------載入磁碟
        if self.disk_path == '':           #創建新磁碟
            self.disk_path ='default.disk'
        if not path.isfile(self.disk_path):
            print('創建:',self.disk_path)
            self.__create_new_disk()
        self.__load_disk()
    def recalculate_size(self):               #算法:總大小-可申請空位=已使用空間
        total_size=self.file_space_configuration_serial[-1]          #總大小
        size=0
        for i in self.file_space_configuration_serial:
            if type(i)==int:
                size+=1024
            elif type(i)==tuple:
                g_size=i[1]-i[0]
                size+=g_size
        #-------------------------------------計算系統使用空間
        self.fdsc_size=self.file_describe_space_configuration.max_term*128
       # print(self.fdsc_size)
        self.fsc_size=self.fsc.file_size
       # print(self.fsc_size)
        self.fdc_size=self.fdc.file_size
       # print(self.fdc_size)
        self.used_size=total_size-size
       # print(self.used_size)
    def format(self):
        self.__create_new_disk()
        self.__load_disk()
    def __create_new_disk(self):                   #創建空磁碟
        f=open(self.disk_path,'wb')
        t=time()
        f.write(file_info(True, t, t, t,0, '---'))                                  # 檔案配置檔案fdsc
        f.write(file_info(True, t, t, t, 4,f'{int(self.fdsc_unit*128)}*'))              #檔案描述符號登記
        f.write(file_info(True, t, t, t, len(f'{self.fdsc_unit*128+1024*3}*'.encode()), f'{int(self.fdsc_unit*128+1024)}*'))              #檔案空間登記
        #--------------------------------------------------
        f.write(file_info(False, t, t, t, 0, f'{int(self.fdsc_unit*128+1024*2)}*'))             #根資料夾
        #--------------------------------------------------
        f.seek(self.fdsc_unit*128,0),f.write(b'512*')                 #下一個檔案登記位置
        f.seek(self.fdsc_unit*128+1024,0),f.write(f'{self.fdsc_unit*128+1024*3}*'.encode())
        f.close()
    def __load_disk(self):            #載入磁碟
        self.f=open(self.disk_path,'rb+')
        #-----------------------------------------------------------檔案配置管理(檔案配置空位、描述符號空位、檔案空間空位)
        self.file_describe_space_configuration = FDSC(self, 0,unit=self.fdsc_unit)
        #--------------------
        self.fdc=FILE(self,128)           #因為內容與其他磁碟差不多，加密後會被與其他磁碟比對而破解，故無須加密
        self.fsc=FILE(self,256)           #因為內容與其他磁碟差不多，加密後會被與其他磁碟比對而破解，故無須加密
        self.file_describe_configuration_serial=text_to_serial(self.fdc.read(0,0).decode())
        self.file_space_configuration_serial= text_to_serial(self.fsc.read(0, 0).decode())
        self.root=FOLDER(self,384,encrypt=self.encrypt)      #內容和其他磁碟不同，須加密   #根資料夾
        self.save_configuration_lock=0
        self.recalculate_size()                                           #已使用空間
    def register_describe_configuration(self,number=1):                                                         #在檔案列表註冊number個描述配置位址
        serial=self.file_describe_configuration_serial           #讀取登記表
        get=[]
        for i in range(number):
            get.append(serial[0])
            if len(serial)>1:
                del serial[0]
            else:serial[0]+=128
        max_term=self.file_describe_space_configuration.max_term
        c=0
        while c<len(get):                                #檢查數值是否超出可登記範圍
            deal=get[c]
            if deal>max_term:
                extend_ptr=self.apply_space(int(self.fdsc_unit/8),continuous=True)[0][0]         #申請100個連續空間
                self.file_describe_space_configuration.extend(extend_ptr)
                max_term=self.file_describe_space_configuration.max_term
            else:c+=1
        if number==1:return get[0]
        return get
    def unregister_describe_configuration(self,ptrs):                                                               #取消登記位址，int或tuple或serial
        serial=self.file_describe_configuration_serial        #讀取登記表
        if type(ptrs)==list:
            self.file_describe_configuration_serial=serial[:-1]+ptrs+[serial[-1]]
        else:self.file_describe_configuration_serial=serial[:-1]+[ptrs,serial[-1]]
    def apply_space(self,number,continuous=False):               #申請使用空間，return 可用空間房號(串列)，共number個
        serial =self.file_space_configuration_serial   # 讀取登記表
        get=[]
        #print('目前的空間登記表:',serial)
        #---------------------------------------處理前面的
        c=0
        while c<len(serial)-1 and number>0:
            deal=serial[c]
            if type(deal)==int and not continuous:
                get.append(deal)
                number-=1
            elif type(deal)==tuple:
                total=(deal[1]-deal[0])//1024
                if total>number:
                    get.append((deal[0], deal[0] + 1024 * number))
                    serial[0]=(deal[0]+1024*number,deal[1])
                    number=0
                    break                 #滿足了，跳出迴圈
                elif not continuous:
                    get.append(deal)
                    number-=total
            if not continuous:
                del serial[0]
            else:c+=1
        #若前面的空間不足
        if number>0:
            if number==1:
                get.append(serial[-1])
            else:
                get.append((serial[-1],serial[-1]+1024*number))
            serial[-1]+=1024*number
       # print('給空間:',get)
        return get
    def release_space(self,abort_serial):             #FILE釋出不用的空間房號
        serial = self.file_space_configuration_serial  # 讀取登記表
        self.file_space_configuration_serial=serial[:-1]+abort_serial+[serial[-1]]
    def save_configuration(self):
        if self.save_configuration_lock==0:
            self.save_configuration_lock=1
            file_describe_configuration=self.fdc
            file_space_configuration=self.fsc
            #-------------------------------------先存登記表
            while True:
                byte=serial_to_text(self.file_describe_configuration_serial).encode()
                n=len(byte)
                if n>file_describe_configuration.space_manaager.now_max_size():
                    need_number=(file_describe_configuration.space_manaager.now_max_size()-n)//1024+1
                    get=self.apply_space(need_number)
                    file_describe_configuration.space_manaager.serial+=get
                    file_describe_configuration.space_manaager.save()
                else:
                    # --------------------------------------------------------------------存空間表
                    byte2 = serial_to_text(self.file_space_configuration_serial).encode()
                    n2 = len(byte2)
                    if n2 > file_space_configuration.space_manaager.now_max_size():
                        need_number = (file_space_configuration.space_manaager.now_max_size() - n) // 1024 + 1
                        get = self.apply_space(need_number)
                        file_space_configuration.space_manaager.serial += get
                        file_space_configuration.space_manaager.save()
                    else:
                        file_describe_configuration.write(byte, 0)
                        file_space_configuration.write(byte2, 0)
                        break
            self.save_configuration_lock=0
#-----------------------------------------------------------------------------------------------------------------------以下為可供外界使用函數
    def fopen(self,filepath,mode=1,encoding='binary'):           #0:無操作,找不到檔案就強制建立
        if filepath=='':return self.root
        ptr=self.__get_file_ptr(filepath,operate=mode)
        if ptr==-1:return ptr
        file=FILE(self,ptr,encoding=encoding,encrypt=self.encrypt)
        if file.type==0:    #代表是資料夾
            return FOLDER(self,ptr,encrypt=self.encrypt)
        return file
    def __get_file_ptr(self,filepath,operate=0):       #operate 0:無操作,1:未找到則建立，2:找到後從資料夾移除
        def listdir(nowfolder,k):
          #  print('列出nowfolder內容:',nowfolder.listdir())
            ptr=nowfolder.get_file_ptr(box[k])
           # print('得到的ptr:',ptr)
            if ptr==-1:
                if operate==1 and k==len(box)-1:
                   # print('創造:',box[k])
                    ptr=nowfolder.CreatFile(box[k])
                return ptr
            if k==len(box)-1:
                if operate==2:
                    nowfolder.DeleteFile(box[k])
                return ptr
            else:
                f=FILE(self,ptr,encrypt=self.encrypt)
                if f.type==1:return -1
                return listdir(FOLDER(self,ptr,encrypt=self.encrypt),k+1)
        box=filepath.replace('\\','/').split('/')
        file_ptr=listdir(self.root,0)
        return file_ptr
    def __relatively_to_absolute(self,filepath):
        filepath=filepath.replace('\\','/').rstrip('/')
        if filepath=='VDisk:':
            filepath+='/'
        if ':/' not in filepath:                       #絕對路徑
            filepath=f'{self.work_folder}/{filepath}'
        k=filepath.index(':/')
        return filepath[k+2:]
    def listdir(self,folder_path='',info=False):                    #列出該目錄下檔案
        folder_path=self.__relatively_to_absolute(folder_path)
        if folder_path=='':result=self.root.listdir(fptr=info)
        else:
            fptr=self.__get_file_ptr(folder_path)
            if fptr==-1:result=fptr
            else:
                folder=FOLDER(self,fptr,encrypt=self.encrypt)
                result=folder.listdir(fptr=info)
        if not info:return result
        box=[]
        for name,ptr in result:
            file=FILE(self,ptr,encrypt=self.encrypt)
            file.name=name
            box.append(file)
        return box
    def mkdir(self,path):
        path=self.__relatively_to_absolute(path)
        f=self.fopen(path)
        if f.file_size>0:return -1            #若是path不合格，return -1
        f.set_type(0)
        return FOLDER(self,f.ptr,encrypt=self.encrypt)
    def rmdir(self, foldername):
        self.remove(self.__relatively_to_absolute(foldername))
    def getcwd(self):
        return self.work_folder
    def rename(self, filepath1, filepath2):
        filepath1=self.__relatively_to_absolute(filepath1)
        filepath2=self.__relatively_to_absolute(filepath2)
        #--------------------------------------------
        filename1=filepath1.split('/')[-1]
        filename2=filepath2.split('/')[-1]
        #--------------------------------------------
        folderpath1=filepath1[:-len(filename1)-1]
        folder1=self.fopen(folderpath1,mode=0)
        folderpath2= filepath2[:-len(filename2)-1]
        folder2=self.fopen(folderpath2,mode=0)
        #-------------------------------------------
        if type(folder1)==FOLDER and type(folder2)==FOLDER:
            folder1.MoveFile_to_AnotherFolder(filename1,filename2,folder2)
            return True
        return False
    def remove(self,filepath):                 #刪除資料夾或檔案
        ptr=self.__get_file_ptr(self.__relatively_to_absolute(filepath),operate=2)
        return ptr
    def chdir(self, foldername):
        foldername=self.__relatively_to_absolute(foldername)
        if self.isdir(foldername):
            self.work_folder = foldername.rstrip('/')
            return
        raise Exception()
    def isfile(self, filepath):
        file=self.fopen(self.__relatively_to_absolute(filepath),mode=0)
        return type(file)==FILE
    def isdir(self, folderpath):
        folderpath=self.__relatively_to_absolute(folderpath)
        if folderpath=='':#根目錄
            return True
        file = self.fopen(folderpath,mode=0)
        return type(file) == FOLDER
    def getsize(self, filepath):
        file=self.fopen(self.__relatively_to_absolute(filepath),mode=0)
        return file.file_size
    def open(self, filepath,mode=None,encoding=None):
        filepath = self.__relatively_to_absolute(filepath)
        if encoding==None:
            if mode in (None,'wb','rb','ab'):
                encoding='binary'
            elif mode in ('r','w','a'):
                encoding='utf-8'
        return self.fopen(filepath,encoding=encoding)
    def input(self,real_filepath,parent_folder=None,progress_func=None):    #從外部匯入檔案
        if parent_folder==None:
            parent_folder=self.work_folder
        print('parent:',parent_folder,'     real:',real_filepath)
        real_filepath=self.__relatively_to_absolute(real_filepath)
        parent_folder=self.__relatively_to_absolute(parent_folder)
        if path.isdir(real_filepath):
            def package_cmd(folderpath):  # 包裝指令
                size=0
                o=listdir(folderpath)
                cmds.append(('mkdir',folderpath))
                for i in o:
                    filepath=folderpath+'/'+i
                    if path.isdir(filepath):
                        size+=package_cmd(filepath)
                    elif path.isfile(filepath):
                        cmds.append(('input',filepath))
                        size+=path.getsize(filepath)
                return size
            cmds=[]
            total_size=package_cmd(real_filepath)
        elif path.isfile(real_filepath):
            cmds=[('input',real_filepath)]
            total_size=path.getsize(real_filepath)
        else:return -1
        f_size=0
        if parent_folder=='':pf=''
        else:                                          #檢查母資料夾是否存在
            ptr=self.__get_file_ptr(parent_folder)
            file=FILE(self,ptr,encrypt=self.encrypt)
            if file.type==0:
                pf=parent_folder+'/'
            else:return -1
        for cmd,filepath in cmds:
            if cmd=='mkdir':
                self.mkdir(pf+filepath)
            elif cmd=='input':
                rf=open(filepath,'rb')
                vf=self.fopen(pf+filepath)
                if vf==-1:return -1
                r_size=2**25                    #寫入尺寸為1MB
                code=rf.read(r_size)
                k=1
                l=0
                while len(code)>0:
                    k+=1
                   # if k==12:break
                    vf.write(code)
                    f_size+=len(code)
                    l+=1
                    if l%1024==0 and progress_func!=None:
                        progress_func(f_size,total_size)
                    code = rf.read(r_size)
                rf.close()
                vf.close()
    def output(self,virtual_filepath,real_filepath):   #從內部匯出檔案到外部
        virtual_filepath=self.__relatively_to_absolute(virtual_filepath)
        vf = self.fopen(virtual_filepath,mode=0)
        if vf==-1:return -1
        rf = open(real_filepath, 'wb')
        r_size = 2**25                  # 讀取尺寸為1MB
        code =vf.read(r_size,0)
        while len(code) > 0:
            rf.write(code)
            code = vf.read(r_size)
        rf.close()
        vf.close()
    def close(self):
        self.f.close()
if __name__ == '__main__':
    disk=Disk()
   # disk.format()
    t=Terminal(disk)
    t.mainloop()
    #f=disk.fopen('new.txt')
    #f2=disk.fopen('new2.txt')
#    f.get_info()
    #byte=open('good2.png','rb').read()
    #byte2=open('NodeMCU-32S-details-3.jpg','rb').read()
   # t=time()
   # disk.mkdir('folder1')
   # disk.input('folder1/new.png','good2.png')
   # disk.input('void.txt', 'test.txt')
    #print('當前可用登記表:',disk.file_describe_configuration_serial)
   # print('當前可用空間表:', disk.file_space_configuration_serial)
   # disk.input('new2.jpg','NodeMCU-32S-details-3.jpg')
   # #print('當前可用登記表:', disk.file_describe_configuration_serial)
   # print('當前可用空間表:', disk.file_space_configuration_serial)
   # disk.input('folder1\\new2.jpg', 'NodeMCU-32S-details-3.jpg')
   # disk.remove('new2.jpg')
    #print('當前可用登記表:', disk.file_describe_configuration_serial)
  #  print('當前可用空間表:', disk.file_space_configuration_serial)
   # for i in range(6):
    #    print('--------------------------------')
   #     disk.input(f'new{i}.png', 'good2.png')
   # print('當前可用空間表:', disk.file_space_configuration_serial)
   # print(disk.listdir('1'))
   # print(disk.listdir('folder2'))
    #disk.output('folder1/new.png','new.png')
    #print(time()-t)
    #disk.input('void.txt','test.txt')
    #disk.output('void.txt','test2.txt')
    #disk.input('new2.jpg','NodeMCU-32S-details-3.jpg')
    #disk.output('new2.jpg','new100.png')
    #t=time()
   # disk.input('Apple.mp4','ss.mp4')
    #disk.output('Apple.mp4','banana.mp4')
    #print(time()-t)