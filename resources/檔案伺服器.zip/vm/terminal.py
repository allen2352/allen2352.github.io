
t_cmd='''
終端機指令:

help                               查看可用指令
system                             查看系統資訊

input    filepath                  將filepath存入虛擬磁碟
output   v_filename r_filename     將v_filename從虛擬磁碟匯出，並命名為r_filename
mkdir    foldername                創建foldername資料夾
cd       foldername                進入資料夾
cd..                               離開資料夾
dir      foldername                查看foldername底下所有檔案資料
info     filename                  查看filename資訊
remove   filename                  移除filename


'''
class Terminal:                      #磁碟操作系統
    def __init__(self,disk,mode=0):          #mode[0:印出結果,1:記錄在output,2:無紀錄]
        self.disk=disk
        self.banlist='/\\:*?"<>|'
        self.folderpath=''
        self.log_text=[]                      #事件紀錄
        self.output=[]
        self.error=0
        self.mode=mode
    def log(self,msg,error=1):
        self.log_text.append((time(),error,msg))
        if self.mode==0:print(msg)
        elif self.mode==1:self.output.append(msg)
        self.error=error
    def operate(self,string):
        self.log_text.append((time(),0,string))
        cmd=string.split(' ')
        if cmd[0]=='help':print(t_cmd,end='')
        elif cmd[0]=='system':
            disk.recalculate_size()
            self.log(f'已使用空間:{esize(disk.used_size)}')
            self.log(f'系統所占空間:{esize(disk.fdsc_size+disk.fdc_size+disk.fsc_size)}')
        elif cmd[0]=='cd..':
            folder=self.folderpath.split('/')[-1]
            self.folderpath=self.folderpath[:-len(folder)-1]
        elif len(cmd)==1 and cmd[0]=='dir':
            self.log('\n'.join(self.disk.listdir(self.folderpath)))
        elif len(cmd)>1:
            filename=cmd[1]
            check_code=0                       #0代表合格
            if len(filename)==0:
                self.log('檔案名稱不可為空!')
                check_code=2                    #2代表不合格
            for i in self.banlist:
                if i in filename:
                    if i in '/\\':
                        check_code=1        #1代表檔名可能使用絕對路徑
                    else:
                        self.log(f'檔案名稱"{filename}"中包含不可使用的字元:{i}')
                        check_code=2                                                 #2代表不合格
           # print('1 self.folderpath:',self.folderpath)
            if check_code==1:
                fpath=filename
            elif self.folderpath == '':
                fpath = filename
            else:
                fpath = self.folderpath + '/' + filename
           # print('2 self.folderpath:',self.folderpath)
            print('fpath:',fpath)
            if check_code<2:

                file = self.disk.fopen(fpath, mode=0)
                if cmd[0]=='mkdir':
                    if file!=-1:
                        if file.type==0:self.log('該資料夾已存在')
                        else:self.log('此為已存在的檔案名稱')
                    else:self.disk.mkdir(fpath)
                if cmd[0]=='cd':
                    if file!=-1 and file.type==0:self.folderpath=fpath
                    else:self.log('該資料夾不存在!')
                elif cmd[0]=='dir':
                    if file!=-1 and file.type==0:self.log('\n'.join(self.disk.listdir(fpath)))
                    else:self.log('該資料夾不存在!')
                elif cmd[0]=='info':
                    if file!=-1:self.log(file.get_info())
                    else:self.log('該檔案不存在!')
                elif cmd[0]=='remove':
                    if file!=-1:self.disk.remove(fpath)
                    else:self.log('該檔案不存在!')
                elif cmd[0] == 'input':
                    if path.isfile(cmd[1]) or path.isdir(cmd[1]):
                        # print('fpath:',fpath)
                        check = self.disk.input(self.folderpath, cmd[1],progress_func=progress_bar)
                        if check == -1: self.log('無效的虛擬路徑')
                    else:
                        self.log(f'{cmd[1]}不存在!')
                elif len(cmd)>2:
                    if cmd[0]=='output':
                        if path.isfile(cmd[2]):
                            self.log('無法覆蓋現有的檔案!')
                        else:
                            check=self.disk.output(fpath,cmd[2])
                            if check==-1:self.log('該虛擬檔案不存在')
        print(f'\n{disk.disk_path}#{self.folderpath}>>',end='')
    def mainloop(self):
        self.operate('help')
        while True:
            a=input()
            if a=='exit':break
            elif a=='format':
                self.disk.format()
                self.folderpath=''
            else:
                b=a.split(' ')
                if b[0]=='ptr':
                    file=FILE(self.disk,b[1])
                    if file.type==0:
                        print(file.read(0,0))
                else:
                    self.operate(a)