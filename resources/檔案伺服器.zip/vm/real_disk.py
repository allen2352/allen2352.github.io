from os import listdir,mkdir,rmdir,getcwd,rename,remove,chdir,popen
from os.path import isdir,isfile,getsize

class RDisk:
    def __init__(self):
        self.work_folder=getcwd().replace('\\','/')
    def __relatively_to_absolute(self,filepath):
        if ':' in filepath:
            return filepath
        return f'{self.work_folder}/{filepath}'
    def listdir(self,foldername=None):
        foldername=self.__relatively_to_absolute(foldername)
        if foldername==None:
            return listdir(self.work_folder)
        return listdir(foldername)
    def mkdir(self,foldername):
        mkdir(self.__relatively_to_absolute(foldername))
    def rmdir(self,foldername):
        rmdir(self.__relatively_to_absolute(foldername))
    def getcwd(self):
        return self.work_folder
    def rename(self,filename1,filename2):
        rename(self.__relatively_to_absolute(filename1),self.__relatively_to_absolute(filename2))
    def remove(self,filepath):
        remove(self.__relatively_to_absolute(filepath))
    def chdir(self,foldername):
        if isdir(foldername):
            self.work_folder=foldername.replace('\\','/').rstrip('/')
    def isfile(self,filepath):
        return isfile(self.__relatively_to_absolute(filepath))
    def isdir(self,folderpath):
        return isdir(self.__relatively_to_absolute(folderpath))
    def getsize(self,filepath):
        return getsize(self.__relatively_to_absolute(filepath))
    def open(self,filepath,*args,**kwargs):
        filepath=self.__relatively_to_absolute(filepath)
        return open(filepath,*args,**kwargs)
    def popen(self,command):
        mypath = getcwd()
        chdir(self.work_folder)
        result=popen(command)
        chdir(mypath)
        return result
    def close(self):    #為了配合virtual disk而設立的函數
        pass
