from random import random

class DataBase:
    def __init__(self):
        self.users = {}
        self.set_init_user_data({'cookie':Cookie()})
    def set_init_user_data(self, object):
        self.init_user_data = object
        if 'cookie' not in object:
            self.init_user_data['cookie']=Cookie()
    def get_user(self, id=None):
        if id==None:                         #註冊Cookie
            user=self.init_user_data.copy()
            user['cookie']=Cookie()
            user['cookie']['id']=cache['id']
            id=user['cookie']['id']
            self.users[id] = user
            while cache['id'] in self.users:
                cache['id']+=1
        if id not in self.users:
            user = self.init_user_data.copy()
            user['cookie']['id']=id
            self.users[id] = user
        return self.users[id]
cache={'id':0}
class Cookie:
    def __init__(self,cookie_dict=None):
        if cookie_dict!=None:
            self.__cook_dict=cookie_dict
        else:
            self.__cook_dict ={}
    def __setitem__(self, key, value):
        self.__cook_dict[key]=value
    def __delitem__(self, key):
        del self.__cook_dict[key]
    def __getitem__(self, item):
        return self.__cook_dict[item]
    def __contains__(self, item):
        return item in self.__cook_dict
    def __str__(self):
        cookie=[]
       # print(self.__cook_dict)
        for key in self.__cook_dict:
            cookie.append(f'{key}={self.__cook_dict[key]}')
        return ';'.join(cookie)
class Http_Response:
    def __init__(self,status_code):
        self.status_code=int(status_code)
        self.header={}
        self.content=b''
    def add_header(self,header_dict):
        self.header.update(header_dict)
    def set_header(self,key,value):
        self.header[key]=value
    def to_bytes(self):
        status_phrase={200:'OK',404:'Not Found'}
        byte_box=[]
        if self.status_code in status_phrase:
            byte_box.append(f'HTTP/1.1 {self.status_code} {status_phrase[self.status_code]}'.encode('utf-8'))
        else:
            byte_box.append(f'HTTP/1.1 {self.status_code} OK'.encode('utf-8'))
        for key in self.header:
            byte_box.append(f'{key}:{self.header[key]}'.encode('utf-8'))
        byte_box.append(b'')
        byte_box.append(self.content)
        return b'\r\n'.join(byte_box)
def html_convert(text):      #將文字內容轉換成可顯示在網頁上
    replace_box = [ ('>', '&gt;'), ('<', '&lt;'),(' ', '&ensp;'),
                    ("[91m",'<p style="color=red;">'),("[92m",'<span style="color=green;">'),
                    ("[0m",'</span>'),
                    ('\n', '<br>')]
    for rtext in replace_box:
        text = text.replace(rtext[0], rtext[1])
    return text
