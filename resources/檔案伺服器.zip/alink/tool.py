def html_convert(text):      #將文字內容轉換成可顯示在網頁上
    replace_box = [ ('>', '&gt;'), ('<', '&lt;'),(' ', '&ensp;'),
                    ("[91m",'<p style="color=red;">'),("[92m",'<span style="color=green;">'),
                    ("[0m",'</span>'),
                    ('\n', '<br>')]
    for rtext in replace_box:
        text = text.replace(rtext[0], rtext[1])
    return text