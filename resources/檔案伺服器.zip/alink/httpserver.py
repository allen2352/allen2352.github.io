from alink.tool import DataBase,Http_Response,Cookie
from vm import RDisk
from socket import socket,AF_INET,SOCK_STREAM,gethostname,gethostbyname,SOL_SOCKET,SO_REUSEADDR,timeout
from urllib.parse import unquote,quote
from os import getcwd,listdir
from os.path import isfile,isdir
from ssl import SSLContext,PROTOCOL_TLS_SERVER,SSLError
from threading import Thread
from time import sleep,time,localtime

HttpDB=DataBase()
def display_time(t):
    lt=localtime(t)
    return f'{lt.tm_year}/{lt.tm_mon}/{lt.tm_mday} {lt.tm_hour}:{lt.tm_min}:{lt.tm_sec}'
class Form_Object:
    def __init__(self,form_content):
        self.form_content=form_content
        # -----------------------------------------    處理欄位
        self.Content_Disposition ={}
        self.params = {}  # 首部欄位參數
        k=-1
        n=len(form_content)
       # print('form:')
        #print(form_content)
        while k < n:
            p = k + 1
            try:
                k = form_content.index(b'\n',p)
            except:
                k = n
            if form_content[k - 1] == 13: k2 =k- 1  # b'\r'
            else:k2=k
            if abs(k2- p) < 2:  # 代表接下來是content
                break
            deal_line =form_content[p:k2].decode('utf-8')
            if ':' in deal_line:
                c = deal_line.split(':')
                self.params[c[0]] = c[1]
                if c[0]=='Content-Disposition':
                    attrs=c[1].split(';')
                    CD={'Content-Disposition':attrs[0]}
                    for item in attrs[1:]:
                        ck=item.index('=')
                        attr_name=item[:ck].lstrip(' ')
                        value=item[ck+1:]
                        CD[attr_name]=type_convert(value)
                    self.Content_Disposition=CD
        self.content = form_content[k + 1:]
    def __getitem__(self, item):
        if item=='content':return self.content
        elif item in self.Content_Disposition:
            return self.Content_Disposition[item]
        return None
    def save(self,filepath,disk=None):
        if disk==None:
            disk=RDisk()
        filename=filepath.split('/')[-1]
        if filename!='':
            f = disk.open(filepath, 'wb')
            f.write(self.content)
            f.close()
            return True
        else:
            print('檔名不可為空')
            return False
def type_convert(value):
    value=value.lstrip(' ')
    if len(value)>0:
        if value[0] in ("'",'"'):
            return value[1:-1]
        elif value[0] in '0123456789-':
            try:                             #可能導致錯誤，e.g. 192.168.31.82
                if '.' in value:
                    return float(value)
                return int(value)
            except:pass
    return value            #無法處理
class Request:
    def __init__(self,http_content,conn):
        self.http_content=http_content
        #請求封包:方法 URL 版本
        n=len(http_content)
        try:
            k=http_content.index(b'\n')
        except:
            k=n
        first_line=http_content[:k].decode('utf-8').split(' ')
        self.method = first_line[0]
        #----------------------------------------
        param_line=first_line[1].lstrip('/')
        self.GET_param={}
        if '?' in param_line:               #查看GET參數
            ck=param_line.index('?')
            self.url=unquote(param_line[:ck])
            params=param_line[ck+1:]
            for item in params.split('&'):
                c=item.split('=')
                self.GET_param[c[0]]=unquote(c[1]) #不使用type_convert
        else:
            self.url=unquote(param_line)
        #--------------------------處理url
        replace_box = {'%20': ' '}
        for key in replace_box:
            self.url=self.url.replace(key,replace_box[key])
        #-----------------------------------------    處理首部欄位
        self.header_params={}      #首部欄位參數
        while k<n:
            p=k+1
            try:
                k = http_content.index(b'\n',p)
            except:
                k = n
            if http_content[k - 1] == 10:
                k2 = k - 1  # b'\r'
            else:k2=k
            if abs(k-p)<2:    #代表接下來是content
                break
            deal_line=http_content[p:k2].decode('utf-8')
            if ':' in deal_line:
                c=deal_line.split(':')
                if c[1][-1]=='\r':value=c[1][:-1]
                else:value=c[1]
                #--------------------------------
                self.header_params[c[0]]=type_convert(value)
        # -------------------------------------------    處理content
        if 'Cookie' in self.header_params:
            cookie=Cookie()
            items=self.header_params['Cookie'].split(';')
            for item in items:
                ck=item.index('=')
                cookie[item[:ck]]=item[ck+1:]
            self.header_params['Cookie']=cookie
        if 'Content-Length' in self.header_params:
            self.content = [http_content[k + 1:]]
            content_length = self.header_params['Content-Length']
            recv_length = len(self.content[0])
            if recv_length < content_length:
                # print('重新接收content，content_length=',content_length)
                speed = 2 ** 16
                while recv_length < content_length:
                    content = conn.recv(speed)  # 重新接收
                    recv_length += len(content)
                    self.content.append(content)
            self.content = b''.join(self.content)
        else:
            self.content =http_content[k + 1:]
        #-------------------------------------------    處理multipart/form-data
        self.form_data=[]
        if 'Content-Type' in self.header_params:
            c=self.header_params['Content-Type'].split(';')
            ctype=c[0]
            if ctype[0]==' ':ctype=ctype[1:]
            if ctype=='multipart/form-data':
                k=c[1].index('=')
                boundary=c[1][k+1:].encode('utf-8')
                if boundary in self.content:
                    k=self.content.index(boundary)
                    n=len(self.content)
                   # print('n=',n)
                    while True:
                        p=k+len(boundary)
                        try:
                            k=self.content.index(boundary,p)
                        except:break
                        while self.content[p] in (13,10):p+=1       #(b'\r',b'\n')
                        k2=k-1
                        while self.content[k2]==45:k2-=1            # b'-'
                        if self.content[k2]==10:
                            k2-=1
                            if self.content[k2]==13:k2-=1
                        k2+=1
                        form_content=self.content[p:k2]
                        form_object=Form_Object(form_content)
                        self.form_data.append((form_object.Content_Disposition,form_object))
    def get_name(self,attr_name):
        results=[]
        for form_data in self.form_data:
            if 'name' in form_data[0] and form_data[0]['name']==attr_name:
                results.append(form_data[1])
        return results
#傳回封包:版本 狀態碼 短語
void_html='''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>'''
_404=Http_Response(404)
_404.content='''<html>
 <body>
   <center>
    <h3>Error 404: File not found</h3>
    <p>Python HTTP Server</p>
    </center>
 </body>
</html>
'''.encode('utf-8')
def return_http_file(filepath,disk=None,need_execute=True):
    if disk==None:
        disk=RDisk()
    if disk.isfile(filepath):
        mime_dict={'jpg':'image/jpg','png':'image/png','css':'text/css','mp3':'audio/mpeg','mpeg':'video/mpeg','mp4':'video/mp4',
                   'pdf':'application/pdf','gif':'image/gif','jpeg':'image/jpeg','doc':'application/msword','docx':'application/msword',
                   'py':'text/plain','txt':'text/plain','js':'text/plain','html':'text/html','ttc':'Font'}
        http_response=Http_Response(200)
        file = disk.open(filepath, 'rb')  # open file , r => read , b => byte format
        response = file.read()
        content_length=len(response)
        filetype=filepath.split('.')[-1]
        if filetype in mime_dict:
            mimetype=mime_dict[filetype]
            if not need_execute and filetype in ('html','css'):
                mimetype='text/html'
        else:
            mimetype = 'text/html'
        http_response.add_header({'Content-Type':mimetype,'Content_Length':content_length})
        http_response.content=response
    else:http_response=_404
    return http_response
class HttpServer:
    def __init__(self):
        self.ssl=['','']
        self.reset()
    def reset(self):
        self.rdisk=RDisk()
        self.speed=2**16
        self.routes=[]          #[(route,methods_list,func),...]
        self.post=3030
        self.cookie=None
        self.template_path=getcwd().replace('\\','/')
    def set_template_path(self,folderpath):
        if isdir(folderpath):
            if folderpath[-1] not in ('\\','/'):
                folderpath+='/'
            self.template_path=folderpath
        else:
            raise FileNotFoundError('指定路徑不存在:',folderpath)
    def add_route(self,path,methods_list,func):
        for i in range(len(methods_list)):
            methods_list[i]=methods_list[i].upper()
        self.routes.append((path.lstrip('/'),methods_list,func))
    def mainloop(self):
        def deal_accept():
            self.now_accept+=1
            try:
                self.__accept_client()
            except Exception as e:  #未知錯誤
                print(e)
            self.now_accept -= 1
        my_ip = gethostbyname(gethostname())
        listener = socket(AF_INET, SOCK_STREAM)
        #listener.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
        listener.bind((my_ip, self.post))
        listener.listen(5)
        if self.ssl[0]!='':
            context = SSLContext(PROTOCOL_TLS_SERVER)              # 生成SSL上下文
            context.load_cert_chain(self.ssl[0],self.ssl[1])             # 加载服务器所用证书和私钥
            listener=context.wrap_socket(listener, server_side=True)
            print(f'連線位址: https://{my_ip}:{self.post}\n伺服器啟動中...')
        else:
            print(f'連線位址: http://{my_ip}:{self.post}\n伺服器啟動中...')
        #listener.setblocking(False)  # 將此socket設成非阻塞
        self.listening=True
        self.now_accept=0     #目前請求尚未處理完畢的次數
        while True:
            try:
                self.conn_address = listener.accept()
                #print('請求尚未完成:',self.now_accept)
            except SSLError:
                print('證書不被信任')
                continue
            except KeyboardInterrupt:
                print('KeyboardInterrupt')
                break
            except Exception as e:
                print(e)
                print('accept失敗')
                continue
            Thread(target=deal_accept).start()
            while self.conn_address!=0:
                sleep(0.1)
        listener.close()
        self.listening=False
    def __accept_client(self):
        conn,address=self.conn_address
        self.conn_address=0
        #--------------------------------------------------#處理收到的請求
        http_content=conn.recv(self.speed)
        if http_content==b'':
            print('收到空訊息:',http_content)
            conn.send(_404)
            return
        #-------------------------------------------------- #取得請求資訊
        try:
            request=Request(http_content,conn)
        except:
            print('收到無法解析的請求')
            conn.send(_404.to_bytes())
            return
        if 'Cookie' not in request.header_params:
            id=None
        else:id=int(request.header_params['Cookie']['id'])
        user=HttpDB.get_user(id)
        request.address=address
        #--------------------------------------------------
        method=request.method.upper()
        path=request.url
        replay=None
        #--------------------------------------------------投入函數
        for i in range(2):
            for route in self.routes:
                if path==route[0] and method in route[1]:
                    replay=route[2](user,request)
                    break
            if replay==None:
                if ':' not in path:  # 代表是相對路徑
                    path = path.lstrip('/')  # 去掉字串左方所有"/"
                    if path == '':
                        path = 'index.html'  # Load index file as default
            else:break
        #-------------------------------------------------回復用戶端
        if replay==None:
            if ':' not in path:
                path = self.template_path + path
            replay=return_http_file(path,self.rdisk)
        #------------------------------------------------------
        replay.set_header('Set-Cookie',user['cookie'])
        #------------------------------------------------------
        send_byte=replay.to_bytes()
        send_size=2**20       #1MB
        process=0
        total=len(send_byte)
        user['inspect']=int(time())        #設定檢查碼
        inspect_time=user['inspect']
        conn.settimeout(10)  # 設定超時
        req_n=0
        user['last_request']=request
        while process<total:
            code=send_byte[process:process+send_size]
            try:
                conn.send(code)
                process+=len(code)
            except ConnectionResetError as e:    #遠端連線被關閉
                print(e)
                break
            except timeout:
                print('傳送超時，重新傳送')
            if inspect_time!=user['inspect']:
                inspect_time=user['inspect']
                req_n+=1
                print('客戶進行新的請求',display_time(time()),req_n)
                if user['last_request'].url!='favicon.ico':           #去除瀏覽器自動的favicon.ico請求
                    break
            elif total>send_size:
                print(f'處理:{path} 進度:{process}/{total} {round(process/total*100,2)}%')
            if not self.listening:
                print('伺服器已關閉')
                break
        #------------------------------------------------關閉連線
        conn.close()
class HttpsServer(HttpServer):
    def __init__(self,crf_filepath,key_filepath):
        self.ssl=[crf_filepath,key_filepath]
        self.reset()