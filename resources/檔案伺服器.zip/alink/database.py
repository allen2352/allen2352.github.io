class DataBase:
    def __init__(self):
        self.users={}
        self.set_init_user_data({})
    def set_init_user_data(self,object):
        self.init_user_data =object
    def get_user(self,address):
        ip=address[0]
        if ip not in self.users:
            self.users[ip]=self.init_user_data.copy()
        return self.users[ip]
