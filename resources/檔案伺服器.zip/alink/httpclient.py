from ssl import wrap_socket,CERT_NONE,PROTOCOL_SSLv23
from socket import socket,AF_INET,SOCK_STREAM,gethostname,gethostbyname,SOL_SOCKET,SO_REUSEADDR

#import ssl
#ssl._create_default_https_context =ssl._create_unverified_context

def type_convert(value):
    value=value.lstrip(' ')
    if value[0] in ("'",'"'):
        return value[1:-1]
    elif value[0] in '0123456789-':
        try:                             #可能導致錯誤，e.g. 192.168.31.82
            if '.' in value:
                return float(value)
            return int(value)
        except:pass
    return value            #無法處理
class Request:
    def __init__(self,http_content,conn):
        self.http_content=http_content
        #回復封包:版本 狀態碼 短語
        n=len(http_content)
        try:
            k=http_content.index(b'\n')
        except:
            k=n
        first_line=http_content[:k].decode('utf-8').split(' ')
        self.status_code = int(first_line[1])     #狀態碼
        #-----------------------------------------    處理首部欄位
        self.header_params={}      #首部欄位參數
        while k<n:
            p=k+1
            try:
                k = http_content.index(b'\n',p)
            except:
                k = n
            if http_content[k - 1] == 10:
                k2 = k - 1  # b'\r'
            else:k2=k
            if abs(k-p)<2:    #代表接下來是content
                break
            deal_line=http_content[p:k2].decode('utf-8')
            if ':' in deal_line:
                c=deal_line.split(':')
                if c[1][-1]=='\r':value=c[1][:-1]
                else:value=c[1]
                #--------------------------------
                self.header_params[c[0]]=type_convert(value)
        #-------------------------------------------    處理content
        if 'Content-Length' in self.header_params:
            self.content = [http_content[k + 1:]]
            content_length = self.header_params['Content-Length']
            recv_length = len(self.content[0])
            if recv_length < content_length:
                speed = 2 ** 16
                while recv_length < content_length:
                    content = conn.recv(speed)  # 重新接收
                    recv_length += len(content)
                    self.content.append(content)
            self.content = b''.join(self.content)
        else:
            self.content = http_content[k + 1:]
        self.raw=self.http_content+self.content
def parse_url(url):
    #---------------------------------------------------------檢查url是否包含"http"
    if url[:4] != 'http':
        url = 'https://' + url        #默認使用https請求
    #---------------------------------------------------------提取域名
    p,n=url.index('//')+2,len(url)
    try:
        k=url.index('/',p)
    except:k=n
    hostname=url[p:k]
    try:
        ip=gethostbyname(hostname)
    except:ip=hostname
    #----------------------------------------------------------提取參數
    if '?' in url:
        k2=url.index('?')
        params=url[k2+1:]
    else:
        k2=n
        params=None
    #----------------------------------------------------------提取路徑
    path=url[k:k2]
    if path=='':path='/'
    return {'host':hostname,'ip':ip,'path':path,'params':params,'url':url}
class Session:           #網路漫遊者，本身就是一種session
    def __init__(self,header=None):
        self.header=header
        self.common_ports = [443,80,21, 22, 8080]
        self.port=443
        self.speed=2**16
    def send(self,url,method,header,content=''):              #發送
        UD=parse_url(url)
        path=UD['path']
        if UD['params']!=None:
            path+='?'+UD['params']
        request_box=[f"{method} {path} HTTP/1.1",f"Host: {UD['host']}"]
        #-----------------------------添加表頭資訊
        for key in header:
            request_box.append(f'{key}:{header[key]}')
        #-----------------------------加入內容
        request_box+=['','']     #結尾需要兩個\r\n
        header_request='\r\n'.join(request_box)       #此request僅包含http表頭，content未加入
        #--------------------------------------------------------------------------------------建立socket
        s = socket(AF_INET,SOCK_STREAM)

        if UD['url'][:6]=='https:':             #https協定添加ssl包裝
            s = wrap_socket(s, ssl_version=PROTOCOL_SSLv23, cert_reqs=CERT_NONE)#,keyfile='server.key', certfile='server.crt',do_handshake_on_connect=False)
        connect=False
        ip=UD['ip']
        print(ip)
        errors=[]
        for port in self.common_ports:
            try:
                s.connect((ip, port))                   # 连接到 HTTPS 服务器
                connect=True
                break
            except Exception as e:
                errors.append(e)
        if not connect:
            for i in range(65536):
                try:
                    s.connect((ip,i))  # 连接到 HTTPS 服务器
                    print(i,'可用port')
                    break
                except:
                    pass
            raise errors[0]
        #----------------------------------------------------------------------------------------
        #----------------------------------------傳送表頭資訊
        s.send(header_request.encode('utf-8'))
        #----------------------------------------接收回復
        http_content =s.recv(self.speed)
        print(http_content)
        request = Request(http_content,s)
        s.close()
        return request
    def get(self,url):
        header={
            'Connection':'keep-alive',
            'Pragma':'no-cache',
            'Cache-Control':'no-cache',
            'sec-ch-ua':'Google Chrome";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
            #'sec-ch-ua-mobile':'?0',
            'sec-ch-ua-platform':'"Windows"',
            #'Upgrade-Insecure-Requests':'1',
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            #'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            #'Sec-Fetch-Site':'none',
            #'Sec-Fetch-Mode': 'navigate',
            #'Sec-Fetch-User': '?1',
            #'Sec-Fetch-Dest': 'document',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'zh-TW,zh;q=0.9'
        }
        return self.send(url,'GET',header,'')