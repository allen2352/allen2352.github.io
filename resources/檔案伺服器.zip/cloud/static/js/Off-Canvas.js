function openNav() {
    nav_is_open=1;
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
  }
  
  function closeNav() {
    nav_is_open=0;
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
  }
  var nav_is_open=0;
  function controlNav(){
    if (nav_is_open==0)
        openNav();
    else
        closeNav();
  }