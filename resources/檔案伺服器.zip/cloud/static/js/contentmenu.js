let mouseX = 0
let mouseY = 0

var myfiles_buttons=document.getElementsByClassName("myfile");
var contentmenu=document.getElementById("contentmenu");
var contentmenu2=document.getElementById("contentmenu2");
var contentmenu_show=0;
var choose_file="";
var choose_id="";
var now_rename=false;
var before_naming_html="";
var ban_rename_update=false;
var nfolder=document.getElementById("newfolder");

document.body.addEventListener('mousedown', function(e) {
    if(contentmenu_show==0){
        contentmenu.style.visibility="hidden";
        contentmenu2.style.visibility="hidden";
    }
    else
        contentmenu_show=0;
    if (now_rename){
        if (ban_rename_update)
            ban_rename_update=false;
        else{
            now_rename=false;
            nfolder.innerHTML="&ensp;";
            document.getElementById(choose_id).innerHTML=before_naming_html;
        }
    }
});
document.body.addEventListener("wheel",function(e){
        contentmenu.style.visibility="hidden";
        contentmenu2.style.visibility="hidden";
});


for (var i=0;i<myfiles_buttons.length;i++){
    myfiles_buttons[i].addEventListener('mousedown', function(e) {
        if(e.button==2){                                       //右鍵
            if (now_rename){
                now_rename=false;
                nfolder.innerHTML="&ensp;";
                document.getElementById(choose_id).innerHTML=before_naming_html;
            }
            contentmenu2.style.visibility="hidden";
            mouseX = e.pageX+"px";
            mouseY = e.pageY+"px";
            contentmenu_show=1;
            contentmenu.style.visibility="visible";
            contentmenu.style.left =mouseX;
            contentmenu.style.top=mouseY;
            choose_file=this.getAttribute("name");
            choose_id=this.getAttribute("id");
        }else if (e.button==0){                                                 //左鍵
            if (!now_rename){
                location.href='/index.html?path='+this.getAttribute("id");
            }else if (this.getAttribute("id")==choose_id){
                ban_rename_update=true;
            }
        }
        
    });
}
nfolder.addEventListener('mousedown', function(e) {
    ban_rename_update=true;
});

document.getElementById("filebox").addEventListener('mousedown', function(e) {
    if(e.button==2 && contentmenu_show==0){                                       //右鍵
        if (now_rename){
            now_rename=false;
            nfolder.innerHTML="&ensp;";
            document.getElementById(choose_id).innerHTML=before_naming_html;
        }
        this.style.color="yellowgreen";
        contentmenu.style.visibility="hidden";
        mouseX = e.pageX+"px";
        mouseY = e.pageY+"px";
        contentmenu_show=1;
        contentmenu2.style.visibility="visible";
        contentmenu2.style.left =mouseX;
        contentmenu2.style.top=mouseY;
    }else if (e.button==1){                                                    //滾輪
        contentmenu.style.visibility="hidden";
    }
    
});
contentmenu.addEventListener('mousedown',function(e){             //防止按下選單時，按鈕被隱藏
    contentmenu_show=1;
})
contentmenu2.addEventListener('mousedown',function(e){            //防止按下選單時，按鈕被隱藏
    contentmenu_show=1;
})

window.oncontextmenu=function(e){
    //取消默认的浏览器自带右键 很重要！！
    e.preventDefault();
}

//以下是功能函數
function copylink(){
    location.href="/copylink?filename="+choose_file;
}

function pastelink(){
    location.href="/pastelink";
}

function renamelink(){
    now_rename=true;
    var element=document.getElementById(choose_id);
    contentmenu.style.visibility="hidden";
    before_naming_html=element.innerHTML;
    element.innerHTML='<input class="form-control" id="rename_input" value="'+choose_file+'">';
    var rename_input=document.getElementById("rename_input");
    rename_input.focus();
    rename_input.addEventListener('mousedown',function(e){            //防止按下選單時，按鈕被隱藏
        contentmenu_show=1;
    })
    rename_input.addEventListener("keypress", function(event) {
        if (event.key === "Enter") {
          location.href="/rename?param="+choose_file+'*'+this.value;
        }
      });
}

function cutlink(){
    location.href="/cutlink?filename="+choose_file;
}

function removelink(){
    location.href="/removelink?filename="+choose_file;
}

function newfolder(){
    now_rename=true;
    nfolder.innerHTML='<input class="form-control" id="newfolder_input" placeholder="新增資料夾">';
    var newfolder_input=document.getElementById("newfolder_input");
    newfolder_input.focus();
    newfolder_input.addEventListener("keypress", function(event) {
        if (event.key === "Enter" && this.value!="") {
          location.href="/newfolder?name="+this.value;
        }
      });
}