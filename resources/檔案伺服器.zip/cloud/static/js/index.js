function openNav() {
    nav_is_open=1;
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}
  
function closeNav() {
  nav_is_open=0;
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}
var nav_is_open=0;
function controlNav(){
  if (nav_is_open==0)
      openNav();
  else
      closeNav();
}
openNav();

function upload_file(){
  file_form=document.getElementById("file_form");
  file_form.submit();
}

//處理terminal

var terminal_content=document.getElementById("terminal_content");

var cmd_list=[]; //歷史命令
var cmd_k=-1;    //命令指標

function send_cmd(event){
  var terminal_input=document.getElementById('terminal_input');
  if (event.key === "Enter") {
    var cmd=terminal_input.value;
    cmd_list.push(cmd);
    cmd_k=cmd_list.length-1;
    var result=command(encodeURIComponent(cmd));
    terminal_content.innerHTML=result+'<input type="text" id="terminal_input" >';
    document.getElementById('terminal_input').focus();
  }else if (event.ctrlKey){
    terminal_input.value="^Z";
  }else if (event.key=="ArrowUp" && cmd_list.length>0){
    terminal_input.value=cmd_list[cmd_k];
    if (cmd_k>0)
        cmd_k-=1;
  }else if (event.key=="ArrowDown" && cmd_list.length>cmd_k){
    cmd_k+=1;
    if (cmd_k>=cmd_list.length){
        terminal_input.value="";
        cmd_k=cmd_list.length-1;
    }else{
      terminal_input.value=cmd_list[cmd_k];
    }
  }
}
function terminal(){
  var terminal_btn=document.getElementById("terminal");
  terminal_btn.click();
  var result=command("display");
  terminal_content.innerHTML=result+'<input type="text" id="terminal_input" >';
  document.getElementById('terminal_input').focus();
}

function command(cmd){
  var xhr = new XMLHttpRequest();
  var response;
  xhr.open("GET", "/cmd?cmd="+cmd,false);
  xhr.onload = function(){
   // alert(xhr.responseText) //顯示資料訊息
    //var str = JSON.parse(xhr.responseText); //將回傳資料傳到瀏覽器-字串轉陣列：JSON.parse()
    //document.querySelector('.message') //HTML的文字訊息 class="message"
    //.textContent = str[0].name //將要抓取的資料顯示於頁面
    response=xhr.responseText;
    }
  xhr.send();
  return response;
}